 
<script>
    //On load
    var activity = $('#txt_chsn_budget_prep_upd').val();
    var project = $('#txt_chsn_project_by_activity').val();
    var budget_line = $('#txt_chsn_budget_by_project').val();
    var payee_type = $('#get_chsn_payee_type_upd').val();
    var payment_method = $('#txt_chsn_payment_method_upd').val();
    var reference = $('#txt_chsn_reference_upd').val();
    var ref_no = $('#txt_chsn_reference_no_upd').val();
    var unit_cost = $('#txt_chsn_unit_cost_upd').val();
    var quantity = $('#txt_chsn_quantity_upd').val();
    var cheque_no = $('#txt_chsn_cheque_number_upd').val();
    var details = $('#txt_chsn_details_upd').val();
    var account = $('#txt_chsn_account_upd').val();
    var bank = $('#txt_chsn_bank_upd').val();

    default_radio_state();
    po_invoice_noref_radios_checked();//Radio box changed
    cbo_invoice_for_details();//combo box changed
    cbo_po_pyt_voucher();//Combo changed
    save_payment_voucher();
    save_payment_vchr_btn_click();
    check_radios_and_get_combos();
    function check_radios_and_get_combos() {
        //<editor-fold defaultstate="collapsed" desc="activity and project combos">
        if ($('#txt_shall_expand_toUpdate').val() != '') {
            try {
                var all_activities_cbo = '';
                var project_by_activity_cbo = activity;

                //Get activities by payment voucher

                $('.wait_loader').show(2);

                $.post('handler_update_details2.php', {all_activities_cbo: all_activities_cbo}, function (data) {

                    var final = $.parseJSON(data.trim());
                    $('.cbo_fill_activity').empty().append('<option></option> <option value="fly_new_p_activity">--Add new-- </option>');
                    $.each(final, function (i, option) {
                        $('.cbo_fill_activity').append($('<option/>').attr("value", option.id).text(option.name));
                    });
                    //Select the activioty on the  activity cbo
                    $('.cbo_activity').val(activity);

                }).complete(function () {
                    //Get Project by payment voucher
                    var all_project_cbo = '';
                    $.post('handler_update_details2.php', {all_project_cbo: all_project_cbo}, function (data) {
                        var final = $.parseJSON(data.trim());
                        $('.cbo_project').empty().append('<option></option> <option>--Add new-- </option>');
                        $.each(final, function (i, option) {
                            $('.cbo_project').append($('<option/>').attr("value", option.id).text(option.name));
                        });
                        $('.cbo_project').val(project);
                    }).complete(function () {
                        var cont = '';

                        //maybe hide the loader gif
                        $('.cbo_type_project').val(budget_line);
                        $('.cbo_account').val(account);
                        console.log('The referece is:' + account);
                        $('#txt_chek_no').val(cheque_no);
                        $('#txt_description').val(details);
                        if (payee_type == 'staff') {
                            $('#rd_staff').prop('checked', true);
                            $('.cbo_staff').val(payee);

                        } else {
                            $('#rd_supplier').prop('checked', true);
                            $('.supplier_cbo').val(payee);
                        }

                        if (payment_method == 'cash') {
                            $('#rd_cash').prop('checked', true);
                        } else if (payment_method == 'bank') {
                            $('#rd_bank').prop('checked', true);
                            $('.cbo_bank').val(bank);
                        }
                        if (reference == 'payment voucher') {
                            $('#rd_ref').prop('checked', true);
                        } else if (reference == 'invoice') {
                            $('#rd_purchase_invoice').prop('checked', true);
                           
                            invoice_radios_checked_layout();
                            cbo_invoice_for_details(); 
                            $('.cbo_invoice_for_details').val(ref_no);
                        } else if (reference == 'purchase order') {
                           
                            $('#rd_Purchase_order').prop('checked', true);
                            cbo_po_pyt_voucher();
                            po_radios_checked_layout();
                            $('.cbo_po_pyt_voucher').val(ref_no);
                        }

                        default_radio_state();
                        po_invoice_noref_radios_checked();

                    });
                });

                $('.cbo_fill_activity').change(function () {
                    var activity = $(this, 'option:selected').val();
                    $('#txt_activity_id').val(activity);
                });
            } catch (err) {
                alert(err.message);
            }
        }
        //</editor-fold>

    }


    var upd_jouranal_id = 0;

    $('#rd_bank').change(function () {
        var check = $(this).is(':checked');
        if (check) {
            $('#bank_used').show();
            $('.check_no_row').slideDown(50);
        }

    });
    $('#rd_cash').change(function () {
        var check = $(this).is(':checked');
        if (check) {
            $('#bank_used').prop("selectedIndex", "0");
            $('#bank_used').hide();
            $('.check_no_row').slideUp(50);
        }
    });
//Suplier & staff
    $('#rd_supplier').change(function () {
        var check_supplier = $(this).is(':checked');
        if (check_supplier) {
            $('#supplier_auto_hide').show();
            //   $('#supplier_auto_hide').prop("selectedIndex", "0");
            $('#staff_auto_hide').hide();
        }
    });
    $('#rd_staff').change(function () {
        var check_staff = $(this).is(':checked');
        if (check_staff) {
            $('#supplier_auto_hide').hide();
            //  $('#supplier_auto_hide').prop("selectedIndex", "0");
            $('#staff_auto_hide').show();
        }
    });


    function default_radio_state() {
        var check1 = $('#rd_cash').is(':checked');
        var check2 = $('#rd_bank').is(':checked');
        if (check1) {
            $('#bank_used').show();
            $('#bank_used').hide();
            $('.check_no_row').slideDown(50);
        }
        if (check2) {
            $('#bank_used').show();

        }

        //Supplier & staff
        var check_supplier = $('#rd_supplier').is(':checked');
        var check_staff = $('#rd_staff').is(':checked');
        if (check_supplier) {
            $('#supplier_auto_hide').show();
            $('#staff_auto_hide').hide();
        }
        if (check_staff) {
            $('#supplier_auto_hide').hide();
            $('#staff_auto_hide').show();
        }
    }

    function save_payment_vchr_btn_click() {
        $('#send_payment_voucher').click(function () {
            save_payment_voucher();
            $('.warn_msg').html('You have to choose the bank');
        });
    }

    function save_payment_voucher() {//This is to validate the fields

        if ($('#rd_bank').is(':checked') && $('.cbo_bank').val() == '') {
            return false;
        } else {
            return true;
        }
    }
    var payee = '<?php echo chosen_payee_upd(); ?>';
    var account = '<?php echo chosen_account_upd(); ?>';
    $('.cbo_account').val(account);
    $('.cbo_staff').val(payee);
    $('#txt_payee_id').val(payee);

    //Radio buttons
    function po_radios_checked_layout() {
        $('#po_data_row').slideDown(30);
        $('#invc_data_row').slideUp(30);
        $('#existing_qty_uc_row').slideUp(30);
        $('#py_vchr_btn_show_req_form').hide(30);
        $('.po_invoice_res').html('');
//           $('.cbo_po_pyt_voucher option:selected').prop('selected', false);
    }
    function invoice_radios_checked_layout() {
        $('#invc_data_row').slideDown(30);
        $('#po_data_row').slideUp(30);
        $('#existing_qty_uc_row').slideUp(30);
        $('#py_vchr_btn_show_req_form').hide(30);
        $('.po_invoice_res').html('');
    }
    function po_invoice_noref_radios_checked() {
        $('#rd_Purchase_order').change(function () {
            var po_selected = $(this).is(':checked');
            if (po_selected) {
                po_radios_checked_layout();
            }
        });
        $('#rd_purchase_invoice').change(function () {
            var pinvoice_selected = $(this).is(':checked');
            if (pinvoice_selected) {
                invoice_radios_checked_layout();
            }
        });
        $('#rd_ref').change(function () {
            var no_reference = $(this).is(':checked');
            if (no_reference) {
                $(".cbo_invoice_for_details option:selected").prop("selected", false);
                $('#po_data_row').slideUp(30);
                $('#invc_data_row').slideUp(30);
                $('#py_vchr_btn_show_req_form').show(30);
                $('.po_invoice_res').html('');
                $('#existing_qty_uc_row').slideDown(30);
            }
        });
    }


    $('#py_vchr_btn_show_req_form').click(function () {
        $('.white_bg').fadeIn(300, function () {
            $('.payment_voucher_items_form').fadeIn(300, function () {
                $('.bgt_txt_unitC:eq(0)').val($('#txt_quantity').val());
                $('.item_txt_qty:eq(0)').val($('#txt_unit_cost').val());
                var uc = $('.bgt_txt_unitC:eq(0)').val();
                var qty = $('.item_txt_qty:eq(0)').val();
                var tot = uc * qty;
                $('.item_txt_amnt:eq(0)').val(tot);
            });
        });

        return false;
    });
    $('.of_req_form').click(function () {//HIding the form
        $('.payment_voucher_items_form').fadeOut(50, function () {
            $('.white_bg').fadeOut(50);
        });
        return false;

    });

    //When selected invoice


    function cbo_invoice_for_details() {
        $('.cbo_invoice_for_details').change(function () {
            var cbo_invoice_for_details = $(this).val();
            var main_req = $(this, ' option:selected').val();
            $('.add_load_gif').show(1);
            var res = '';
            console.log('The main request: ' + cbo_invoice_for_details);
            $.post('handler_update_details2.php', {cbo_invoice_for_details: cbo_invoice_for_details}, function (data) {
                res = data;
            }).complete(function () {
                $('.add_load_gif').hide(300, function () {
                    $('.po_invoice_res').html(res);
                });
            });
        });
    }

    function cbo_po_pyt_voucher() {
        $('.cbo_po_pyt_voucher').change(function () {
            var main_req = $(this, ' option:selected').val();
            var cbo_p_order_for_details = $(this).val();

            $('.add_load_gif').show(1);
            var res = '';
            $.post('handler_update_details2.php', {cbo_p_order_for_details: cbo_p_order_for_details}, function (data) {
//            console.log('return purchase order details: ' + data);
                res = data;
            }).complete(function () {
                $('.add_load_gif').hide(300, function () {
                    $('.po_invoice_res').html(res);
                });
            });

        });
    }

 
    $('.payment_voucher_update_link').click(function () {
        upd_jouranal_id = $(this).data('journlid');
        var table_to_update = $(this).data('table');
        var id_update = $(this).data('table_id');

        $.post('handler.php', {id_update: id_update, table_to_update: table_to_update}, function (data) {

        }).complete(function () {
            window.location.replace('redirect.php');
        });



    });

    $('.payment_voucher_update_link').click(function () {


    });//delete frompayment_voucher.. 





</script>


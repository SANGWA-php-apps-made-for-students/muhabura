<?php
session_start();
require_once '../web_db/multi_values.php';
require_once './navigation/extra_sub_menus.php';
require_once '../web_db/other_fx.php';
require_once '../web_db/Other_fx2.php';
require_once '../web_db/Details_by_click.php';

if (!isset($_SESSION)) {
    session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}

// <editor-fold defaultstate="collapsed" desc="--save Request in db ---">
function save_request() {
    if (isset($_POST['send_p_request'])) {

        require_once '../web_db/new_values.php';
        require_once '../web_db/other_fx.php';
        //get sums
        $items = $_POST['acc_item_combo'];
        $measurement = $_POST['measurement_array'];
        $quantity = $_POST['txt_qty'];
        $unit_c = $_POST['txt_unit_c'];

        $index_item = new ArrayIterator($items);
        $index_measurement = new ArrayIterator($measurement);
        $index_quantity = new ArrayIterator($quantity);
        $index_unit_c = new ArrayIterator($unit_c);
        $mit = new MultipleIterator(MultipleIterator::MIT_KEYS_ASSOC);

        $mit->attachIterator($index_item, "Item");
        $mit->attachIterator($index_measurement, "measurement");
        $mit->attachIterator($index_quantity, "quantity");
        $mit->attachIterator($index_unit_c, "unit_c");
        
        $ot = new other_fx();

        $entry_date = date('Y-m-d ' . $ot->local_time_h() . ':i:s');
        $user = $_SESSION['userid'];
        $field = filter_input(INPUT_POST, 'cbo_field');

        $obj = new new_values();
        $obj->new_Main_Request($entry_date, $user);
        $m = new multi_values();
        $last_req = $m->get_last_Main_Request();
        foreach ($mit as $fruit) {
            $dc = json_decode(json_encode($fruit), true);
            foreach ($dc as $val) {
                if (!empty($dc['Item'])) {
                    $newobj = new new_values();
                    $item = $dc['Item'];
                    $quantity = (!empty($dc['quantity'])) ? $dc['quantity'] : 0;
                    $unit_c = (!empty($dc['unit_c'])) ? $dc['unit_c'] : 0;
                    $amount = filter_var($unit_c, FILTER_SANITIZE_NUMBER_INT) * filter_var($quantity, FILTER_SANITIZE_NUMBER_INT);
                    if ($amount > 0) {
                        $request_no = '';
                        $status = 0;
                        $DAF = date("Y-m-d h:m:s");
                        $DG = date("Y-m-d h:m:s");
                        if (isset($_SESSION['table_to_update']) && $_SESSION['table_to_update'] == 'p_request') {
                            ?><script>alert('Updating, ...');</script><?php
                        } else {
                            $newobj->new_p_request($item, filter_var($quantity, FILTER_SANITIZE_NUMBER_INT), filter_var($unit_c, FILTER_SANITIZE_NUMBER_INT), filter_var($amount, FILTER_SANITIZE_NUMBER_INT), $entry_date, $user, $dc['measurement'], $request_no, $last_req, $field, $status, $DAF, $DG);
                        }
                    }
                    
                    break;
                }
            }
        }
    }
}

// </editor-fold>
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title>
            p_budget
        </title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <link href="admin_style.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/financial_rep.css" rel="stylesheet" type="text/css"/>
        <meta name="viewport" content="width=device-width, initial scale=1.0"/>
        <style>
            .journal_entry_table thead{
                background-color: #234094;
            }
            .journal_entry_table .textbox{
                background-color: #f0f2f7;
                width: 100%;
                margin: auto;
            }
        </style>
    </head>
    <body>
        <?php
        include 'admin_header.php';
        $ot = new other_fx();
        $ot->get_yes_no_dialog();
       
       
        $ot->get_searchNew_menu('Request', without_admin());
        $ot2= new Other_fx2();
        $ot2->get_details_result_pane();
        ?>
        <div class="parts eighty_centered off saved_dialog">
            p_budget saved successfully!
        </div>
        <!--Start of opening measurement Pane(The pane that allow the user to add the data in a different table without leaving the current one)-->
        <div class="parts abs_full eighty_centered onfly_pane_measurement">
            <div class="parts  full_center_two_h heit_free">
                <div class="parts pane_opening_balance  full_center_two_h heit_free no_shade_noBorder">
                    <table class="new_data_table" >
                        <thead>Add new measurement</thead>
                        <tr>     <td>code</td> <td><input type="text" required class="textbox"  id="onfly_txt_code" />  </td>
                        <tr>     <td>description</td> <td><input type="text" required class="textbox"  id="onfly_txt_description" />  </td>
                        </tr>
                        <tr>
                            <td colspan="2">
                                <input type="button" class="confirm_buttons btn_onfly_save_measurement" name="send_measurement" value="Save & close"/> 
                                <input type="button" class="confirm_buttons reverse_bg_btn reverse_color cancel_btn_onfly" name="send_account" value="Cancel"/> 
                            </td>
                        </tr>
                    </table>
                </div>
            </div>                        
        </div>
        <!--End of opening Pane-->

        <!--Start of opening p_budget_itemsPane(The pane that allow the user to add the data in a different table without leaving the current one)-->
        <div class="parts abs_full eighty_centered onfly_pane_p_budget_items">
            <div class="parts  full_center_two_h heit_free">
                <div class="parts pane_opening_balance  full_center_two_h heit_free no_shade_noBorder">
                    <table class="new_data_table" >
                        <thead>Add new  Items</thead>
                        <tr>     <td>item name</td> <td><input type="text" required class="textbox"  id="onfly_txt_item_name" />  </td>
                        <tr>     <td>Description</td> <td><input type="text" required class="textbox"  id="onfly_txt_description" />  </td>
                        <tr>     <td>Account</td> <td><input type="text" required class="textbox"  id="onfly_txt_chart_account" />  </td>
                        </tr>
                        <tr>
                            <td colspan="2">                                 
                                <input type="button" class="confirm_buttons btn_onfly_save_p_budget_items" name="send_p_budget_items" value="Save & close"/> 
                                <input type="button" class="confirm_buttons reverse_bg_btn reverse_color cancel_btn_onfly" name="send_account" value="Cancel"/> 
                            </td>
                        </tr>
                    </table>
                </div>
            </div>  
        </div>
        <!--End of opening Pane--> 

        <div class="parts eighty_centered new_data_box off">
            <input type="hidden" style="float: right;" id="txt_project_id"   name="txt_project_id"/>
            <!--Below fields get the session values when the user has selected the year and the activity-->
            <input type="hidden" style="float: right;" id="txt_selected_fisc_year_id"   name="txt_f_year_process" value="<?php echo get_fisc_year_process(); ?>"  />
            <input type="hidden" style="float: right;" id="txt_selected_activity_id"   name="txt_f_activity_process" value="<?php echo get_activity_process(); ?>" />
            <form action="new_p_request.php" method="post" >
                <input type="hidden" id="txt_shall_expand_toUpdate" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim($_SESSION['table_to_update']) : '' ?>" />
                <!--this field  (shall_expand_toUpdate)above is for letting the form expand using js for updating-->
                <input type="hidden" id="txt_account_id"   name="txt_account_id"/>
                <input type="hidden" id="txt_activity_id"   name="txt_activity_id"/>
                <input type="hidden"   id="txt_fisc_year_id"   name="txt_fisc_year_id"/>
                <div class="parts full_center_two_h heit_free no_shade_noBorder">  
                    <div class="parts margin_free x_width_thr_h heit_free no_paddin_shade_no_Border ">
                        <table>
                            <tr>
                                <td style="min-width: 150px;">&nbsp;&nbsp;Field:<br/> <?php get_field_combo(); ?> </td>
                                <td>&nbsp;&nbsp; 
                                    <div class="parts no_paddin_shade_no_Border">
                                        Project
                                    </div>
                                    <div class="parts no_paddin_shade_no_Border status_labels only_numbers" id="proj_status_lbl">0</div> <br/> 
                                    <?php get_project_by_fiscalyear(); ?>      
                                </td>
                                <td>&nbsp;&nbsp; 
                                    <div class="parts no_paddin_shade_no_Border off">
                                        Activity:
                                    </div>
                                    <div class="parts no_paddin_shade_no_Border status_labels off" id="activity_status_lbl">0</div>  <br/> 
                                    <select name="cbo_activity" class="textbox fill_from_project small_cbos off" id="activity_tot" style="width: 150px; float: right;">
                                        <option> --Activities--</option>
                                    </select>
                                </td>
                                <td>&nbsp;&nbsp;Description<br/>
                                    <input required type="text" class="textbox x_width_thr_h"></textarea>
                                </td>
                            </tr>
                            <tr class="off">
                                <td colspan="4">
                                    <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border">
                                        Remaining on the budget
                                    </div>
                                </td>
                            </tr>
                        </table>
                    </div>
                    <span class="parts full_center_two_h no_paddin_shade_no_Border warn_msg off heit_free">
                        You have to choose the field
                    </span>
                </div>
                <table class="dataList_table journal_entry_table thehidden_part " style="width: 80%;">
                    <?php
                    loader_center();
                    $req_form= new Other_fx2();
                    $req_form->get_request_form();
                    ?>
                    <tr><td colspan="5"> 
                            <input class="confirm_buttons save_request" type="submit" id="save_budget" name="send_p_request" value="Save" > 
                            <input type="button" class="cancel_btn red_cancel_button off" name="send_cancel"  data-cancel_name="" value="Cancel"/>
                            <!--Here shoud be a button called by php but that one is called by "if condition of php" and we rather want to call the button by js-->
                        </td></tr>
                </table>
            </form> 
            <table class=" off">
                <tr><td><label for="txt_"budget_value>budget value </label></td><td> <input type="text"     name="txt_budget_value" required id="txt_budget_value" class="textbox" value="<?php echo trim(chosen_budget_value_upd()); ?>"   />  </td></tr>
                <tr><td><label for="txt_"description>Description </label></td><td> <input type="text"     name="txt_description" required id="txt_description" class="textbox" value="<?php echo trim(chosen_description_upd()); ?>"   />  </td></tr>
                <tr><td><label for="txt_"is_active>Is Active </label></td><td> <input type="text"     name="txt_is_active" required id="txt_is_active" class="textbox" value="<?php echo trim(chosen_is_active_upd()); ?>"   />  </td></tr>
                <tr><td class="new_data_tb_frst_cols">Activity </td><td> <?php get_activity_combo(); ?>  </td></tr>
                <tr><td colspan="2"> 
                        <input type="submit" class="confirm_buttons" name="send_p_request" value="Save"/>
                        <input type="button" class="confirm_buttons reverse_bg_btn reverse_color cancel_btn_onfly" name="send_account" value="Cancel"/> 
                    </td></tr>
            </table>
        </div>
        <div class="parts eighty_centered datalist_box" >
            <div class="parts no_shade_noBorder xx_titles no_bg whilte_text dataList_title no_paddin_shade_no_Border">Requests </div>
            <?php
            save_request();
            if (isset($_POST['prev'])) {
                $_SESSION['page'] = ($_SESSION['page'] < 1) ? 1 : ($_SESSION['page'] -= 1);
                $last = ($_SESSION['page'] > 1) ? $_SESSION['page'] * 30 : 30;
                $first = $last - 30;
            } else if (isset($_POST['page_level'])) {//this is next
                $_SESSION['page'] = ($_SESSION['page'] < 1) ? 1 : ($_SESSION['page'] += 1);
                $last = $_SESSION['page'] * 30;
                $first = $last - 30;
            } else if (isset($_SESSION['page']) && isset($_POST['paginated']) && $_SESSION['page'] > 0) {// the use is on another page(other than the first) and clicked the page inside
                $last = $_POST['paginated'] * 30;
                $first = $last - 30;
            } else if (isset($_POST['paginated']) && $_SESSION['page'] = 0) {
                $first = 0;
            } else if (isset($_POST['paginated'])) {
                $last = $_POST['paginated'] * 30;
                $first = $last - 30;
            } else if (isset($_POST['first'])) {
                $_SESSION['page'] = 1;
                $first = 0;
            } else {
                $first = 0;
            }
            $menu = new extra_sub_menus();
            $menu->get_request_smenu();
            ?>
            <div class="parts no_paddin_shade_no_Border page_pane" id="page_pane1">
                <?php
                $obj = new multi_values();
                $ot3 = new other_fx();
                $first = $obj->get_first_p_budget();
                $obj->list_p_request($first);
                //Add the Request pdf and exce
                $ot3->get_pdf_excel('../prints/print_p_request.php', '../web_exports/excel_export.php');
                ?>
            </div> 
            <div class="parts no_paddin_shade_no_Border page_pane off" id="page_pane2">
                <?php
                $det = new Details_by_click();
                $ot = new other_fx();
                $ot->list_requests_by_field();
                ?>
                <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border top_off_xx">
                    <form action="../print_more_reports/print_all_requests.php" target="blank" method="post">
                        <input type="hidden" name="start_date" value="<?php // echo $this->get_this_year_start_date();                                                                                                                                                                                                                                                                                                                                  ?>"/>
                        <input type="hidden" name="end_date" value="<?php // echo $this->get_this_year_end_date();                                                                                                                                                                                                                                                                                                                                  ?>"/>
                        <input type="hidden" name="field_id" value="<?php // echo $row['p_field_id'];                                                                                                                                                                                                                                                                                                                                   ?>"/>
                        <input type="hidden" name="field_name" value="<?php // echo $row['field_name'];                                                                                                                                                                                                                                                                                                                                   ?>"/>
                        <input type="submit" name="export" class="btn_export  btn_export_pdf margin_free" value="Export"/>
                    </form>
                </div>
            </div>
        </div>
        <div class="parts eighty_centered  no_paddin_shade_no_Border no_shade_noBorder check_loaded" >
            <?php require_once './navigation/add_nav.php'; ?> 
        </div>
        <div class="parts full_center_two_h heit_free footer"> Copyrights <?php echo '2018 - ' . date("Y") . ' MUHABURA MULTICHOICE COMPANY LTD Version 1.0' ?></div>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="admin_script.js" type="text/javascript"></script>
        <script src="../web_scripts/date_picker/jquery-ui.min.js" type="text/javascript"></script>
        <script src="../web_scripts/date_picker/jquery-ui.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
        <script src="../web_scripts/searches.js" type="text/javascript"></script>
      
        <?php require_once './request_js.php'; ?>
    </body>
</hmtl>
<?php

function loader_center() {
    $ld = new other_fx();
    $ld->get_load_in_center();
}

function get_project_by_fiscalyear() {
    $det = new Details_by_click();
    $ot = new other_fx();
    $start_date = $ot->get_this_year_start_date();
    $end_date = $ot->get_this_year_end_date();
    $det->get_project_by_fisca_year();
}

function get_field_combo() {
    $obj = new multi_values();
    $obj->get_field_in_combo();
}

function get_items_in_combo() {
    require_once '../web_db/other_fx.php';

    $ot = new other_fx();
    $ot->get_items_in_combo();
}

function get_measurement_combo() {
    $obj = new other_fx();
    $obj->get_measurement_in_combo_arr();
}

function get_project_combo() {
    $obj = new multi_values();
    $obj->get_project_in_combo_refill();
}

function get_project_pre_filled() {//this finction will bring the data on the form load
    $obj = new multi_values();
    $obj->get_type_project_in_sml_cbo();
}

function get_fisc_year_combo() {
    $obj = new multi_values();
    $obj->get_fisc_year_in_combo();
}

function get_account_in_combo() {
    require_once '../web_db/other_fx.php';
    $obj = new other_fx();
    $obj->get_account_in_combo_array();
}

function get_account_combo() {
    require_once '../web_db/other_fx.php';
    $obj = new multi_values();
    $obj->get_account_in_combo();
}

function chosen_budget_value_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'p_budget') {
            $id = $_SESSION['id_upd'];
            $budget_value = new multi_values();
            return $budget_value->get_chosen_p_budget_budget_value($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_description_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'p_budget') {
            $id = $_SESSION['id_upd'];
            $description = new multi_values();
            return $description->get_chosen_p_budget_description($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_account_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'p_budget') {
            $id = $_SESSION['id_upd'];
            $account = new multi_values();
            return $account->get_chosen_p_budget_account($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_entry_date_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'p_budget') {
            $id = $_SESSION['id_upd'];
            $entry_date = new multi_values();
            return $entry_date->get_chosen_p_budget_entry_date($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_is_active_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'p_budget') {
            $id = $_SESSION['id_upd'];
            $is_active = new multi_values();
            return $is_active->get_chosen_p_budget_is_active($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_status_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'p_budget') {
            $id = $_SESSION['id_upd'];
            $status = new multi_values();
            return $status->get_chosen_p_budget_status($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function get_activity_combo() {

    $obj = new multi_values();
    $obj->get_activity_in_combo();
}

function chosen_activity_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'p_budget') {
            $id = $_SESSION['id_upd'];
            $activity = new multi_values();
            return $activity->get_chosen_p_budget_activity($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function get_fisc_year_process() {
    if (isset($_SESSION['selected_fisc_year'])) {
        return (isset($_SESSION['selected_fisc_year'])) ? $_SESSION['selected_fisc_year'] : '';
    }
}

function get_activity_process() {
    return (isset($_SESSION['activity'])) ? $_SESSION['activity'] : '';
}

function get_cancel_btn() {
    $ot = new other_fx();
    $ot->get_cancel_button();
}

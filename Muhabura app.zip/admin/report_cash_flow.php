<?php
    session_start();
    require_once '../web_db/multi_values.php';
    require_once '../web_db/other_fx.php';
    if (!isset($_SESSION)) {
        session_start();
    }
    if (!isset($_SESSION['login_token'])) {
        header('location:../index.php');
    }
    if (isset($_POST['send_journal_entry_line'])) {
        if (isset($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'journal_entry_line') {
                require_once '../web_db/updates.php';
                $upd_obj = new updates();
                $journal_entry_line_id = $_SESSION['id_upd'];
                $accountid = trim($_POST['txt_accountid_id']);
                $dr_cr = $_POST['txt_dr_cr'];
                $amount = $_POST['txt_amount'];
                $memo = $_POST['txt_memo'];
                $journal_entry_header = $_POST['txt_journal_entry_header_id'];
                $upd_obj->update_journal_entry_line($accountid, $dr_cr, $amount, $memo, $journal_entry_header, $journal_entry_line_id);
                unset($_SESSION['table_to_update']);
            }
        } else {
            $accountid = trim($_POST['txt_accountid_id']);
            $dr_cr = $_POST['txt_dr_cr'];
            $amount = $_POST['txt_amount'];
            $memo = $_POST['txt_memo'];
            $journal_entry_header = trim($_POST['txt_journal_entry_header_id']);
            require_once '../web_db/new_values.php';
            $obj = new new_values();
            $obj->new_journal_entry_line($accountid, $dr_cr, $amount, $memo, 0);
        }
    }
?>

<html>
    <head>
        <meta charset="UTF-8">
        <title>
            journal_entry_line
        </title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <link href="admin_style.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/financial_rep.css" rel="stylesheet" type="text/css"/>
        <link href="../web_scripts/date_picker/jquery-ui.css" rel="stylesheet" type="text/css"/>
        <link href="../web_scripts/date_picker/jquery-ui.min.css" rel="stylesheet" type="text/css"/>
        <link href="../web_scripts/date_picker/jquery-ui.structure.css" rel="stylesheet" type="text/css"/>
        <link href="../web_scripts/date_picker/jquery-ui.structure.min.css" rel="stylesheet" type="text/css"/>
        <link href="../web_scripts/date_picker/jquery-ui.theme.css" rel="stylesheet" type="text/css"/>
        <link href="../web_scripts/date_picker/jquery-ui.theme.min.css" rel="stylesheet" type="text/css"/>
        <meta name="viewport" content="width=device-width, initial scale=1.0"/>
        <link rel="shortcut icon" href="../web_images/tab_icon.png" type="image/x-icon">

    </head>
    <body>
        <?php require_once './fin_book_details/balance_sheet.php'; ?>
        <div class="parts fin_details_box off">

        </div>
        <form action="new_journal_entry_line.php" method="post" enctype="multipart/form-data">
            <input type="hidden" id="txt_shall_expand_toUpdate" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim($_SESSION['table_to_update']) : '' ?>" />
            <!--this field  (shall_expand_toUpdate)above is for letting the form expand using js for updating-->
            <input type="hidden" id="txt_accountid_id"   name="txt_accountid_id"/>
            <input type="hidden" id="txt_journal_entry_header_id"   name="txt_journal_entry_header_id"/>

            <input type="hidden" id="txt_acc_type_id" style="float: right;"   name="txt_acc_type_id"/>
            <input type="hidden" id="txt_subacc_id" style="float: right;"   name="txt_subacc_id"/>
            <input type="hidden" id="txt_acc_class_id"   name="txt_acc_class_id"/>
            <!--when the opening balance is available the below fields are used-->
            <input type="hidden" id="txt_end_balance_id"   name="txt_end_balance_id"/>
            <input type="hidden" id="txt_end_date_id"   name="txt_end_date_id"/>
            <?php
                include 'admin_header.php';
            ?>
            <div class="parts eighty_centered  accept_abs no_paddin_shade_no_Border margin_free" >
                <div class="parts report_note no_paddin_shade_no_Border link_cursor off" data-bind="cash_flow_note"> </div>
                <div class="parts ninenty_centered heit_free no_paddin_shade_no_Border">
                    <table class="full_center_two_h heit_free margin_free">
                        <td><select class="cbo_rep_period_options">
                                <option>All</option>
                                <option>Today</option>
                                <option>This week</option>
                                <option>This week-to-date</option>
                                <option>This month</option>
                                <option>This month-to-date</option>
                                <option>This fiscal quarter</option>
                                <option>This fiscal quarter-to-date</option>
                                <option>This fiscal year</option>
                                <option>This fiscal year-to-Last Month</option>
                                <option>This fiscal year-to-date</option>
                                <option>Yesterday</option>
                                <option>Last week</option>
                                <option>Last week-to-date</option>
                                <option>Last month</option>
                                <option>Last month-to-date</option>
                                <option>Last fiscal quarter</option>
                                <option>Last fiscal quarter-to-date</option>
                                <option>Last Year</option>
                                <option>Last Year-to-date</option>
                            </select>
                        </td>  <td>Start date</td><td><input type="text" id="date1" value="<?php echo start_date(); ?>" class="textbox dates"></td>
                        <td>End date</td><td><input  type="text" id="date2" value="<?php echo end_date(); ?>" class="textbox dates"></td>
                        <td>
                            <select>
                                <option>Sort by</option>
                                <option>Type</option>
                                <option>Date</option>
                                <option>Num</option>
                                <option>Name</option>
                                <option>Memo</option>
                                <option>Amount</option>
                            </select> </td> <td></td>
                        <td><input type="button"  class="confirm_buttons btn_books_date" data-bind="cshfl" value="Search" style= "background-image: none;margin-top: 0px;"/> </td>
                    </table>
                </div>
                <?php
                    $other = new other_fx();
                    $min_date = $other->get_this_year_start_date();
                    $max_date = $other->get_this_year_end_date();
                    $tot_inc_exp = new other_fx();
                    $sum_cash_by_date = 0; //$other->get_account_balance('Cash_hand_bank', $min_date, $max_date);

                    $sum_assets = $other->get_account_balance('Fixed asset', $min_date, $max_date); // other than the fixed assets
                    $sum_acrud_exp = $other->get_account_balance('Accrued Expenses', $min_date, $max_date);
                    $sum_liability = $other->get_account_balance('Cash_hand_bank', $min_date, $max_date) + $sum_acrud_exp;
                    $equity = $sum_assets - $sum_liability;
                    $obj = new multi_values();

                    $sum_current_debt = $other->get_account_balance('Current portion of debt', $min_date, $max_date) * -1;
                    $sum_long_term_debt = $other->get_account_balance('Long term debt', $min_date, $max_date) * -1;
                    $sum_capital_stock_by_date = $other->get_account_balance('Share Capital', $min_date, $max_date) * -1;

                    // <editor-fold defaultstate="collapsed" desc="-------Net Result ---------">

                    $sum_income = $tot_inc_exp->get_account_balance('Sales revenue', $min_date, $max_date);
                    $tot_cogs = $other->get_account_balance('Cost Of Good Sold', $min_date, $max_date);
                    $sum_research_dev = $other->get_account_balance('Research and Development', $min_date, $max_date);
                    $gen_expenses = $other->get_account_balance('General & administrative', $min_date, $max_date);
                    $gen_other_expense = $other->get_account_balance('Other expense', $min_date, $max_date);
                    $sum_sales_marketing = $other->get_account_balance('Sales And Marketing', $min_date, $max_date);
                    $other_income = $other->get_account_balance('Other income', $min_date, $max_date);

                    $sum_disbursement = $sum_research_dev + $gen_expenses + $gen_other_expense + $sum_sales_marketing;

                    $gross_profit = $sum_income - $tot_cogs;
                    $tot_op_expense = $sum_income - $sum_disbursement; // these are the operating exp.
                    $sum_net_borrowing = $sum_long_term_debt + $sum_current_debt;

                    $sum_income_ope = $gross_profit - $tot_op_expense;
                    $sum_interest_income = $other->get_account_balance('Interest Income', $min_date, $max_date); //This is calculated by accountant manually
                    $sum_income_tax = $other->get_account_balance('Income Tax', $min_date, $max_date); //This is what calculated by accountant manually
                    $tot_net_income = $other->get_income_stmt_net();
                    $tot_tot_cashflow = $sum_income + $tot_op_expense - $sum_assets + $sum_net_borrowing - $sum_income_tax + $sum_capital_stock_by_date;
// </editor-fold>
                ?>
                <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border">
                    <div class="parts seventy_centered no_shade_noBorder ">
                        <div class=" parts full_center_two_h heit_free no_shade_noBorder  heit_free" style="font-size: 19px;">
                            <span style="font-weight: normal;"> Cash flow from</span> <?php echo $min_date . '  to  ' . $max_date ?>
                            <br/>
                        </div> 
                        <table class="income_table2">

                            <tr class="row_bold group_label ch_fl_cash">    <td>Beginning Cash balance</td><td><?php echo number_format($sum_cash_by_date); ?></td> </tr>
                            <tr class="row_bold group_label ch_fl_cash_receit">       <td>Cash receipt</td><td><?php echo number_format($sum_income); ?></td>                            </tr>
                            <tr class="row_bold row_underline group_label ch_fl_disbursemt"> <td>Cash disbursement</td><td><?php echo number_format($sum_disbursement); ?></td>                            </tr>
                            <tr class="row_bold"><td>CASH FROM OPERATIONS</td><td><?php echo number_format($sum_income_ope); ?></td>                            </tr>
                            <tr class="row_bold padding_top group_label ch_fl_fixed_asst">    <td>Fixed asset purchase</td><td><?php echo number_format($sum_assets); ?></td>                         </tr>
                            <tr class="row_bold group_label ch_fl_net_borow">           <td>Net borrowing</td><td><?php echo number_format($sum_net_borrowing); ?></td>                            </tr>
                            <tr class="row_bold group_label ch_fl_incom_tx">      <td>Income tax paid </td><td><?php echo number_format($sum_income_tax); ?></td>                           </tr>
                            <tr class="row_bold group_label ch_fl_sale_stock">      <td>Share capital</td><td><?php echo number_format($sum_capital_stock_by_date); ?></td>                            </tr>
                            <tr class="row_bold padding_top row_underline">       <td>ENDING CASH BALANCE</td><td><?php echo number_format($tot_tot_cashflow) ?></td>                            </tr>
                        </table>
                    </div>
                </div>
                <table class="dataList_table off">
                    <tr class="big_title"><td>Assets</td><td><?php echo number_format($sum_assets); ?></td></tr>  <?php ?><tr><td colspan="2">
                            <a href="#" style="color: #000080; text-decoration: none;">
                                <span class="details link_cursor"><div class="parts no_paddin_shade_no_Border full_center_two_h heit_free no_bg"> Details</div>
                                    <span class="off hidable full_center_two_h heit_free"> 
                                        <?php $other->list_assets(); ?>
                                    </span>
                                </span>
                            </a>
                        </td></tr>
                    <tr class="big_title"><td>Liability </td> <td><?php echo number_format($sum_liability); ?></td></tr>
                    <tr><td colspan="2"> 
                            <a href="#" style="color: #000080; text-decoration: none;">
                                <span class="details link_cursor"><div class="parts no_paddin_shade_no_Border full_center_two_h heit_free no_bg"> Details</div>
                                    <span class="off hidable full_center_two_h heit_free"> 
                                        <?php $other->list_liabilities(); ?>
                                    </span>
                                </span>
                            </a>
                        </td><?php ?></tr>
                    <tr class="big_title">
                        <td>Equity</td>
                        <td><?php echo (number_format($equity) < 1) ? '<span class="red_text">' . number_format($equity) . '</span>' : number_format($equity); ?></td>
                    </tr>
                </table>
            </div>  
        </form>
        <div class="parts eighty_centered  no_paddin_shade_no_Border no_shade_noBorder check_loaded" >
            <?php require_once './navigation/add_nav.php'; ?> 
        </div>
        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="admin_script.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
        <script src="../web_scripts/date_picker/jquery-ui.js" type="text/javascript"></script>
        <script src="../web_scripts/date_picker/jquery-ui.min.js" type="text/javascript"></script>
        <script src="../web_scripts/hide_headers.js" type="text/javascript"></script>
        <script>
            $('#ending_date,#date1,#date2,  .dates').datepicker({
                dataFormat: 'yy-mm-dd'
            });
            $('#ending_date, .dates').datepicker({
                dateFormat: 'yy-mm-dd'
            });
            //Here are the default(Set this year start date and the its ending date)
            var d = new Date();
            var month = 1;
            var day = 1;
            var output = d.getFullYear() + '-' +
                    (month < 10 ? '0' : '') + month + '-' + (day < 10 ? '0' : '') + day;
//            $('#date1').val(output);

            //The second date
            var month2 = d.getMonth() + 1;
            var day2 = d.getDate();
            var output2 = d.getFullYear() + '-' + (month2 < 10 ? '0' : '') + month2 + '-' +
                    (day2 < 10 ? '0' : '') + day2;

//            $('#date2').val(output2);
        </script>
    </body>
</hmtl>
<?php

    function start_date() {
        $m = new other_fx();
        return $m->get_this_year_start_date();
    }

    function end_date() {
        $m = new other_fx();
        return $m->get_this_year_end_date();
    }

    function get_acc_combo() {
        $obj = new multi_values();
        $obj->get_account_in_combo();
    }

    function chosen_name_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'account') {
                $id = $_SESSION['id_upd'];
                $name = new multi_values();
                return $name->get_chosen_account_name($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function get_parties_in_combo() {
        $obj = new other_fx();
        $obj->get_vendors_suppliers_in_combo_array();
    }

    function get_account_in_combo() {
        $obj = new other_fx();
        $obj->get_account_in_combo_array();
    }

    function get_journal_entry_header_combo() {
        $obj = new multi_values();
        $obj->get_journal_entry_header_in_combo();
    }

    function chosen_accountid_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'journal_entry_line') {
                $id = $_SESSION['id_upd'];
                $accountid = new multi_values();
                return $accountid->get_chosen_journal_entry_line_accountid($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_dr_cr_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'journal_entry_line') {
                $id = $_SESSION['id_upd'];
                $dr_cr = new multi_values();
                return $dr_cr->get_chosen_journal_entry_line_dr_cr($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_amount_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'journal_entry_line') {
                $id = $_SESSION['id_upd'];
                $amount = new multi_values();
                return $amount->get_chosen_journal_entry_line_amount($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_memo_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'journal_entry_line') {
                $id = $_SESSION['id_upd'];
                $memo = new multi_values();
                return $memo->get_chosen_journal_entry_line_memo($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_journal_entry_header_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'journal_entry_line') {
                $id = $_SESSION['id_upd'];
                $journal_entry_header = new multi_values();
                return $journal_entry_header->get_chosen_journal_entry_line_journal_entry_header($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function send_journal() {
        if (isset($_POST['send_journal'])) {
            require_once '../web_db/new_values.php';
            $debit = $_POST['txt_debit'];
            $credit = $_POST['txt_credit'];
            $memos = $_POST['txt_memo'];
            $all_debit = 0;
            $all_credit = 0;
            $amnt_debt = 0;
            $amnt_crdt = 0;
            //get sums
            $sum_debt = 0;
            $sum_crdt = 0;
            $account = $_POST['acc_name_combo'];

            foreach ($debit as $dbt) {
                $sum_debt += $dbt;
            }
            foreach ($credit as $crdt) {
                $sum_crdt += $crdt;
            }
            if ($sum_debt != $sum_crdt) {
                ?><script>alert('The credit side is not equal debit side');</script><?php
            } else {
                foreach ($account as $acc) {
                    if (!empty($acc)) {
                        foreach ($debit as $dbt) {
                            if (!empty($dbt)) {
                                $all_debit += 1;
                                $amnt_debt += $dbt;
                                $newobj = new new_values();
                            }
                            break;
                        }
                        foreach ($credit as $crdt) {
                            if (!empty($crdt)) {
                                $amnt_crdt += $crdt;
                                $all_credit += 1;
                                $newobj = new new_values();
                            } break;
                        }
                        foreach ($memos as $memo) {
                            if (!empty($memo)) {
                                
                            }
                            break;
                        }
                        $newobj->new_journal_entry_line($acc, 0, $amnt_crdt, $memo, 0);
                        echo 'Account: ' . $acc . '  Debit side: ' . $sum_crdt . ' Credit side: ' . $sum_debt . '   <br/>';
                    }
                }
            }
        }
    }
    
<!--Start delete  dialog's-->
<div class="parts   any_full_bg off">

</div>

<div class="parts abs_full y_n_dialog off fullwith_bg">
    <div class="parts dialog_yes_no no_paddin_shade_no_Border reverse_border off">
        <div class="parts full_center_two_h heit_free margin_free pane_title skin">
            Do you really want to delete this record?
        </div>
        <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border  top_off_x margin_free">
            <div class="parts yes_no_btns no_shade_noBorder reverse_border  link_cursor yes_dlg_btn">Yes</div>
            <div class="parts yes_no_btns no_shade_noBorder reverse_border  link_cursor no_dlg_btn">No</div>
        </div>
    </div>
</div>   
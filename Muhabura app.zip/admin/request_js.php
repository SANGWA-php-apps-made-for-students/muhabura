<?php

/**
 * Description of request_js
 *
 * @author SANGWA
 */
?>

<script>
    $(document).ready(function () {

        $('.item_txt_qty').keydown(function (e) {
            $('.journal_entry_table > .item_txt_qty').css('background-color:', 'blue');
            if (e.which === 9) {
                var my_index = $(this).parent().index() + 1;
                var closst = $(this).closest('tr').index() + 1;
            }
        });
        $('.item_txt_amnt').focus(function () {
            var item = $(this).val();
            // alert('Got focus: ' + item  );
            return false;
        });

        $('.save_request').click(function () {
            var the_field = $('.cbo_field option:selected').val();
            var unit_c = '';
            $('.bgt_txt_unitC').each(function () {
                unit_c += $(this).val();
            });
            if (the_field == '') {
                $('.warn_msg').show();
                $('html, body').animate({scrollTop: 10}, 500);
                return false;
            } else if ($('.cbo_acti_by_proj option:selected').val() == '') {
                $('html, body').animate({scrollTop: 10}, 500);
                $('.warn_msg').show().html('You have to choose the project').append('<a href="#" id="help_link" onclick="help_click()">Help</a>');
                return false;
            }

            //      else if ($('#activity_tot option:selected').val() == '') {
            //     $('html, body').animate({scrollTop: 10}, 500);
            //     $('.warn_msg').show().html('You have to choose the activity');
            //      } 
            else if (unit_c < 1) {
                $('html, body').animate({scrollTop: 10}, 500);
                $('.warn_msg').show().html('You have not entered any amount in the form, First enter some');
                return false;
            } else if ($('#txt_shall_expand_toUpdate').val() != '') {//When is to update
                var c = 0;
                $('.load_in_center').fadeIn(100);
                $('.cbo_items').each(function (index, value) {
                    if ($(this).val() != '') {
                        try {
                            //                                                            alert('Now updating these' + $(this).val() + ' and request; ' + $(this).children('span').html());
                            var update_whole_reques = $(this).children('span').html().trim();
                            var item = $('.cbo_items:eq(' + c + ')').val();
                            var measurement = $('.bgt_txt_msrment:eq(' + c + ')').val();
                            var unic = $('.bgt_txt_unitC:eq(' + c + ')').val();
                            var qty = $('.item_txt_qty:eq(' + c + ')').val();
                            var amount = $('.item_txt_amnt:eq(' + c + ')').val();
                            var field = $('.cbo_field:eq(' + c + ')').val();
                            //Save all the request items
                            $.post('handler.php', {field: field, amount: amount, qty: qty, unic: unic, measurement: measurement, item: item, update_whole_reques: update_whole_reques}, function (data) {

                            }).complete(function () {
                                //                                                                cancel the update session 
                                unset_update_session();
                            });
                        } catch (err) {
                            alert(err.message);
                        }
                    } else {
                        return;
                    }
                    c += 1;
                });
                $('.load_in_center').fadeOut(100);

                return false;
            } else {
                $('.warn_msg').hide().html('');
                return true;
            }

        }
        );
        function help_click() {
            $('#help_click').click(function () {
                alert('Clicked the help button');
                return false;
            });

        }
    });
</script>   
 <?php

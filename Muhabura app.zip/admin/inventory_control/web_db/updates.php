<?php

    require_once 'connection.php';

    class updates {

        function update_account($account_category, $date_created, $profile, $username, $password, $is_online, $account_id) {
            $database = new dbconnection();
            $db = $database->openconnection();
            $stmt = $db->prepare("UPDATE account set 
account_category= ?, date_created= ?, profile= ?, username= ?, password= ?, is_online= ? WHERE account_id=?");
            $stmt->execute(array($account_category, $date_created, $profile, $username, $password, $is_online, $account_id));
        }

        function update_account_category($name, $account_category_id) {
            $database = new dbconnection();
            $db = $database->openconnection();
            $stmt = $db->prepare("UPDATE account_category set 
name= ? WHERE account_category_id=?");
            $stmt->execute(array($name, $account_category_id));
        }

        function update_profile($dob, $name, $last_name, $gender, $telephone_number, $email, $residence, $image, $profile_id) {
            $database = new dbconnection();
            $db = $database->openconnection();
            $stmt = $db->prepare("UPDATE profile set 
dob= ?, name= ?, last_name= ?, gender= ?, telephone_number= ?, email= ?, residence= ?, image= ? WHERE profile_id=?");
            $stmt->execute(array($dob, $name, $last_name, $gender, $telephone_number, $email, $residence, $image, $profile_id));
        }

        function update_image($path, $image_id) {
            $database = new dbconnection();
            $db = $database->openconnection();
            $stmt = $db->prepare("UPDATE image set 
path= ? WHERE image_id=?");
            $stmt->execute(array($path, $image_id));
        }

        function update_main_stock($item, $quantity, $available_qty, $in_or_out, $measurement, $entry_date, $User, $main_stock_id) {
            $database = new dbconnection();
            $db = $database->openconnection();
            $stmt = $db->prepare("UPDATE main_stock set item= ?, quantity= ?, available_qty= ?, in_or_out= ?, measurement= ?, entry_date= ?, User= ? WHERE main_stock_id=?");
            $stmt->execute(array($item, $quantity, $available_qty, $in_or_out, $measurement, $entry_date, $User, $main_stock_id));
        }

        function update_main_stock_qty($available_qty, $itemid) {
            $database = new dbconnection();
            $db = $database->openconnection();
            $stmt = $db->prepare("UPDATE main_stock set  available_qty= ? WHERE item=?");
            $stmt->execute(array($available_qty, $itemid));
        }

        function update_distriibution($source_stock, $destination_stock, $taken_qty, $item, $remaining_qty, $entry_date, $User, $distriibution_id) {
            $database = new dbconnection();
            $db = $database->openconnection();
            $stmt = $db->prepare("UPDATE distriibution set 
source_stock= ?, destination_stock= ?, taken_qty= ?, item= ?, remaining_qty= ?, entry_date= ?, User= ? WHERE distriibution_id=?");
            $stmt->execute(array($source_stock, $destination_stock, $taken_qty, $item, $remaining_qty, $entry_date, $User, $distriibution_id));
        }

        function update_returns($source_stock, $destination_stock, $item, $remaining_qty, $entry_date, $User, $returns_id) {
            $database = new dbconnection();
            $db = $database->openconnection();
            $stmt = $db->prepare("UPDATE returns set 
source_stock= ?, destination_stock= ?, item= ?, remaining_qty= ?, entry_date= ?, User= ? WHERE returns_id=?");
            $stmt->execute(array($source_stock, $destination_stock, $item, $remaining_qty, $entry_date, $User, $returns_id));
        }

        function update_small_stock($quantity, $available_qty, $in_or_out, $measurement, $item, $entry_date, $User, $small_stock_id) {
            $database = new dbconnection();
            $db = $database->openconnection();
            $stmt = $db->prepare("UPDATE small_stock set quantity= ?, available_qty= ?, in_or_out= ?, measurement= ?, item= ?, entry_date= ?, User= ? WHERE small_stock_id=?");
            $stmt->execute(array($quantity, $available_qty, $in_or_out, $measurement, $item, $entry_date, $User, $small_stock_id));
        }

        function update_qty_small_stock($available_qty, $item, $stock) {
            $database = new dbconnection();
            $db = $database->openconnection();
            $stmt = $db->prepare("UPDATE smal_stock_status set    qunantity= ? WHERE item=? and smal_stock_status.stock=?");
            $stmt->execute(array($available_qty, $item, $stock));
        }

        function update_stock_taking($item, $quantity, $entry_date, $User, $available_quantity, $in_or_out, $measurement, $stock_taking_id) {
            $database = new dbconnection();
            $db = $database->openconnection();
            $stmt = $db->prepare("UPDATE stock_taking set 
item= ?, quantity= ?, entry_date= ?, User= ?, available_quantity= ?, in_or_out= ?, measurement= ? WHERE stock_taking_id=?");
            $stmt->execute(array($item, $quantity, $entry_date, $User, $available_quantity, $in_or_out, $measurement, $stock_taking_id));
        }

        function update_ditribution_small_stock($source_stock, $destination_stock, $taken_quantity, $item, $remaining_qty, $entry_date, $User, $ditribution_small_stock_id) {
            $database = new dbconnection();
            $db = $database->openconnection();
            $stmt = $db->prepare("UPDATE ditribution_small_stock set 
source_stock= ?, destination_stock= ?, taken_quantity= ?, item= ?, remaining_qty= ?, entry_date= ?, User= ? WHERE ditribution_small_stock_id=?");
            $stmt->execute(array($source_stock, $destination_stock, $taken_quantity, $item, $remaining_qty, $entry_date, $User, $ditribution_small_stock_id));
        }

        function update_p_budget_items($item_name, $description, $created_by, $entry_date, $chart_account, $p_budget_items_id) {
            $database = new dbconnection();
            $db = $database->openconnection();
            $stmt = $db->prepare("UPDATE p_budget_items set 
item_name= ?, description= ?, created_by= ?, entry_date= ?, chart_account= ? WHERE p_budget_items_id=?");
            $stmt->execute(array($item_name, $description, $created_by, $entry_date, $chart_account, $p_budget_items_id));
        }

        function update_measurement($code, $description, $measurement_id) {
            $database = new dbconnection();
            $db = $database->openconnection();
            $stmt = $db->prepare("UPDATE measurement set 
code= ?, description= ? WHERE measurement_id=?");
            $stmt->execute(array($code, $description, $measurement_id));
        }

        function update_smal_stock_status($item, $quantity, $stock, $smal_stock_status_id) {
            $database = new dbconnection();
            $db = $database->openconnection();
            $stmt = $db->prepare("UPDATE smal_stock_status set item= ?, quantity= ?, stock= ? WHERE smal_stock_status_id=?");
            $stmt->execute(array($item, $quantity, $stock, $smal_stock_status_id));
        }

        function update_smal_stock_status_qty($quantity, $stock, $item) {
            $database = new dbconnection();
            $db = $database->openconnection();
            $stmt = $db->prepare("UPDATE smal_stock_status set  quantity= ? WHERE  stock= ? and item=?");
            $stmt->execute(array($quantity, $stock, $item));
        }

    }
    
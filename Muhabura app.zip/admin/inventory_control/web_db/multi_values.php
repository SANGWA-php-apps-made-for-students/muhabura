<?php
    require_once '../web_db/connection.php';

    class multi_values {

        function list_stock_taking($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select stock_taking.stock_taking_id ,stock_taking.item,  stock_taking.quantity,  stock_taking.entry_date,  stock_taking.User,  stock_taking.available_quantity,  stock_taking.in_or_out,  stock_taking.measurement,p_budget_items.item_name as item, user.Firstname,user.Lastname from stock_taking "
                    . " join p_budget_items on p_budget_items.p_budget_items_id=stock_taking.item"
                    . " join user on user.StaffID=stock_taking.User ";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
            <table class="dataList_table">
                <thead><tr>
                        <td> S/N </td>
                        <td> Item </td><td> Quantity </td><td> Entry Date </td>
                        <td> User </td><td class="off"> Available_quantity </td>
                        <?php if (isset($_SESSION['shall_delete'])) { ?>  <td>Delete</td><td>Update</td><?php } ?></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['stock_taking_id']; ?>
                        </td>
                        <td class="item_id_cols stock_taking " title="stock_taking" >
                            <?php echo $this->_e($row['item']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['quantity']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['entry_date']); ?>
                        </td>
                        <td>
                            <?php
                            echo $this->_e($row['Firstname']) . '  ';
                            echo $row['Lastname'];
                            ?>
                        </td>
                        <td class="off">
                            <?php echo $this->_e($row['available_quantity']); ?>
                        </td>
                        <?php if (isset($_SESSION['shall_delete'])) { ?>
                            <td>
                                <a href="#" class="stock_taking_delete_link" style="color: #000080;" data-id_delete="stock_taking_id"  data-table="
                                   <?php echo $row['stock_taking_id']; ?>">Delete</a>
                            </td>
                            <td>
                                <a href="#" class="stock_taking_update_link" style="color: #000080;" value="
                                   <?php echo $row['stock_taking_id']; ?>">Update</a>
                            </td><?php } ?></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

//chosen individual field

            function get_chosen_stock_taking_quantity($id) {

                $db = new dbconnection();
                $sql = "select   stock_taking.quantity from stock_taking where stock_taking_id=:stock_taking_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':stock_taking_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['quantity'];
                echo $field;
            }

            function get_chosen_stock_taking_entry_date($id) {

                $db = new dbconnection();
                $sql = "select   stock_taking.entry_date from stock_taking where stock_taking_id=:stock_taking_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':stock_taking_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['entry_date'];
                echo $field;
            }

            function get_chosen_stock_taking_User($id) {

                $db = new dbconnection();
                $sql = "select   stock_taking.User from stock_taking where stock_taking_id=:stock_taking_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':stock_taking_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['User'];
                echo $field;
            }

            function get_chosen_stock_taking_available_quantity($id) {

                $db = new dbconnection();
                $sql = "select   stock_taking.available_quantity from stock_taking where stock_taking_id=:stock_taking_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':stock_taking_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['available_quantity'];
                echo $field;
            }

            function get_chosen_stock_taking_measurement($id) {

                $db = new dbconnection();
                $sql = "select   stock_taking.measurement from stock_taking where stock_taking_id=:stock_taking_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':stock_taking_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['measurement'];
                echo $field;
            }

            function All_stock_taking() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  stock_taking_id   from stock_taking";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_stock_taking() {
                $con = new dbconnection();
                $sql = "select stock_taking.stock_taking_id from stock_taking
                    order by stock_taking.stock_taking_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['stock_taking_id'];
                return $first_rec;
            }

            function get_last_stock_taking() {
                $con = new dbconnection();
                $sql = "select stock_taking.stock_taking_id from stock_taking
                    order by stock_taking.stock_taking_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['stock_taking_id'];
                return $first_rec;
            }

            function get_fisc_year_in_combo() {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select p_fiscal_year.p_fiscal_year_id,   p_fiscal_year.fiscal_year_name from p_fiscal_year";
                ?>
            <select class="textbox cbo_fisc_year"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['p_fiscal_year_id'] . ">" . $row['fiscal_year_name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_project_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select p_project.p_project_id,   p_project.name from p_project group by name";
            ?>
            <select class="textbox cbo_project"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['p_project_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_project_in_combo_refill() {// this one refils another combobox
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select p_project.p_project_id,   p_project.name from p_project group by name ";
            ?>
            <select class="textbox cbo_project cbo_proj_refill"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['p_project_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_item_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select p_budget_items.item_name,  p_budget_items.p_budget_items_id from p_budget_items ";
            ?>
            <select class="textbox cbo_item name "><option></option><option value="fly_new_p_budget_items"></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['p_budget_items_id'] . ">" . $row['item_name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_activity_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select p_activity.p_activity_id,   p_activity.name from p_activity group by p_activity.name";
            ?>
            <select class="textbox cbo_activity"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['p_activity_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_first_p_budget_prep() {
            $con = new dbconnection();
            $sql = "select p_budget_prep.p_budget_prep_id from p_budget_prep
                    order by p_budget_prep.p_budget_prep_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['p_budget_prep_id'];
            return $first_rec;
        }

        function get_first_p_budget() {
            $con = new dbconnection();
            $sql = "select p_budget.p_budget_id from p_budget
                    order by p_budget.p_budget_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['p_budget_id'];
            return $first_rec;
        }

        function list_p_request($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select p_request.p_request_id,  p_request.item,  p_request.quantity,  p_request.unit_cost,  p_request.amount,  p_request.entry_date,  p_request.User,  p_request.measurement,  p_request.request_no,user.Firstname,user.Lastname , p_budget_items.item_name as item"
                    . " from p_request "
                    . " join user on user.StaffiD=p_request.User "
                    . " join p_budget_items on p_budget_items.p_budget_items_id=p_request.item "
                    . " order by p_request.p_request_id asc";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
            <table class="dataList_table">
                <thead><tr>
                        <td> S/N </td>
                        <td> Item </td><td> Quantity </td><td> Unit Cost </td>
                        <td> Amount </td><td> Entry Date </td><td> User </td>
                        <td> Measurement </td><td class="off"> Request Number </td>
                        <?php if (isset($_SESSION['shall_delete'])) { ?>  <td>Delete</td><td>Update</td>
                        <?php } ?>  </tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['p_request_id']; ?>
                        </td>
                        <td class="item_id_cols p_request " title="p_request" >
                            <?php echo $this->_e($row['item']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['quantity']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['unit_cost']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['amount']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['entry_date']); ?>
                        </td>
                        <td>
                            <?php
                            echo $this->_e($row['Firstname']) . '  ';
                            echo $this->_e($row['Lastname'])
                            ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['measurement']); ?>
                        </td>
                        <td class="off">
                            <?php echo $this->_e($row['request_no']); ?>
                        </td>

                        <?php if (isset($_SESSION['shall_delete'])) { ?>
                            <td>
                                <a href="#" class="p_request_delete_link" style="color: #000080;" data-id_delete="p_request_id"  data-table="
                                   <?php echo $row['p_request_id']; ?>">Delete</a>
                            </td>
                            <td>
                                <a href="#" class="p_request_update_link" style="color: #000080;" value="
                                   <?php echo $row['p_request_id']; ?>">Update</a>
                            </td><?php } ?></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

            function get_first_journal_entry_line() {
                $con = new dbconnection();
                $sql = "select journal_entry_line.journal_entry_line_id from journal_entry_line
                    order by journal_entry_line.journal_entry_line_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['journal_entry_line_id'];
                return $first_rec;
            }

            function get_measurement_in_combo() {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select measurement.measurement_id, measurement.code from measurement";
                ?>
            <select class="textbox bgt_txt_msrment cbo_measurement cbo_onfly_measurement_change">
                <option></option>
                <option value="fly_new_measurement">--Add new--</option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value = " . $row['measurement_id'] . ">" . $row['code'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_chart_account_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select chart_account.chart_account_id,   chart_account.name from chart_account";
            ?>
            <select class="textbox cbo_chart_account cbo_accountid"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['chart_account_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_last_Main_Request() {
            $con = new dbconnection();
            $sql = "select Main_Request.Main_Request_id from Main_Request
                    order by Main_Request.Main_Request_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['Main_Request_id'];
            return $first_rec;
        }

        function _e($string) {
            echo htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
        }

//chosen individual field


        function All_stock_into_main() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  stock_into_main_id   from stock_into_main";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_stock_into_main() {
            $con = new dbconnection();
            $sql = "select stock_into_main.stock_into_main_id from stock_into_main
                    order by stock_into_main.stock_into_main_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['stock_into_main_id'];
            return $first_rec;
        }

        function get_last_stock_into_main() {
            $con = new dbconnection();
            $sql = "select stock_into_main.stock_into_main_id from stock_into_main
                    order by stock_into_main.stock_into_main_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['stock_into_main_id'];
            return $first_rec;
        }

        function list_stock_into_main($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from stock_into_main "
                    . " join p_budget_items on p_budget_items.p_budget_items_id=stock_into_main.item "
                    . " join user on user.StaffID=stock_into_main.User "
                    . " ";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
            <table class="dataList_table">
                <thead><tr>
                        <td> S/N </td>
                        <td> item </td><td> Quantity </td><td> Entry Date </td><td> User </td>
                        <?php if (isset($_SESSION['shall_delete'])) { ?> <td>Delete</td><td>Update</td><?php } ?></tr></thead>
                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['stock_into_main_id']; ?>
                        </td>
                        <td class="item_id_cols stock_into_main " title="stock_into_main" >
                            <?php echo $this->_e($row['item_name']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['quantity']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['entry_date']); ?>
                        </td>
                        <td>
                            <?php
                            echo $this->_e($row['Firstname']) . '  ';
                            echo $row['Lastname'];
                            ?>
                        </td>
                        <?php if (isset($_SESSION['shall_delete'])) { ?>                        <td>
                                <a href="#" class="stock_into_main_delete_link" style="color: #000080;" data-id_delete="stock_into_main_id"  data-table="
                                   <?php echo $row['stock_into_main_id']; ?>">Delete</a>
                            </td>
                            <td>
                                <a href="#" class="stock_into_main_update_link" style="color: #000080;" value="
                                   <?php echo $row['stock_into_main_id']; ?>">Update</a>
                            </td><?php } ?></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

            function get_account_in_combo_array() {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select account.account_id,   account.name, account_type.name as type from account"
                        . " join account_type on account.acc_type=account_type.account_type_id "
                        . "  group by account.name";
                ?>
            <select name="acc_name_com[]"  class="textbox cbo_account_arr">
                <option </option>
                <option value="new_item">-- Add New --</option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['account_id'] . ">" . $row['name'] . "      (<b>" . strtoupper($row['type']) . "</b>) </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_journal_entry_header_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select journal_entry_header.journal_entry_header_id, journal_entry_header.name from journal_entry_header";
            ?>
            <select class="textbox cbo_journal_entry_header"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value = " . $row['journal_entry_header_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_purchaseid() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select purchase_invoice.purchase_invoice ";
            ?>
            <select class="textbox cbo_chart_account cbo_accountid"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['chart_account_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_purchase_invoiceid_combo() {
            try {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $sql = " select purchase_invoice_line.purchase_invoice_line_id, purchase_invoice_line.quantity,  purchase_invoice_line.unit_cost,purchase_invoice_line.User,purchase_invoice_line.entry_date,  purchase_invoice_line.amount, p_budget_items.p_budget_items_id,  p_budget_items.item_name, user.Firstname,user.Lastname from purchase_invoice_line
                        join purchase_order_line on purchase_order_line.purchase_order_line_id=purchase_invoice_line.purchase_order
                        join p_request on  p_request.p_request_id = purchase_order_line.request 
                        join p_budget_items on p_budget_items.p_budget_items_id= p_request.item 
                        join user on user.StaffID=purchase_invoice_line.User
                        where purchase_invoice_line.purchase_invoice_line_id not in ( select stock_into_main.purchaseid from stock_into_main )";
                ?>
                <select class="textbox  name cbo_pur_invoice">
                    <option></option>
                    <option value="fly_new_p_budget_items"></option>
                    <?php
                    foreach ($db->query($sql) as $row) {
                        echo "<option value=" . $row['purchase_invoice_line_id'] . ">" . $row['purchase_invoice_line_id'] . " - " . $row['item_name'] . " (" . $row['Firstname'] . " " . $row['Lastname'] . ") on  (" . $row['entry_date'] . ") </option>";
                    }
                    ?>
                </select>
                <?php
            } catch (PDOException $e) {
                echo $e->getMessage();
            }
        }

        // <editor-fold defaultstate="collapsed" desc="---Inventory from outside ----">
        function list_account($min) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select * from account";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $min));
            ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> account </td>
                        <td>  </td><td>  </td><td>  </td><td>  </td><td>  </td><td>  </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['account_id']; ?>
                        </td>
                        <td class="account_category_id_cols account " title="account" >
                            <?php echo $this->_e($row['account_category']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['date_created']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['profile']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['username']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['password']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['is_online']); ?>
                        </td>


                        <td>
                            <a href="#" class="account_delete_link" style="color: #000080;" data-id_delete="account_id"  data-table="
                               <?php echo $row['account_id']; ?>">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="account_update_link" style="color: #000080;" value="
                               <?php echo $row['account_id']; ?>">Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

            //chosen individual field
            function get_chosen_account_account_category($id) {

                $db = new dbconnection();
                $sql = "select   account.account_category from account where account_id=:account_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':account_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['account_category'];
                echo $field;
            }

            function get_chosen_account_date_created($id) {

                $db = new dbconnection();
                $sql = "select   account.date_created from account where account_id=:account_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':account_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['date_created'];
                echo $field;
            }

            function get_chosen_account_profile($id) {

                $db = new dbconnection();
                $sql = "select   account.profile from account where account_id=:account_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':account_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['profile'];
                echo $field;
            }

            function get_chosen_account_username($id) {

                $db = new dbconnection();
                $sql = "select   account.username from account where account_id=:account_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':account_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['username'];
                echo $field;
            }

            function get_chosen_account_password($id) {

                $db = new dbconnection();
                $sql = "select   account.password from account where account_id=:account_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':account_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['password'];
                echo $field;
            }

            function get_chosen_account_is_online($id) {

                $db = new dbconnection();
                $sql = "select   account.is_online from account where account_id=:account_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':account_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['is_online'];
                echo $field;
            }

            function All_account() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  account_id   from account";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_account() {
                $con = new dbconnection();
                $sql = "select account.account_id from account
                    order by account.account_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['account_id'];
                return $first_rec;
            }

            function get_last_account() {
                $con = new dbconnection();
                $sql = "select account.account_id from account
                    order by account.account_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['account_id'];
                return $first_rec;
            }

            function list_account_category($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from account_category";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> account_category </td>
                        <td>  </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['account_category_id']; ?>
                        </td>
                        <td class="name_id_cols account_category " title="account_category" >
                            <?php echo $this->_e($row['name']); ?>
                        </td>


                        <td>
                            <a href="#" class="account_category_delete_link" style="color: #000080;" data-id_delete="account_category_id"  data-table="
                               <?php echo $row['account_category_id']; ?>">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="account_category_update_link" style="color: #000080;" value="
                               <?php echo $row['account_category_id']; ?>">Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

//chosen individual field
            function get_chosen_account_category_name($id) {

                $db = new dbconnection();
                $sql = "select   account_category.name from account_category where account_category_id=:account_category_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':account_category_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['name'];
                echo $field;
            }

            function All_account_category() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  account_category_id   from account_category";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_account_category() {
                $con = new dbconnection();
                $sql = "select account_category.account_category_id from account_category
                    order by account_category.account_category_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['account_category_id'];
                return $first_rec;
            }

            function get_last_account_category() {
                $con = new dbconnection();
                $sql = "select account_category.account_category_id from account_category
                    order by account_category.account_category_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['account_category_id'];
                return $first_rec;
            }

            function list_profile($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from profile";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> profile </td>
                        <td>  </td><td>  </td><td>  </td><td>  </td><td>  </td><td>  </td><td>  </td><td>  </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['profile_id']; ?>
                        </td>
                        <td class="dob_id_cols profile " title="profile" >
                            <?php echo $this->_e($row['dob']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['name']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['last_name']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['gender']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['telephone_number']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['email']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['residence']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['image']); ?>
                        </td>


                        <td>
                            <a href="#" class="profile_delete_link" style="color: #000080;" data-id_delete="profile_id"  data-table="
                               <?php echo $row['profile_id']; ?>">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="profile_update_link" style="color: #000080;" value="
                               <?php echo $row['profile_id']; ?>">Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

//chosen individual field
            function get_chosen_profile_dob($id) {

                $db = new dbconnection();
                $sql = "select   profile.dob from profile where profile_id=:profile_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':profile_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['dob'];
                echo $field;
            }

            function get_chosen_profile_name($id) {

                $db = new dbconnection();
                $sql = "select   profile.name from profile where profile_id=:profile_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':profile_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['name'];
                echo $field;
            }

            function get_chosen_profile_last_name($id) {

                $db = new dbconnection();
                $sql = "select   profile.last_name from profile where profile_id=:profile_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':profile_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['last_name'];
                echo $field;
            }

            function get_chosen_profile_gender($id) {

                $db = new dbconnection();
                $sql = "select   profile.gender from profile where profile_id=:profile_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':profile_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['gender'];
                echo $field;
            }

            function get_chosen_profile_telephone_number($id) {

                $db = new dbconnection();
                $sql = "select   profile.telephone_number from profile where profile_id=:profile_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':profile_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['telephone_number'];
                echo $field;
            }

            function get_chosen_profile_email($id) {

                $db = new dbconnection();
                $sql = "select   profile.email from profile where profile_id=:profile_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':profile_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['email'];
                echo $field;
            }

            function get_chosen_profile_residence($id) {

                $db = new dbconnection();
                $sql = "select   profile.residence from profile where profile_id=:profile_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':profile_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['residence'];
                echo $field;
            }

            function get_chosen_profile_image($id) {

                $db = new dbconnection();
                $sql = "select   profile.image from profile where profile_id=:profile_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':profile_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['image'];
                echo $field;
            }

            function All_profile() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  profile_id   from profile";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_profile() {
                $con = new dbconnection();
                $sql = "select profile.profile_id from profile
                    order by profile.profile_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['profile_id'];
                return $first_rec;
            }

            function get_last_profile() {
                $con = new dbconnection();
                $sql = "select profile.profile_id from profile
                    order by profile.profile_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['profile_id'];
                return $first_rec;
            }

            function list_image($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from image";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> image </td>
                        <td>  </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['image_id']; ?>
                        </td>
                        <td class="path_id_cols image " title="image" >
                            <?php echo $this->_e($row['path']); ?>
                        </td>


                        <td>
                            <a href="#" class="image_delete_link" style="color: #000080;" data-id_delete="image_id"  data-table="
                               <?php echo $row['image_id']; ?>">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="image_update_link" style="color: #000080;" value="
                               <?php echo $row['image_id']; ?>">Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

//chosen individual field
            function get_chosen_image_path($id) {

                $db = new dbconnection();
                $sql = "select   image.path from image where image_id=:image_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':image_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['path'];
                echo $field;
            }

            function All_image() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  image_id   from image";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_image() {
                $con = new dbconnection();
                $sql = "select image.image_id from image
                    order by image.image_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['image_id'];
                return $first_rec;
            }

            function get_last_image() {
                $con = new dbconnection();
                $sql = "select image.image_id from image
                    order by image.image_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['image_id'];
                return $first_rec;
            }

            function list_main_stock($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select   main_stock.main_stock_id,  main_stock.item,  main_stock.quantity,  main_stock.available_qty,  main_stock.in_or_out,  main_stock.measurement,  main_stock.entry_date,  main_stock.User,p_budget_items.item_name as item,user.Firstname,user.Lastname,main_stock.unit_cost,main_stock.total_amount "
                        . " from main_stock "
                        . " join p_budget_items on p_budget_items.p_budget_items_id=main_stock.item  "
                        . " join user on user.StaffID=main_stock.User "
                        . " ";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead>
                    <tr>
                        <td> S/N </td>
                        <td> Item </td>
                        <td> Added Quantity </td>
                        <td> Unit Cost </td>
                        <td> Amount </td> 
                        <td> available quantity </td>

                        <td class="off"> In Or Out </td>
                        <td class="off"> Measurement </td>
                        <td> Entry Date </td>
                        <td> User </td>
                        <?php if (isset($_SESSION['shall_delete'])) { ?>  <td>Delete</td>
                            <td>Update</td><?php } ?>
                    </tr>
                </thead>
                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 
                        <td>
                            <?php echo $row['main_stock_id']; ?>
                        </td>
                        <td class="item_id_cols main_stock " title="main_stock" >
                            <?php echo $this->_e($row['item']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['quantity']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['unit_cost']); ?>
                        </td>   <td>
                            <?php echo $this->_e(number_format($row['total_amount'])); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['available_qty']); ?>
                        </td>



                        <td class="off">
                            <?php echo $this->_e($row['in_or_out']); ?>
                        </td>
                        <td class="off">
                            <?php echo $this->_e($row['measurement']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['entry_date']); ?>
                        </td>
                        <td>
                            <?php
                            echo $this->_e($row['Firstname']) . ' ';
                            echo $row['Lastname'];
                            ?>
                        </td>
                        <?php if (isset($_SESSION['shall_delete'])) { ?>  <td>
                                <a href="#" class="main_stock_delete_link" style="color: #000080;" data-id_delete="main_stock_id"  data-table="
                                   <?php echo $row['main_stock_id']; ?>">Delete</a>
                            </td>
                            <td>
                                <a href="#" class="main_stock_update_link" style="color: #000080;" value="
                                   <?php echo $row['main_stock_id']; ?>">Update</a>
                            </td><?php } ?></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

//chosen individual field
            function get_chosen_main_stock_item($id) {

                $db = new dbconnection();
                $sql = "select   main_stock.item from main_stock where main_stock_id=:main_stock_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':main_stock_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['item'];
                echo $field;
            }

            function get_chosen_main_stock_quantity($id) {

                $db = new dbconnection();
                $sql = "select   main_stock.quantity from main_stock where main_stock_id=:main_stock_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':main_stock_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['quantity'];
                echo $field;
            }

            function get_chosen_main_stock_available_qty($id) {

                $db = new dbconnection();
                $sql = "select   main_stock.available_qty from main_stock where main_stock_id=:main_stock_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':main_stock_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['available_qty'];
                echo $field;
            }

            function get_chosen_main_stock_in_or_out($id) {

                $db = new dbconnection();
                $sql = "select   main_stock.in_or_out from main_stock where main_stock_id=:main_stock_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':main_stock_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['in_or_out'];
                echo $field;
            }

            function get_chosen_main_stock_measurement($id) {

                $db = new dbconnection();
                $sql = "select   main_stock.measurement from main_stock where main_stock_id=:main_stock_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':main_stock_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['measurement'];
                echo $field;
            }

            function get_chosen_main_stock_entry_date($id) {

                $db = new dbconnection();
                $sql = "select   main_stock.entry_date from main_stock where main_stock_id=:main_stock_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':main_stock_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['entry_date'];
                echo $field;
            }

            function get_chosen_main_stock_User($id) {

                $db = new dbconnection();
                $sql = "select   main_stock.User from main_stock where main_stock_id=:main_stock_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':main_stock_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['User'];
                echo $field;
            }

            function All_main_stock() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  main_stock_id   from main_stock";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_main_stock() {
                $con = new dbconnection();
                $sql = "select main_stock.main_stock_id from main_stock
                    order by main_stock.main_stock_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['main_stock_id'];
                return $first_rec;
            }

            function get_last_main_stock() {
                $con = new dbconnection();
                $sql = "select main_stock.main_stock_id from main_stock
                    order by main_stock.main_stock_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['main_stock_id'];
                return $first_rec;
            }

            function list_distriibution($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select distriibution.distriibution_id,  distriibution.source_stock, small_stock.name as destination_stock,  distriibution.taken_qty,  distriibution.item,  distriibution.remaining_qty,  distriibution.entry_date,  distriibution.User,p_budget_items.item_name as item,user.Firstname,user.Lastname from distriibution "
                        . "  "
                        . "join small_stock on small_stock.small_stock_id=distriibution.destination_stock "
                        . " join p_budget_items on p_budget_items.p_budget_items_id= distriibution.item "
                        . " join user on user.StaffID=distriibution.User order by distriibution.distriibution_id asc";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> S/N </td>
                        <td> Source Stock </td><td> Destination Stock </td><td> Taken Quantity </td><td> Item </td><td> Remaining Quantity </td><td> Entry Date </td><td> User </td>
                        <?php if (isset($_SESSION['shall_delete'])) { ?> <td>Delete</td><td>Update</td><?php } ?></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['distriibution_id']; ?>
                        </td>
                        <td class="source_stock_id_cols distriibution " title="distriibution" >
                            <?php echo 'Muhabura' ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['destination_stock']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['taken_qty']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['item']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['remaining_qty']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['entry_date']); ?>
                        </td>
                        <td>
                            <?php
                            echo $this->_e($row['Firstname']) . ' ';
                            echo $row['Lastname'];
                            ?>
                        </td>

                        <?php if (isset($_SESSION['shall_delete'])) { ?>
                            <td>
                                <a href="#" class="distriibution_delete_link" style="color: #000080;" data-id_delete="distriibution_id"  data-table="
                                   <?php echo $row['distriibution_id']; ?>">Delete</a>
                            </td>
                            <td>
                                <a href="#" class="distriibution_update_link" style="color: #000080;" value="
                                   <?php echo $row['distriibution_id']; ?>">Update</a>
                            </td><?php } ?></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

//chosen individual field
            function get_chosen_distriibution_source_stock($id) {

                $db = new dbconnection();
                $sql = "select   distriibution.source_stock from distriibution where distriibution_id=:distriibution_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':distriibution_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['source_stock'];
                echo $field;
            }

            function get_chosen_distriibution_destination_stock($id) {

                $db = new dbconnection();
                $sql = "select   distriibution.destination_stock from distriibution where distriibution_id=:distriibution_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':distriibution_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['destination_stock'];
                echo $field;
            }

            function get_chosen_distriibution_taken_qty($id) {

                $db = new dbconnection();
                $sql = "select   distriibution.taken_qty from distriibution where distriibution_id=:distriibution_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':distriibution_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['taken_qty'];
                echo $field;
            }

            function get_chosen_distriibution_item($id) {

                $db = new dbconnection();
                $sql = "select   distriibution.item from distriibution where distriibution_id=:distriibution_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':distriibution_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['item'];
                echo $field;
            }

            function get_chosen_distriibution_remaining_qty($id) {

                $db = new dbconnection();
                $sql = "select   distriibution.remaining_qty from distriibution where distriibution_id=:distriibution_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':distriibution_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['remaining_qty'];
                echo $field;
            }

            function get_chosen_distriibution_entry_date($id) {

                $db = new dbconnection();
                $sql = "select   distriibution.entry_date from distriibution where distriibution_id=:distriibution_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':distriibution_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['entry_date'];
                echo $field;
            }

            function get_chosen_distriibution_User($id) {

                $db = new dbconnection();
                $sql = "select   distriibution.User from distriibution where distriibution_id=:distriibution_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':distriibution_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['User'];
                echo $field;
            }

            function All_distriibution() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  distriibution_id   from distriibution";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_distriibution() {
                $con = new dbconnection();
                $sql = "select distriibution.distriibution_id from distriibution
                    order by distriibution.distriibution_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['distriibution_id'];
                return $first_rec;
            }

            function get_last_distriibution() {
                $con = new dbconnection();
                $sql = "select distriibution.distriibution_id from distriibution
                    order by distriibution.distriibution_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['distriibution_id'];
                return $first_rec;
            }

            function list_returns() {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  returns.returns_id, small_stock.name as source_stock, returns.remaining_qty,  returns.destination_stock,  p_budget_items.item_name as item,  returns.entry_date,  returns.User, user.Firstname,user.Lastname from returns "
                        . " join small_stock on small_stock.small_stock_id=returns.source_stock "
                        . " join p_budget_items on p_budget_items.p_budget_items_id=returns.item "
                        . "join user on user.StaffID=returns.User ";
                $stmt = $db->prepare($sql);
                $stmt->execute();
                ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> S/N </td>
                        <td> Source Stock </td><td> Destination Stock </td><td> Item </td><td> Remaining Quantity </td><td> Entry Date </td><td> User </td>
                        <?php if (isset($_SESSION['shall_delete'])) { ?> <td>Delete</td><td>Update</td><?php } ?></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['returns_id']; ?>
                        </td>
                        <td class="source_stock_id_cols returns " title="returns" >
                            <?php echo $this->_e($row['source_stock']); ?>
                        </td>
                        <td>
                            <?php echo 'MUHABURA' ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['item']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['remaining_qty']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['entry_date']); ?>
                        </td>
                        <td>
                            <?php
                            echo $this->_e($row['Firstname']) . ' ';
                            echo $row['Lastname'];
                            ?>
                        </td>

                        <?php if (isset($_SESSION['shall_delete'])) { ?>
                            <td>
                                <a href="#" class="returns_delete_link" style="color: #000080;" data-id_delete="returns_id"  data-table="
                                   <?php echo $row['returns_id']; ?>">Delete</a>
                            </td>
                            <td>
                                <a href="#" class="returns_update_link" style="color: #000080;" value="
                                   <?php echo $row['returns_id']; ?>">Update</a>
                            </td><?php } ?></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

//chosen individual field
            function get_chosen_returns_source_stock($id) {

                $db = new dbconnection();
                $sql = "select   returns.source_stock from returns where returns_id=:returns_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':returns_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['source_stock'];
                echo $field;
            }

            function get_chosen_returns_destination_stock($id) {

                $db = new dbconnection();
                $sql = "select   returns.destination_stock from returns where returns_id=:returns_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':returns_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['destination_stock'];
                echo $field;
            }

            function get_chosen_returns_item($id) {

                $db = new dbconnection();
                $sql = "select   returns.item from returns where returns_id=:returns_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':returns_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['item'];
                echo $field;
            }

            function get_chosen_returns_remaining_qty($id) {

                $db = new dbconnection();
                $sql = "select   returns.remaining_qty from returns where returns_id=:returns_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':returns_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['remaining_qty'];
                echo $field;
            }

            function get_chosen_returns_entry_date($id) {

                $db = new dbconnection();
                $sql = "select   returns.entry_date from returns where returns_id=:returns_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':returns_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['entry_date'];
                echo $field;
            }

            function get_chosen_returns_User($id) {

                $db = new dbconnection();
                $sql = "select   returns.User from returns where returns_id=:returns_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':returns_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['User'];
                echo $field;
            }

            function All_returns() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  returns_id   from returns";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_returns() {
                $con = new dbconnection();
                $sql = "select returns.returns_id from returns
                    order by returns.returns_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['returns_id'];
                return $first_rec;
            }

            function get_last_returns() {
                $con = new dbconnection();
                $sql = "select returns.returns_id from returns
                    order by returns.returns_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['returns_id'];
                return $first_rec;
            }

            function list_small_stock($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  small_stock.small_stock_id,  small_stock.quantity, small_stock.location, small_stock.available_qty,  small_stock.in_or_out,  small_stock.measurement,  small_stock.item,  small_stock.entry_date,  small_stock.User,  small_stock.name,user.Firstname,user.Lastname from small_stock "
                        . "join user on user.StaffID=small_stock.User "
                        . "  ";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table full_center_two_h heit_free">
                <thead><tr>
                        <td> S/N </td>
                        <td> Location</td>
                        <td class="off"> Quantity </td>
                        <td class="off"> Available quantity </td>
                        <td class="off"> In Or Out </td>
                        <td class="off"> Measurement </td>
                        <td class="off"> Item </td>
                        <td> Date Created</td>
                        <td> User </td>
                        <?php if (isset($_SESSION['shall_delete'])) { ?> <td>Delete</td><td>Update</td><?php } ?></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['small_stock_id']; ?>
                        </td>
                        <td>
                            <?php echo $row['location']; ?>
                        </td>
                        <td class="off quantity_id_cols small_stock " title="small_stock" >
                            <?php echo $this->_e($row['quantity']); ?>
                        </td>
                        <td class="off">
                            <?php echo $this->_e($row['available_qty']); ?>
                        </td>
                        <td class="off">
                            <?php echo $this->_e($row['in_or_out']); ?>
                        </td>
                        <td class="off">
                            <?php echo $this->_e($row['measurement']); ?>
                        </td>
                        <td class="off">
                            <?php echo $this->_e($row['item']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['entry_date']); ?>
                        </td>
                        <td>
                            <?php
                            echo $this->_e($row['Firstname']) . '  ';
                            echo $row['Lastname'];
                            ?>
                        </td>

                        <?php if (isset($_SESSION['shall_delete'])) { ?>
                            <td>
                                <a href="#" class="small_stock_delete_link" style="color: #000080;" data-id_delete="small_stock_id"  data-table="
                                   <?php echo $row['small_stock_id']; ?>">Delete</a>
                            </td>
                            <td>
                                <a href="#" class="small_stock_update_link" style="color: #000080;" value="
                                   <?php echo $row['small_stock_id']; ?>">Update</a>
                            </td><?php } ?></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

//chosen individual field
            function get_chosen_small_stock_quantity($id) {

                $db = new dbconnection();
                $sql = "select   small_stock.quantity from small_stock where small_stock_id=:small_stock_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':small_stock_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['quantity'];
                echo $field;
            }

            function get_chosen_small_stock_available_qty($id) {

                $db = new dbconnection();
                $sql = "select   small_stock.available_qty from small_stock where small_stock_id=:small_stock_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':small_stock_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['available_qty'];
                echo $field;
            }

            function get_chosen_small_stock_in_or_out($id) {

                $db = new dbconnection();
                $sql = "select   small_stock.in_or_out from small_stock where small_stock_id=:small_stock_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':small_stock_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['in_or_out'];
                echo $field;
            }

            function get_chosen_small_stock_measurement($id) {

                $db = new dbconnection();
                $sql = "select   small_stock.measurement from small_stock where small_stock_id=:small_stock_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':small_stock_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['measurement'];
                echo $field;
            }

            function get_chosen_small_stock_item($id) {

                $db = new dbconnection();
                $sql = "select   small_stock.item from small_stock where small_stock_id=:small_stock_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':small_stock_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['item'];
                echo $field;
            }

            function get_chosen_small_stock_entry_date($id) {

                $db = new dbconnection();
                $sql = "select   small_stock.entry_date from small_stock where small_stock_id=:small_stock_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':small_stock_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['entry_date'];
                echo $field;
            }

            function get_chosen_small_stock_User($id) {

                $db = new dbconnection();
                $sql = "select   small_stock.User from small_stock where small_stock_id=:small_stock_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':small_stock_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['User'];
                echo $field;
            }

            function All_small_stock() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  small_stock_id   from small_stock";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_small_stock() {
                $con = new dbconnection();
                $sql = "select small_stock.small_stock_id from small_stock
                    order by small_stock.small_stock_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['small_stock_id'];
                return $first_rec;
            }

            function get_last_small_stock() {
                $con = new dbconnection();
                $sql = "select small_stock.small_stock_id from small_stock
                    order by small_stock.small_stock_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['small_stock_id'];
                return $first_rec;
            }

//chosen individual field
            function get_chosen_stock_taking_item($id) {

                $db = new dbconnection();
                $sql = "select   stock_taking.item from stock_taking where stock_taking_id=:stock_taking_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':stock_taking_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['item'];
                echo $field;
            }

            function get_chosen_stock_taking_in_or_out($id) {

                $db = new dbconnection();
                $sql = "select   stock_taking.in_or_out from stock_taking where stock_taking_id=:stock_taking_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':stock_taking_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['in_or_out'];
                echo $field;
            }

            function list_ditribution_small_stock($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select ditribution_small_stock.ditribution_small_stock_id,  small_stock.name as source_stock,  small_stock.name as destination_stock,  ditribution_small_stock.taken_quantity,  ditribution_small_stock.item,  ditribution_small_stock.remaining_qty,  ditribution_small_stock.entry_date,  ditribution_small_stock.User from ditribution_small_stock "
                        . " join small_stock on small_stock.small_stock_id=ditribution_small_stock.source_stock "
                        . "  ";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> ditribution_small_stock </td>
                        <td> Source Stock </td><td> Destination Stock </td><td> Taken Quantity </td><td> Item </td><td> Remaining Quantity </td><td> Entry Date </td><td> User </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['ditribution_small_stock_id']; ?>
                        </td>
                        <td class="source_stock_id_cols ditribution_small_stock " title="ditribution_small_stock" >
                            <?php echo $this->_e($row['source_stock']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['destination_stock']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['taken_quantity']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['item']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['remaining_qty']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['entry_date']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['User']); ?>
                        </td>


                        <td>
                            <a href="#" class="ditribution_small_stock_delete_link" style="color: #000080;" data-id_delete="ditribution_small_stock_id"  data-table="
                               <?php echo $row['ditribution_small_stock_id']; ?>">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="ditribution_small_stock_update_link" style="color: #000080;" value="
                               <?php echo $row['ditribution_small_stock_id']; ?>">Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

//chosen individual field
            function get_chosen_ditribution_small_stock_source_stock($id) {

                $db = new dbconnection();
                $sql = "select   ditribution_small_stock.source_stock from ditribution_small_stock where ditribution_small_stock_id=:ditribution_small_stock_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':ditribution_small_stock_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['source_stock'];
                echo $field;
            }

            function get_chosen_ditribution_small_stock_destination_stock($id) {

                $db = new dbconnection();
                $sql = "select   ditribution_small_stock.destination_stock from ditribution_small_stock where ditribution_small_stock_id=:ditribution_small_stock_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':ditribution_small_stock_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['destination_stock'];
                echo $field;
            }

            function get_chosen_ditribution_small_stock_taken_quantity($id) {

                $db = new dbconnection();
                $sql = "select   ditribution_small_stock.taken_quantity from ditribution_small_stock where ditribution_small_stock_id=:ditribution_small_stock_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':ditribution_small_stock_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['taken_quantity'];
                echo $field;
            }

            function get_chosen_ditribution_small_stock_item($id) {

                $db = new dbconnection();
                $sql = "select   ditribution_small_stock.item from ditribution_small_stock where ditribution_small_stock_id=:ditribution_small_stock_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':ditribution_small_stock_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['item'];
                echo $field;
            }

            function get_chosen_ditribution_small_stock_remaining_qty($id) {

                $db = new dbconnection();
                $sql = "select   ditribution_small_stock.remaining_qty from ditribution_small_stock where ditribution_small_stock_id=:ditribution_small_stock_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':ditribution_small_stock_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['remaining_qty'];
                echo $field;
            }

            function get_chosen_ditribution_small_stock_entry_date($id) {

                $db = new dbconnection();
                $sql = "select   ditribution_small_stock.entry_date from ditribution_small_stock where ditribution_small_stock_id=:ditribution_small_stock_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':ditribution_small_stock_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['entry_date'];
                echo $field;
            }

            function get_chosen_ditribution_small_stock_User($id) {

                $db = new dbconnection();
                $sql = "select   ditribution_small_stock.User from ditribution_small_stock where ditribution_small_stock_id=:ditribution_small_stock_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':ditribution_small_stock_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['User'];
                echo $field;
            }

            function All_ditribution_small_stock() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  ditribution_small_stock_id   from ditribution_small_stock";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_ditribution_small_stock() {
                $con = new dbconnection();
                $sql = "select ditribution_small_stock.ditribution_small_stock_id from ditribution_small_stock
                    order by ditribution_small_stock.ditribution_small_stock_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['ditribution_small_stock_id'];
                return $first_rec;
            }

            function get_last_ditribution_small_stock() {
                $con = new dbconnection();
                $sql = "select ditribution_small_stock.ditribution_small_stock_id from ditribution_small_stock
                    order by ditribution_small_stock.ditribution_small_stock_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['ditribution_small_stock_id'];
                return $first_rec;
            }

            function list_p_budget_items($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from p_budget_items";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> S/N </td>
                        <td> Item Name </td><td> Description </td><td> Created By </td><td> Entry Date </td><td> Chart Account </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['p_budget_items_id']; ?>
                        </td>
                        <td class="item_name_id_cols p_budget_items " title="p_budget_items" >
                            <?php echo $this->_e($row['item_name']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['description']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['created_by']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['entry_date']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['chart_account']); ?>
                        </td>


                        <td>
                            <a href="#" class="p_budget_items_delete_link" style="color: #000080;" data-id_delete="p_budget_items_id"  data-table="
                               <?php echo $row['p_budget_items_id']; ?>">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="p_budget_items_update_link" style="color: #000080;" value="
                               <?php echo $row['p_budget_items_id']; ?>">Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

//chosen individual field
            function get_chosen_p_budget_items_item_name($id) {

                $db = new dbconnection();
                $sql = "select   p_budget_items.item_name from p_budget_items where p_budget_items_id=:p_budget_items_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':p_budget_items_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['item_name'];
                echo $field;
            }

            function get_chosen_p_budget_items_description($id) {

                $db = new dbconnection();
                $sql = "select   p_budget_items.description from p_budget_items where p_budget_items_id=:p_budget_items_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':p_budget_items_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['description'];
                echo $field;
            }

            function get_chosen_p_budget_items_created_by($id) {

                $db = new dbconnection();
                $sql = "select   p_budget_items.created_by from p_budget_items where p_budget_items_id=:p_budget_items_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':p_budget_items_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['created_by'];
                echo $field;
            }

            function get_chosen_p_budget_items_entry_date($id) {

                $db = new dbconnection();
                $sql = "select   p_budget_items.entry_date from p_budget_items where p_budget_items_id=:p_budget_items_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':p_budget_items_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['entry_date'];
                echo $field;
            }

            function get_chosen_p_budget_items_chart_account($id) {

                $db = new dbconnection();
                $sql = "select   p_budget_items.chart_account from p_budget_items where p_budget_items_id=:p_budget_items_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':p_budget_items_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['chart_account'];
                echo $field;
            }

            function All_p_budget_items() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  p_budget_items_id   from p_budget_items";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_p_budget_items() {
                $con = new dbconnection();
                $sql = "select p_budget_items.p_budget_items_id from p_budget_items
                    order by p_budget_items.p_budget_items_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['p_budget_items_id'];
                return $first_rec;
            }

            function get_last_p_budget_items() {
                $con = new dbconnection();
                $sql = "select p_budget_items.p_budget_items_id from p_budget_items
                    order by p_budget_items.p_budget_items_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['p_budget_items_id'];
                return $first_rec;
            }

            function list_measurement($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select * from measurement";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>

                        <td> measurement </td>
                        <td> Code </td><td> Description </td>
                        <td>Delete</td><td>Update</td></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr> 

                        <td>
                            <?php echo $row['measurement_id']; ?>
                        </td>
                        <td class="code_id_cols measurement " title="measurement" >
                            <?php echo $this->_e($row['code']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['description']); ?>
                        </td>


                        <td>
                            <a href="#" class="measurement_delete_link" style="color: #000080;" data-id_delete="measurement_id"  data-table="
                               <?php echo $row['measurement_id']; ?>">Delete</a>
                        </td>
                        <td>
                            <a href="#" class="measurement_update_link" style="color: #000080;" value="
                               <?php echo $row['measurement_id']; ?>">Update</a>
                        </td></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
                <?php
            }

//chosen individual field
            function get_chosen_measurement_code($id) {

                $db = new dbconnection();
                $sql = "select   measurement.code from measurement where measurement_id=:measurement_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':measurement_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['code'];
                echo $field;
            }

            function get_chosen_measurement_description($id) {

                $db = new dbconnection();
                $sql = "select   measurement.description from measurement where measurement_id=:measurement_id ";
                $stmt = $db->openConnection()->prepare($sql);
                $stmt->bindValue(':measurement_id', $id);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $field = $row['description'];
                echo $field;
            }

            function All_measurement() {
                $c = 0;
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select  measurement_id   from measurement";
                foreach ($db->query($sql) as $row) {
                    $c += 1;
                }
                return $c;
            }

            function get_first_measurement() {
                $con = new dbconnection();
                $sql = "select measurement.measurement_id from measurement
                    order by measurement.measurement_id asc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['measurement_id'];
                return $first_rec;
            }

            function get_last_measurement() {
                $con = new dbconnection();
                $sql = "select measurement.measurement_id from measurement
                    order by measurement.measurement_id desc
                    limit 1";
                $stmt = $con->openconnection()->prepare($sql);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['measurement_id'];
                return $first_rec;
            }

            function get_account_category_in_combo() {
                require_once('../web_db/connection.php');
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select account_category.account_category_id,   account_category.name from account_category";
                ?>
            <select class="textbox cbo_account_category"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['account_category_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_profile_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select profile.profile_id,   profile.name from profile";
            ?>
            <select class="textbox cbo_profile"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['profile_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_image_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select image.image_id,   image.name from image";
            ?>
            <select class="textbox cbo_image"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['image_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_destination_stock_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select small_stock.small_stock_id,small_stock.location, small_stock.name,  small_stock.small_stock_id from small_stock";
            ?>
            <select class="textbox cbo_destination_stock"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['small_stock_id'] . ">" . $row['small_stock_id'] . " - " . $row['location'] . " - " . $row['name'];
                    "</option>";
                }
                ?>
            </select>
            <?php
        }

        function get_source_stock_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select small_stock.small_stock_id,small_stock.name,   small_stock.location from small_stock";
            ?>
            <select class="textbox cbo_source_stock"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['small_stock_id'] . ">" . $row['small_stock_id'] . " - " . $row['location'] . " - " . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_source_stock_in_js_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select small_stock.small_stock_id,small_stock.name,   small_stock.location from small_stock";
            ?>
            <select class="textbox cbo_source_stock dbo_return_items_cbo"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['small_stock_id'] . ">" . $row['small_stock_id'] . " - " . $row['location'] . " - " . $row['name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_items_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select p_budget_items.p_budget_items_id,  p_budget_items.item_name from p_budget_items";
            ?>
            <select name="acc_item_combo[]"  class="textbox cbo_items"><option></option> <option value="fly_new_p_budget_items">--Add new--</option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['p_budget_items_id'] . ">" . $row['item_name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_smallstock_items_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select small_stock.item,p_budget_items.item_name from small_stock "
                    . " join p_budget_items on p_budget_items.p_budget_items_id=small_stock.item "
                    . " group by small_stock.item";
            ?>
            <select name="acc_item_combo[]"  class="textbox cbo_items"><option></option> <option value="fly_new_p_budget_items">--Add new--</option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['item'] . ">" . $row['item_name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        function get_mainstock_items_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select main_stock.item,p_budget_items.item_name from main_stock "
                    . " join p_budget_items on p_budget_items.p_budget_items_id=main_stock.item "
                    . "group by p_budget_items.p_budget_items_id";
            ?>
            <select name="acc_item_combo[]"  class="textbox cbo_items"><option></option> <option value="fly_new_p_budget_items">--Add new--</option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['item'] . ">" . $row['item_name'] . " </option>";
                }
                ?>
            </select>
            <?php
        }

        // <editor-fold defaultstate="collapsed" desc="----other fx--------">
        function get_mainstock_old_qty($item) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select available_qty from  main_stock "
                    . " where item=:item "
                    . " order by main_stock.main_stock_id desc limit 1 ";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":item" => $item));
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            return $row['available_qty'];
        }

        function get_item_exits_main_stock($item) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select item from  main_stock where item=:item ";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":item" => $item));
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            return $row['item'];
        }

        function get_mainstock_old_amount($item) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select total_amount from  main_stock "
                    . " where item=:item "
                    . " order by main_stock.main_stock_id desc limit 1 ";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":item" => $item));
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            return $row['total_amount'];
        }

        function get_samllstock_old_qty($item, $stock) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "SELECT quantity from smal_stock_status where smal_stock_status.stock=:stock and smal_stock_status.item=:item";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":item" => $item, ":stock" => $stock));
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            return $row['quantity'];
        }

        function get_item_insmall_stock($item, $stock) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select item from smal_stock_status where smal_stock_status.item=:item and smal_stock_status.stock=:stock  ";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":item" => $item, ":stock" => $stock));
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            return trim($row['item']);
        }

        function get_sml_stockname_by_id($stockid) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select name from small_stock where small_stock.small_stock_id=:stock ";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":stock" => $stockid));
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            return trim($row['name']);
        }

        function get_sml_stocklocation_by_id($stockid) {
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select location from small_stock where small_stock.small_stock_id=:stock ";
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":stock" => $stockid));
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            return trim($row['location']);
        }

// </editor-fold>

        function get_smalstock_items_by_stock($stock) {
            try {

                $database = new dbconnection();
                $db = $database->openconnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $sql = "select smal_stock_status.item, p_budget_items.item_name as name from smal_stock_status   "
                        . " join p_budget_items on p_budget_items.p_budget_items_id=smal_stock_status.item "
                        . " where smal_stock_status.stock=:stock "
                        . " group by smal_stock_status.item "
                        . " ";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":stock" => $stock));
                $data = array();
                while ($row = $stmt->fetch()) {
                    $data[] = array(
                        'id' => $row['item'],
                        'name' => $row['name']
                    );
                }
                return json_encode($data);
            } catch (PDOException $e) {
                echo $e->getMessage();
            }
        }

        function get_sector_in_combo() {
            require_once('../web_db/connection.php');
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select sector.sector_id,   sector.name from sector";
            ?>
            <div class="parts  no_paddin_shade_no_Border reverse_border margin_free select_wrapper">
                <select class="sml_combo  cbo_sector" id="sp_combo_sectr"><option> Sectors</option>
                    <?php
                    foreach ($db->query($sql) as $row) {
                        echo "<option value=" . $row['sector_id'] . ">" . $row['name'] . " </option>";
                    }
                    ?>
                </select>
            </div>
            <?php
        }

        function search_item_main_stock($item_name) {
            ?><div class="parts full_center_two_h heit_free no_shade_noBorder">
                Items from Main stock
            </div><?php
            try {
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $sql = "select main_stock.main_stock_id, p_budget_items.p_budget_items,  p_budget_items.description,  p_budget_items.created_by,  p_budget_items.entry_date,  p_budget_items.chart_account from main_stock
                        join p_budget_items on p_budget_items.p_budget_items_id=main_stock.item
                        where p_budget_items.item_name=:item 
                        group by p_budget_items.item_name";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":item" => $item_name));
                ?>
                <table class="dataList_table">
                    <thead><tr>
                            <td> S/N </td>
                            <td> Item name </td>
                            <td> Description </td>
                            <?php if (isset($_SESSION['shall_delete'])) { ?> <td>Delete</td>
                                <td>Update</td><?php } ?>
                        </tr></thead>
                    <?php
                    $pages = 1;
                    while ($row = $stmt->fetch()) {
                        ?><tr> 
                            <td>
                                <?php 1 ?>
                            </td>
                            <td class="code_id_cols measurement " title="measurement" >
                                <?php echo $this->_e($row['item_name']); ?>
                            </td>
                            <td>
                                <?php echo $this->_e($row['description']); ?>
                            </td><?php if (isset($_SESSION['shall_delete'])) { ?>
                                <td>
                                    <a href="#" class="measurement_delete_link" style="color: #000080;" data-id_delete="measurement_id"  data-table="
                                       <?php echo $row['created_by']; ?>">Delete</a>
                                </td>
                                <td>
                                    <a href="#" class="measurement_update_link" style="color: #000080;" value="
                                       <?php echo $row['measurement_id']; ?>">Update</a>
                                </td><?php } ?></tr>
                        <?php
                        $pages += 1;
                    }
                    ?></table>
                    <?php
                } catch (PDOException $e) {
                    echo $e->getMessage();
                }
            }

            function list_smal_stock_status($min) {
                $database = new dbconnection();
                $db = $database->openConnection();
                $sql = "select smal_stock_status.smal_stock_status_id,  p_budget_items.item_name as item,  smal_stock_status.quantity,   small_stock.name as stock from smal_stock_status"
                        . " join small_stock on small_stock.small_stock_id= smal_stock_status.stock "
                        . " join p_budget_items on p_budget_items.p_budget_items_id=smal_stock_status.item";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":min" => $min));
                ?>
            <table class="dataList_table">
                <thead><tr>
                        <td> S/N </td>   <td> Stock </td>

                        <td> Item </td><td> Quantity </td>
                        <?php if (isset($_SESSION['shall_delete'])) { ?><td>Delete</td><td>Update</td><?php } ?></tr></thead>

                <?php
                $pages = 1;
                while ($row = $stmt->fetch()) {
                    ?><tr>     <td>
                            <?php echo $row['smal_stock_status_id']; ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['stock']); ?>
                        </td>
                        <td class="item_id_cols smal_stock_status " title="smal_stock_status" >
                            <?php echo $this->_e($row['item']); ?>
                        </td>
                        <td>
                            <?php echo $this->_e($row['quantity']); ?>
                        </td>
                        <?php if (isset($_SESSION['shall_delete'])) { ?>
                            <td>
                                <a href="#" class="smal_stock_status_delete_link" style="color: #000080;" data-id_delete="smal_stock_status_id"  data-table="
                                   <?php echo $row['smal_stock_status_id']; ?>">Delete</a>
                            </td>
                            <td>
                                <a href="#" class="smal_stock_status_update_link" style="color: #000080;" value="
                                   <?php echo $row['smal_stock_status_id']; ?>">Update</a>
                            </td><?php } ?></tr>
                    <?php
                    $pages += 1;
                }
                ?></table>
            <?php
        }

//chosen individual field
        function get_chosen_smal_stock_status_item($id) {

            $db = new dbconnection();
            $sql = "select   smal_stock_status.item from smal_stock_status where smal_stock_status_id=:smal_stock_status_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':smal_stock_status_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['item'];
            echo $field;
        }

        function get_chosen_smal_stock_status_quantity($id) {

            $db = new dbconnection();
            $sql = "select   smal_stock_status.quantity from smal_stock_status where smal_stock_status_id=:smal_stock_status_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':smal_stock_status_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['quantity'];
            echo $field;
        }

        function get_chosen_smal_stock_status_stock($id) {

            $db = new dbconnection();
            $sql = "select   smal_stock_status.stock from smal_stock_status where smal_stock_status_id=:smal_stock_status_id ";
            $stmt = $db->openConnection()->prepare($sql);
            $stmt->bindValue(':smal_stock_status_id', $id);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $field = $row['stock'];
            echo $field;
        }

        function All_smal_stock_status() {
            $c = 0;
            $database = new dbconnection();
            $db = $database->openConnection();
            $sql = "select  smal_stock_status_id   from smal_stock_status";
            foreach ($db->query($sql) as $row) {
                $c += 1;
            }
            return $c;
        }

        function get_first_smal_stock_status() {
            $con = new dbconnection();
            $sql = "select smal_stock_status.smal_stock_status_id from smal_stock_status
                    order by smal_stock_status.smal_stock_status_id asc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['smal_stock_status_id'];
            return $first_rec;
        }

        function get_last_smal_stock_status() {
            $con = new dbconnection();
            $sql = "select smal_stock_status.smal_stock_status_id from smal_stock_status
                    order by smal_stock_status.smal_stock_status_id desc
                    limit 1";
            $stmt = $con->openconnection()->prepare($sql);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            $first_rec = $row['smal_stock_status_id'];
            return $first_rec;
        }

        function get_quantity_by_pr_id($purid) {

            try {
                $con = new dbconnection();
                $db = $con->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $sql = "select purchase_invoice_line.quantity, purchase_invoice_line.purchase_invoice_line_id from purchase_invoice_line where purchase_invoice_line.purchase_invoice_line_id=:purid ";
                $stmt = $db->prepare($sql);
                $stmt->execute(array(":purid" => $purid));
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $first_rec = $row['quantity'];
                return $first_rec;
            } catch (PDOException $e) {
                echo $e->getMessage();
            }
        }

// </editor-fold>
    }
    
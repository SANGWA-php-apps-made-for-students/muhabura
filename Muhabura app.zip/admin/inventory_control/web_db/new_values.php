<?php

    require_once('connection.php');

    class new_values {

        function new_account($account_category, $date_created, $profile, $username, $password, $is_online) {
            try {

                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into account values(:account_id, :account_category,  :date_created,  :profile,  :username,  :password,  :is_online)");
                $stm->execute(array(':account_id' => 0, ':account_category' => $account_category, ':date_created' => $date_created, ':profile' => $profile, ':username' => $username, ':password' => $password, ':is_online' => $is_online
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_account_category($name) {
            try {

                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into account_category values(:account_category_id, :name)");
                $stm->execute(array(':account_category_id' => 0, ':name' => $name
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_profile($dob, $name, $last_name, $gender, $telephone_number, $email, $residence, $image) {
            try {

                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into profile values(:profile_id, :dob,  :name,  :last_name,  :gender,  :telephone_number,  :email,  :residence,  :image)");
                $stm->execute(array(':profile_id' => 0, ':dob' => $dob, ':name' => $name, ':last_name' => $last_name, ':gender' => $gender, ':telephone_number' => $telephone_number, ':email' => $email, ':residence' => $residence, ':image' => $image
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_image($path) {
            try {

                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into image values(:image_id, :path)");
                $stm->execute(array(':image_id' => 0, ':path' => $path
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_main_stock($item, $quantity, $available_qty, $in_or_out, $measurement, $entry_date, $User, $unit_cost, $total_amount) {
            try {

                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into main_stock values(:main_stock_id, :item,  :quantity,  :available_qty,  :in_or_out,  :measurement,  :entry_date,  :User,:unit_cost,:total_amount)");
                $stm->execute(array(':main_stock_id' => 0, ':item' => $item, ':quantity' => $quantity, ':available_qty' => $available_qty, ':in_or_out' => $in_or_out, ':measurement' => $measurement, ':entry_date' => $entry_date, ':User' => $User, ':unit_cost' => $unit_cost, ':total_amount' => $total_amount));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_distriibution($source_stock, $destination_stock, $taken_qty, $item, $remaining_qty, $entry_date, $User) {
            try {
                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into distriibution values(:distriibution_id, :source_stock,  :destination_stock,  :taken_qty,  :item,  :remaining_qty,  :entry_date,  :User)");
                $stm->execute(array(':distriibution_id' => 0, ':source_stock' => $source_stock, ':destination_stock' => $destination_stock, ':taken_qty' => $taken_qty, ':item' => $item, ':remaining_qty' => $remaining_qty, ':entry_date' => $entry_date, ':User' => $User
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e->getMessage();
            }
        }

        function new_returns($source_stock, $destination_stock, $item, $remaining_qty, $entry_date, $User) {
            try {

                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into returns values(:returns_id, :source_stock,  :destination_stock,  :item,  :returned_qty,  :entry_date,  :User)");
                $stm->execute(array(':returns_id' => 0, ':source_stock' => $source_stock, ':destination_stock' => $destination_stock, ':item' => $item, ':returned_qty' => $remaining_qty, ':entry_date' => $entry_date, ':User' => $User
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_small_stock($quantity, $available_qty, $in_or_out, $measurement, $item, $entry_date, $User, $location, $name) {
            try {

                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into small_stock values(:small_stock_id, :quantity,  :available_qty,  :in_or_out,  :measurement,  :item,  :entry_date,  :User,:location,:name)");
                $stm->execute(array(':small_stock_id' => 0, ':quantity' => $quantity, ':available_qty' => $available_qty, ':in_or_out' => $in_or_out, ':measurement' => $measurement, ':item' => $item, ':entry_date' => $entry_date, ':User' => $User, ':location' => $location, ':name' => $name
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_stock_taking($item, $quantity, $entry_date, $User, $available_quantity, $in_or_out, $measurement) {
            try {

                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into stock_taking values(:stock_taking_id, :item,  :quantity,  :entry_date,  :User,  :available_quantity,  :in_or_out,  :measurement)");
                $stm->execute(array(':stock_taking_id' => 0, ':item' => $item, ':quantity' => $quantity, ':entry_date' => $entry_date, ':User' => $User, ':available_quantity' => $available_quantity, ':in_or_out' => $in_or_out, ':measurement' => $measurement
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_ditribution_small_stock($source_stock, $destination_stock, $taken_quantity, $item, $remaining_qty, $entry_date, $User) {
            try {

                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into ditribution_small_stock values(:ditribution_small_stock_id, :source_stock,  :destination_stock,  :taken_quantity,  :item,  :remaining_qty,  :entry_date,  :User)");
                $stm->execute(array(':ditribution_small_stock_id' => 0, ':source_stock' => $source_stock, ':destination_stock' => $destination_stock, ':taken_quantity' => $taken_quantity, ':item' => $item, ':remaining_qty' => $remaining_qty, ':entry_date' => $entry_date, ':User' => $User
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_p_budget_items($item_name, $description, $created_by, $entry_date, $chart_account) {
            try {

                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into p_budget_items values(:p_budget_items_id, :item_name,  :description,  :created_by,  :entry_date,  :chart_account)");
                $stm->execute(array(':p_budget_items_id' => 0, ':item_name' => $item_name, ':description' => $description, ':created_by' => $created_by, ':entry_date' => $entry_date, ':chart_account' => $chart_account
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_measurement($code, $description) {
            try {

                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into measurement values(:measurement_id, :code,  :description)");
                $stm->execute(array(':measurement_id' => 0, ':code' => $code, ':description' => $description
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_smal_stock_status($item, $quantity, $stock) {
            try {

                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into smal_stock_status values(:smal_stock_status_id, :item,  :quantity,  :stock)");
                $stm->execute(array(':smal_stock_status_id' => 0, ':item' => $item, ':quantity' => $quantity, ':stock' => $stock
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_Main_Request($entry_date, $User) {
            try {

                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into main_request values(:Main_Request_id, :entry_date,  :User)");
                $stm->execute(array(':Main_Request_id' => 0, ':entry_date' => $entry_date, ':User' => $User
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_p_request($item, $quantity, $unit_cost, $amount, $entry_date, $User, $measurement, $request_no, $main_req) {
            try {

                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into p_request values(:p_request_id, :item,  :quantity,  :unit_cost,  :amount,  :entry_date,  :User,  :measurement,  :request_no,:main_req)");
                $stm->execute(array(':p_request_id' => 0, ':item' => $item, ':quantity' => $quantity, ':unit_cost' => $unit_cost, ':amount' => $amount, ':entry_date' => $entry_date, ':User' => $User, ':measurement' => $measurement, ':request_no' => $request_no, ":main_req" => $main_req
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

        function new_stock_into_main($item, $quantity, $entry_date, $User, $purchaseid) {
            try {

                $database = new dbconnection();
                $db = $database->openConnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $stm = $db->prepare("insert into stock_into_main values(:stock_into_main_id, :item,  :quantity,  :entry_date,  :User, :purchaseid)");
                $stm->execute(array(':stock_into_main_id' => 0, ':item' => $item, ':quantity' => $quantity, ':entry_date' => $entry_date, ':User' => $User, ':purchaseid' => $purchaseid
                ));
            } catch (PDOException $e) {
                echo 'Error .. ' . $e;
            }
        }

    }
    
<?php

    require_once 'connection.php';

    class deletions {

        function deleteFrom_stock_taking($stock_taking_id) {
            $db = new dbconnection();
            $con = $db->openconnection();
            $smt = $con->prepare(" DELETE FROM stock_taking where stock_taking_id =:stock_taking_id");
            $smt->bindValue(':stock_taking_id', $stock_taking_id, PDO::PARAM_STR);
            $smt->execute();
            echo 'Record removed succefully';
        }

    }
    
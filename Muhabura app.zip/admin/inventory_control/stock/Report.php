<?php
    require_once '../web_db/multi_values.php';
?><html>
    <head>
        <meta charset="UTF-8">
        <title>
            Stock Repport
        </title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>  <link href="admin_style.css" rel="stylesheet" type="text/css"/>
        <meta name="viewport" content="width=device-width, initial scale=1.0"/>
        <style>
            .welcome_text{
                height: 300px;
                width: 300px;
                background-image: url('../web_images/stock_report_welcome.png');
                background-repeat: no-repeat;
                font-size: 30px;
                color: #209abe;

                /*text-shadow: 0px 0px 6px #0040ff;*/
                /*color: #0040ff;*/
            }
            .rep_box{
                min-height: 300px;
            }
            .stock_rep_menus a{
                float: left;
                margin-left: 18px;
            }
            .search_box .textbox{
                width: 500px;
            }
            .btn_search{
                margin-top: 0px;
                float: left;
            }
        </style>
    </head>
    <body>
        <form action="new_account.php" method="post" enctype="multipart/form-data">
            <input type="hidden" id="txt_shall_expand_toUpdate" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim($_SESSION['table_to_update']) : '' ?>" />
            <!--this field  (shall_expand_toUpdate)above is for letting the form expand using js for updating-->

            <input type="hidden" id="txt_account_category_id"   name="txt_account_category_id"/><input type="hidden" id="txt_profile_id"   name="txt_profile_id"/>
            <?php
                include 'admin_header.php';
            ?>

            <!--Start dialog's-->
            <div class="parts abs_full y_n_dialog off">
                <div class="parts dialog_yes_no no_paddin_shade_no_Border reverse_border">
                    <div class="parts full_center_two_h heit_free margin_free skin">
                        Do you really want to delete this record?
                    </div>
                    <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border top_off_x margin_free">
                        <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_xx link_cursor yes_dlg_btn" id="citizen_yes_btn">Yes</div>
                        <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_seventy link_cursor no_btn" id="no_btn">No</div>
                    </div>
                </div>
            </div>   
            <!--End dialog-->
            <div class="parts eighty_centered no_paddin_shade_no_Border hider_box">  
                <div class="parts  no_paddin_shade_no_Border new_data_hider"> Hide </div>  </div>
            <div class="parts eighty_centered off saved_dialog">
                account saved successfully!
            </div>
            <div class="parts eighty_centered no_paddin_shade_no_Border rep_box">
                <div class="welcome_text off" style="margin: auto;">
                    Stock Reports
                </div>
                <div class="parts  stock_rep_menus full_center_two_h heit_free">
                    <a class="stock_rep_links" id="stock_rep_main_stock_link" href="#">Main Stock</a>
                    <a class="stock_rep_links" id="stock_rep_small_stock_link"href="#">Small Stock</a>
                    <a class="stock_rep_links" href="#">Main Stock</a>
                    <a class="stock_rep_links" href="#">Main Stock</a>
                    <a class="stock_rep_links" href="#">Main Stock</a>
                    <a class="stock_rep_links" href="#">Main Stock</a>
                </div>
                <div class="parts full_center_two_h heit_free main_stock_pane">
                    <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border search_box">
                        <input type="text" class="textbox" id="txt_main_stock" placeholder="Search from Main stock" autocomplete="off" name="txt_name"  /><input type="button" class="confirm_buttons btn_search btn_main_search margin_free" style="margin-top: 0px; float: left;" value="Search">
                    </div>
                    <?php
                        $obj = new multi_values();
                        $first = $obj->get_first_main_stock();
                        $obj->list_main_stock($first);
                    ?>
                </div>
                <div class="parts full_center_two_h heit_free small_stock_pane off">
                    <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border search_box">
                        <input type="text" class="textbox" placeholder="Search from Small stock" autocomplete="off" name="txt_name"  /><input type="button" class="confirm_buttons btn_search btn_small_search margin_free" style="margin-top: 0px; float: left;" value="Search">
                    </div>
                </div>
                <div class="parts full_center_two_h heit_free res_box">
                    <div class=" no_paddin_shade_no_Border load_res_box off">

                    </div>
                    <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border data_res">
                        Data
                    </div>
                </div>
            </div>
            <div class="parts eighty_centered datalist_box off">
                <div class="parts no_shade_noBorder xx_titles no_bg whilte_text dataList_title">account List</div>
                <?php
                    $obj = new multi_values();
                    $first = $obj->get_first_account();
                    $obj->list_account($first);
                ?>
            </div>  
            <div class="parts no_paddin_shade_no_Border export_box  eighty_centered heit_free">
                <form action="../web_exports/account.php" method="post">
                    <input type="submit" name="account" class="exprt_btn  exprt_btn_account" value="Export to Excel"/>
                </form>
            </div>
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
        <script>
            $(document).ready(function () {

                $('.welcome_text').show(1000).delay(2000).slideUp(400);
                $('#stock_rep_main_stock').click(function () {
                    var main_stock = ;
                            $.post('../admin/handler.php', {main_stock: main_stock}, function (data) {
                            }).complete(function () {
                    });
                });

            });
        </script>
        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
    </body>
</hmtl> 
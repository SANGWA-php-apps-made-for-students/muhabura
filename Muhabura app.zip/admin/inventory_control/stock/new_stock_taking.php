<?php
    session_start();
    require_once '../web_db/multi_values.php';
    if (!isset($_SESSION)) {
        session_start();
    }if (!isset($_SESSION['login_token'])) {
        header('location:../index.php');
    }
    if (isset($_POST['send_stock_taking'])) {
        if (isset($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'stock_taking') {
                require_once '../web_db/updates.php';
                $upd_obj = new updates();
                $stock_taking_id = $_SESSION['id_upd'];

                $item = trim($_POST['txt_item_id']);
                $quantity = $_POST['txt_quantity'];
                $entry_date = date("y-m-d");
                $User = $_SESSION['userid'];
                $available_quantity = $_POST['txt_available_quantity'];
                $in_or_out = $_POST['txt_in_or_out'];
                $measurement = $_POST['txt_measurement_id'];

                $m = new multi_values();
                $old_qty = $m->get_mainstock_old_qty($item);
                if ($old_qty < $quantity) {
                    ?><script>alert('The quantity you want to take is bigger than the existing. In main stock you only have <?php echo $old_qty; ?>');</script><?php
                } else {
                    $upd_obj->update_stock_taking($item, $quantity, $entry_date, $User, $available_quantity, $in_or_out, $measurement, $stock_taking_id);
                    unset($_SESSION['table_to_update']);
                }
            }
        } else {
            $item = trim($_POST['txt_item_id']);
            $quantity = $_POST['txt_quantity'];
            $entry_date = date("y-m-d");
            $User = $_SESSION['userid'];
            $available_quantity = 0; // $_POST['txt_available_quantity'];
            $in_or_out = 'in';
            $measurement = trim($_POST['txt_measurement_id']);

            //Check if the quantity is available
            $m = new multi_values();
            $old_qty = $m->get_mainstock_old_qty($item);
            if ($old_qty < $quantity) {
                ?><script>alert('The quantity you want to take is bigger than the existing. In main stock you only have <?php echo $old_qty; ?>');</script><?php
            } else {
                require_once '../web_db/new_values.php';
                require_once '../web_db/updates.php';
                $upd = new updates();
                $obj = new new_values();
                $obj->new_stock_taking($item, $quantity, $entry_date, $User, $available_quantity, $in_or_out, $measurement);
                //Update main stock
                $new_qty = $old_qty - $quantity;
                $upd->update_main_stock_qty($new_qty, $item);
            }
        }
    }
?>

<html>
    <head>
        <meta charset="UTF-8">
        <title>
            Stock movement</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <link href="admin_style.css" rel="stylesheet" type="text/css"/>
        <meta name="viewport" content="width=device-width, initial scale=1.0"/>
    </head>
    <body>
        <form action="new_stock_taking.php" method="post" enctype="multipart/form-data">
            <input type="hidden" id="txt_shall_expand_toUpdate" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim($_SESSION['table_to_update']) : '' ?>" />
            <!--this field  (shall_expand_toUpdate)above is for letting the form expand using js for updating-->
            <input type="hidden" id="txt_item_id"   name="txt_item_id"/>
            <input type="hidden" id="txt_measurement_id"   name="txt_measurement_id"/>
            <?php
                include 'admin_header.php';
                $ot = new other_fx();
                $ot->get_searchNew_menu('taken item', without_admin());
            ?>
            <!--Start dialog's-->
            <div class="parts abs_full y_n_dialog off">
                <div class="parts dialog_yes_no no_paddin_shade_no_Border reverse_border">
                    <div class="parts full_center_two_h heit_free margin_free skin">
                        Do you really want to delete this record?
                    </div>
                    <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border top_off_x margin_free">
                        <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_xx link_cursor yes_dlg_btn" id="citizen_yes_btn">Yes</div>
                        <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_seventy link_cursor no_btn" id="no_btn">No</div>
                    </div>
                </div>
            </div>   
            <!--End dialog-->

            <div class="parts eighty_centered off saved_dialog">
                stock_taking saved successfully! 
            </div>
            <div class="parts eighty_centered new_data_box off">
                <div class="parts eighty_centered new_data_title">  stock Movement Registration </div>
                <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border">
                    This is to take items from main stock for general use
                </div>
                <table class="new_data_table">
                    <tr><td class="new_data_tb_frst_cols">Item </td><td> <?php get_item_combo(); ?>  </td></tr><tr><td><label for="txt_quantity">Quantity </label></td><td> <input type="text"     name="txt_quantity" required id="txt_quantity" class="textbox" value="<?php echo trim(chosen_quantity_upd()); ?>"   />  </td></tr>
                    <tr class="off"><td><label for="txt_available_quantity">Available quantity </label></td><td> <input type="text"     name="txt_available_quantity"  id="txt_available_quantity" class="textbox" value="<?php echo trim(chosen_available_quantity_upd()); ?>"   />  </td></tr>
                    <tr><td class="new_data_tb_frst_cols">Measurement </td><td> <?php get_measurement_combo(); ?>  </td></tr>
                    <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_stock_taking" value="Save"/>  </td></tr>
                </table>
            </div>
            <div class="parts eighty_centered datalist_box" >
                <div class="parts no_shade_noBorder xx_titles no_bg whilte_text dataList_title">stock Movement List</div>
                <?php
                    $obj = new multi_values();
                    $first = $obj->get_first_stock_taking();
                    $obj->list_stock_taking($first);
                ?>
            </div>  
        </form> <div class="parts no_paddin_shade_no_Border export_box  eighty_centered heit_free">
            <form action="../web_exports/stock_taking.php" method="post">
                <input type="submit" name="stock_taking" class="exprt_btn  exprt_btn_stock_taking" value="Export to Excel"/>
            </form>
        </div><div class="parts eighty_centered  no_paddin_shade_no_Border no_shade_noBorder check_loaded" >
            <?php require_once './navigation/add_nav.php'; ?> 
        </div>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="admin_script.js" type="text/javascript"></script> 
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
        <script src="../../../web_scripts/searches.js" type="text/javascript"></script>
        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
    </body>
</hmtl>
<?php

    function get_measurement_combo() {
        $obj = new multi_values();
        $obj->get_measurement_in_combo();
    }

    function get_item_combo() {
        $obj = new multi_values();
        $obj->get_mainstock_items_in_combo();
    }

    function chosen_item_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'stock_taking') {
                $id = $_SESSION['id_upd'];
                $item = new multi_values();
                return $item->get_chosen_stock_taking_item($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_quantity_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'stock_taking') {
                $id = $_SESSION['id_upd'];
                $quantity = new multi_values();
                return $quantity->get_chosen_stock_taking_quantity($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_entry_date_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'stock_taking') {
                $id = $_SESSION['id_upd'];
                $entry_date = new multi_values();
                return $entry_date->get_chosen_stock_taking_entry_date($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_User_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'stock_taking') {
                $id = $_SESSION['id_upd'];
                $User = new multi_values();
                return $User->get_chosen_stock_taking_User($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_available_quantity_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'stock_taking') {
                $id = $_SESSION['id_upd'];
                $available_quantity = new multi_values();
                return $available_quantity->get_chosen_stock_taking_available_quantity($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_in_or_out_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'stock_taking') {
                $id = $_SESSION['id_upd'];
                $in_or_out = new multi_values();
                return $in_or_out->get_chosen_stock_taking_in_or_out($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_measurement_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'stock_taking') {
                $id = $_SESSION['id_upd'];
                $measurement = new multi_values();
                return $measurement->get_chosen_stock_taking_measurement($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }
    
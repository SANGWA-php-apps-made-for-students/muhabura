<?php
    session_start();
    require_once '../web_db/multi_values.php';
    require_once '../web_db/other_fx.php';
    if (!isset($_SESSION)) {
        session_start();
    }if (!isset($_SESSION['login_token'])) {
        header('location:../index.php');
    }
    if (isset($_POST['send_stock_into_main'])) {
        if (isset($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'stock_into_main') {
                require_once '../web_db/updates.php';
                $upd_obj = new updates();
                $stock_into_main_id = $_SESSION['id_upd'];
                $upd_obj->update_stock_into_main($stock_into_main_id);
                unset($_SESSION['table_to_update']);
            }
        } else {
            require_once '../web_db/new_values.php';
            require_once '../web_db/updates.php';
            $obj = new new_values();
            $upd = new updates();
            $item = trim($_POST['txt_item_id']);
            $m = new multi_values();
            $quantity = !empty($_POST['txt_quantity2']) ? $_POST['txt_quantity2'] : 0;
            $entry_date = date("y-m-d");
            $User = $_SESSION['userid'];
            $purchaseid = !empty(trim($_POST['txt_purchaseid'])) ? trim($_POST['txt_purchaseid']) : 0;
            if ($quantity > 1) {
                $obj->new_stock_into_main($item, $quantity, $entry_date, $User, $purchaseid);
                //Update the main stock
                $item_found = $m->get_item_exits_main_stock($item);
                if (empty($item_found)) {// if the item already exist
                    $obj->new_main_stock($item, $quantity, $quantity, 'in', 0, $entry_date, $User, 0, 0);
                } else {// if the item exists then update the quantity
                    $old_qty = $m->get_mainstock_old_qty($item);
                    $new_qty = $old_qty + $quantity;
                    $upd->update_main_stock_qty($new_qty, $item);
                }
            } else {
                ?><script>alert('You have to add quantity');</script><?php
            }
        }
    }
?>

<html>
    <head>
        <meta charset="UTF-8">
        <title>
            vat calculation</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/> <link href="admin_style.css" rel="stylesheet" type="text/css"/>
        <meta name="viewport" content="width=device-width, initial scale=1.0"/>
    </head>
    <body>
        <form action="new_stock_into_main.php" method="post" enctype="multipart/form-data">
            <input type="hidden" id="txt_shall_expand_toUpdate" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim($_SESSION['table_to_update']) : '' ?>" />
            <!--this field  (shall_expand_toUpdate)above is for letting the form expand using js for updating-->
            <?php
                include 'admin_header.php';
                $ot = new other_fx();
                $ot->get_searchNew_menu('more items', without_admin());
            ?>
            <input type="hidden" id="txt_item_id"   name="txt_item_id"/>
            <input type="hidden"  id="txt_pur_invoice"   name="txt_purchaseid"/>
            <input type="text"  id="txt_quantity2"   name="txt_quantity2"/>

            <!--Start dialog's-->
            <div class="parts abs_full y_n_dialog off">
                <div class="parts dialog_yes_no no_paddin_shade_no_Border reverse_border">
                    <div class="parts full_center_two_h heit_free margin_free skin">
                        Do you really want to delete this record?
                    </div>
                    <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border top_off_x margin_free">
                        <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_xx link_cursor yes_dlg_btn" id="citizen_yes_btn">Yes</div>
                        <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_seventy link_cursor no_btn" id="no_btn">No</div>
                    </div>
                </div>
            </div>   
            <!--End dialog-->


            <div class="parts eighty_centered off saved_dialog">
                stock_into_main saved successfully!
            </div>

            <div class="parts eighty_centered new_data_box">
                <div class="parts eighty_centered new_data_title">  Add items in Main stock </div>
                <table class="new_data_table">
                    <tr><td class="new_data_tb_frst_cols">item 
                        </td><td> <?php get_item_combo(); ?>  </td></tr>
                    <tr>
                        <td> <label for="chk_puronvoice">By Purchase purchase invoice</label>  </td><td><input type="checkbox" id="chk_puronvoice" checked="true" name="chk_purchase" ></td>
                    <tr class="hidable"><td><label for="txt_quantity">Purchase </label></td><td> <?php get_purchaseid_combo(); ?>   </td></tr>
                    <tr><td><label for="txt_quantity">Quantity </label></td><td> <input type="text"  disabled=""   name="txt_quantity" required id="txt_quantity" autocomplete="off" class="textbox" value="<?php echo trim(chosen_quantity_upd()); ?>"   />  </td>
                    </tr> <tr><td><label for="txt_quantity">  </label></td><td>  <div class="res"></div>  </td></tr>

                    <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_stock_into_main" value="Save"/>  </td></tr>
                </table>
            </div>

            <div class="parts eighty_centered datalist_box" >
                <div class="parts no_shade_noBorder xx_titles no_bg whilte_text dataList_title">stock ins</div>
                <?php
                    $obj = new multi_values();
                    $first = $obj->get_first_stock_into_main();
                    $obj->list_stock_into_main($first);
                ?>
            </div>  
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="admin_script.js" type="text/javascript"></script> 
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
        <script src="../../../web_scripts/web_scripts.js" type="text/javascript"></script>
        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
    </body>
</hmtl>
<?php

    function get_purchaseid_combo() {
        $obj = new multi_values();
        $obj->get_purchase_invoiceid_combo();
    }

    function get_item_combo() {
        $obj = new multi_values();
        $obj->get_item_in_combo();
    }

    function chosen_item_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'stock_into_main') {
                $id = $_SESSION['id_upd'];
                $item = new multi_values();
                return $item->get_chosen_stock_into_main_item($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_quantity_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'stock_into_main') {
                $id = $_SESSION['id_upd'];
                $quantity = new multi_values();
                return $quantity->get_chosen_stock_into_main_quantity($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_entry_date_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'stock_into_main') {
                $id = $_SESSION['id_upd'];
                $entry_date = new multi_values();
                return $entry_date->get_chosen_stock_into_main_entry_date($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_User_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'stock_into_main') {
                $id = $_SESSION['id_upd'];
                $User = new multi_values();
                return $User->get_chosen_stock_into_main_User($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }
    
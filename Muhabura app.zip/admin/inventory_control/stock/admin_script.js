
//<editor-fold defaultstate="collapsed" desc="----These variables are for adding new accounts ------------">
var menu_index = '';//this 40 is made as initial 40 will not be used

var menu_itself = '';
var accountid = 0, item = 0;
//these are used on the journal entry line
var end_balance = 0;
var end_date = '';

//</editor-fold>

$(document).ready(function () {
    try {
        mainLink_click();
        navigation();//  function has all naviagations
        slide_fromleft();
        chart_of_accounts();
        Projects();
        journal();
        //<editor-fold defaultstate="collapsed" desc="---Journal---">
        get_new_account_from_combo();
        get_second_pane();
        ok_opening_bal();
        save_close();
        //</editor-fold>
        //<editor-fold defaultstate="collapsed" desc="---budget implementation---">
//      get_activityy_by_proj();
        get_cbo_refil_changed();
        get_rev_expenses_combo();
        show_rep_details();
        //</editor-fold>
        get_accountid_id_combo();
        change_hider_txt();
        center_combobox();// this is the combo box on the field page
        budget();
        slideUp_figures();
        keep_menu_open();
        get_index_session();
        request_auto_typing();
        chk_puronvoice();
        show_alerts();
        alert_unfished_nav();
        //        hide_footer();
    } catch (err) {
        alert(err.message);
    }
});
function mainLink_click() {
    $('.main_link').click(function () {
        try {
            var me = $(this).children('span').is(':hidden');
            if (me) {
                $('.main_link').children('span').slideUp();
                $(this).children('span').slideToggle();
            } else {
                $(this).children('span').slideUp();
            }
            menu_index = $('.main_link').index(this);

            keep_menu_open();
            $.post('handler.php', {menu_index: menu_index}, function (data) {
                menu_index = data;
            });
            $('#navigated_menu').val(menu_index);
        } catch (err) {
            alert(err.message);
        }
    });
    var path = window.location.pathname;
    var page = path.split('/').slice();
    $('a[href^="' + page[3] + '"]').addClass('visited_menu');
    $('a[href^="' + page[3] + '"]').css('border', '1px solid red').css('padding', '5').css('background-color', '#d9e0f1');
}
function me_open() {


}
function some_menu_open() {
    var span1 = $('#span1').is(':hidden'), span2 = $('#span2').is(':hidden'), span3 = $('#span3').is(':hidden'), span4 = $('#span4').is(':hidden');
    if (span1 && span2 && span3 && span4) {
        return false;
    } else {
        return true;
    }
//    var open=$('#span1').is(':visible');
}
function slide_fromleft() {
    $('.slid_left').delay(1000).slideDown(500);
}
function get_accountid_id_combo() {
    try {
        $('.cbo_accountid').change(function () {

        });
    } catch (err) {
        alert(err.message);
    }
}
function change_hider_txt() {
//    $('.new_data_hider').html('Add New');
}
function center_combobox() {
    var box_width = $('.location_small_cbo').width();
    var cbo_width = $('.middle_cbo').width();
    var left_space = (box_width - cbo_width) / 2;

}
//<editor-fold defaultstate="collapsed" desc="------------Navigation of administrator------------">
function navigation() {
    try {
        $('.pages').hide();
        chart_acc();
        journal();
        t_balance();
        income();
        balance_sheet();
        projects();
        get_cbo_acc_rec_accid();

    } catch (err) {
        alert(err.message);
    }
}
function hide_anyother_pane() {
    $('.pages').hide();
    $('.slid_left').hide();
    //these down are the page specific items ( hider, new data form and the data list)
    $('.new_data_hider').hide();
    $('.datalist_box').hide();
    $('.new_data_box').hide();
}
//start
function chart_acc() {
    $('#pane_chart_acc').click(function () {
//        hide_anyother_pane();
//        change_nav_title('Chart of Accounts');
//        $('.charts_acc').show();
        //new temporaly functionality
        window.location.replace('../../new_account.php');

    });
}
function journal() {
    $('#pane_journal').click(function () {
//        hide_anyother_pane();
//        change_nav_title('General Journal entries');
//        $('.journal_sub_p').show();
        window.location.replace('new_journal_entry_line.php');

    });
}
function t_balance() {
    $('#pane_t_balance').click(function () {
//        hide_anyother_pane();
//        change_nav_title('Trial Balance');
//        $('.tb_sub_p').show();
        window.location.replace('report_trial_balance.php');
    });
}
function income() {
    $('#pane_income_stmt').click(function () {
//        hide_anyother_pane();
//        change_nav_title('Income Statement');
//        $('.income_sub_p').show();
//        window.location.replace('../../report_journal_entry.php');
    });
}
function balance_sheet() {
    $('#pane_b_sheet').click(function () {
//        hide_anyother_pane();
//        change_nav_title('Balance Sheet');
//        $('.balance_sub_p').show();
        window.location.replace('report_balanceshett.php');
    });
}
function projects() {
    $('#pane_projects').click(function () {
        hide_anyother_pane();
        change_nav_title('MMC Projects');
        $('.projects_sub_p').show();
    });
}
function change_nav_title(title) {
    $('.changing_title').html(title);

}
//end
//</editor-fold>

//<editor-fold defaultstate="collapsed" desc="Chart of Accounts new_account.php">

function chart_of_accounts() {
    defaults();
    get_accounts_done();
    click_acc_table();
    hide_menu();
    changed_acc_type_combo();
    other_accounts();
    sub_account_checkbox();
    opening_balance_btn();
    cancel_opening_balance();
    other_pane_ok();//ok button
    cancel_acctype_step1_2();

}
function get_accounts_done() {
    $('.radios').click(function () {
        item = $(this).val().trim();
        $('#txt_acc_type_id').val(item);
        $('#acc_next').prop('disabled', false);
        $('.drop_down').prop('disabled', true);
        shall_save_journal(item);
        if (item == 1) {
            $('.accounts_expln').html('Categorizes money earned from normal business operations, such as: \n\
            ' + '  <br/>     <ul> '
                    + '  <li>Product sales</li>'
                    + ' <li>Services sales</li>'
                    + ' <li>Discounts to customers</li>'
                    + ' </ul>');
        } else if (item == 2) {
            $('.accounts_expln').html('Categorizes money spend in the course  of normal business operations, such as:<br/>\n\
                ' + '<ul>\n\
                    ' + '<li>Advertising and promotion</li>\n\
                      ' + '<li>Office sipplies</li>\n\
                    ' + '<li>Insurances</li>\n\
                    ' + '<li>Legal fees</li>\n\
                    ' + '<li>Charitable Contributions</li>\n\
                    ' + '<li>Rent</li><ul>');
        } else if (item == 7) {
            $('.accounts_expln').html('Tracks the values of significant items that have a useful life of more than one year, such as: <br/>\n\
                ' + '<ul>\n\
                ' + '<li>Buildings</li>\n\
                ' + '<li>Land</li>\n\
                ' + '<li>Machinery and equipment</li>\n\
                ' + '<li>Vehicles</li></ul>');
        } else if (item == 17) {
            $('.accounts_expln').html('Create one for each cah such as:<br/>\n\
                ' + '<ul>\n\
                    <li>Petty cash</li>\n\
                    <li>Checking</li>\n\
                    <li>Savings</li>\n\
                    <li>Money market</li>\n\
                 ' + '</ul>');
        } else if (item == 18) {
            $('.accounts_expln').html('Track the principal your business owes for a \n\
                loan or line of credit');
        }
    });
    $('#other').click(function () {
        item = 0;
    });
    $('.drop_down').change(function () {
        $('#other').is(':selected');
        var droped = $('.drop_down option:selected').val();
        $('#txt_acc_type_id').val(droped);
        item = droped;
        shall_save_journal(item);
        $('#acc_next').prop('disabled', false);
        if (droped == '6') {
            $('.accounts_expln').html('Tracks money your customer owe you on unpaid invoices;<br/><br/>\n\
                ' + 'Most business require only the A/R account that The system automatically creates<br/>');
        } else if (droped == '10') {
            $('.accounts_expln').html('Track the value of things that can be converted to cash or used up within one year\n\
            ' + ', such as:<br/><br/>\n\
             ' + '<li>Prepaid expenses</li>\n\
             ' + '<li>Employee cash advances</li>\n\
             ' + '<li>Incentory</li>\n\
             ' + '<li>Loans from your business</li>'
                    + '</ul>');
        } else if (droped == '11') {
            $('.accounts_expln').html('Track the value of things that are neither Fixed Assets nor Other Current Assets, such as:<br/><br/>\n\
               ' + '<ul>\n\
                <li>Goodwill</li>\n\
                <li>Long term notes receiveable</li>\n\
                <li>Security de[posits paid</li>\n\
                 \n\
                </ul>');
        } else if (droped == 5) {//Account payable
            $('.accounts_expln').html('Tracks money you owe to vendor for purchase made on credit.<br/>\n\
                <br/>\n\
                Most business require only the A/P account that the system automatically creates.');
        } else if (droped == '12') {//Other current liabilties
            $('.accounts_expln').html('Track money your business owes and expects to pay within one year such as:<br/><br/>\n\
               ' + '<ul>\n\
               ' + '<li>SAles tax</li>\n\
               ' + '<li>Security deposits/retainers from cistomers</li>\n\
                ' + '<li>Payroll taxes</li>\n\
                </ul>');
        } else if (droped == '13') {//Long term liabilities
            $('.accounts_expln').html('Tracks money your business owes and expects to pay back over more than one year, such as:<br/><br/>\n\
             ' + '<ul>\n\
             <li>mortgages</li>\n\
             <li>Long term loans</li>\n\
             <li>Notes payable</li>\n\
              \n\
                </ul>');
        } else if (droped == '14') {//Cost of Goods sold
            $('.accounts_expln').html('Tracks the direct costs to produces the otems that your business sales, such as:<br/><br/>\n\
              \n\
                <ul>\n\
                <li>Cost of materials</li>\n\
                <li>Cost of labor</li>\n\
                <li>shipping, freght and delivery</li>\n\
                <li>Subcontractors</li>\n\
                </ul>');
        } else if (droped == '15') {
            $('.accounts_expln').html('Categorizes money your business erans that is unrelated to normal business operations, such as:\n\
                ' + '<ul>\n\
                <li>Dividend income</li>\n\
                <li>Interest income</li>\n\
                <li>Insurance reimbursements</li>\n\
                </ul>');
        } else if (droped == '16') {
            $('.accounts_expln').html('Categorizes money your business spends that is unrelated to normal business operations, such as:<br/><br/>\n\
            ' + '<ul>\n\
            <li>Corporation taxes</li>\n\
            <li>Penalities and legal settlements</li>\n\
            </ul>');
        }
    });
    $('#acc_next').click(function () {
        if (item != 0) {
            accountid = $('#txt_acc_type_id').val();
            var cont = 'c';
            $('.tb_rows').hide(0, function () {
                if (item == '1' || item == '2') {
                    $('.next_row').show();
                    $('.next_button').show();

                    $('.acc_bo_row').hide();
                    $('.opn_b_row').hide();
                } else {
                    $('.next_row').show();
                    $('.next_button').show();
                }

            });

            //$.post('../admin/handler.php', {accountid: accountid}, function (data) {
//                alert(data);
//            }).complete(function () {
//
//            });
        } else {
            alert('You have to choose the account type');
        }

    });

}

function shall_save_journal(item) {
    if (item != 1 && item != 2) {
        //tell that we shall save in the journal (already a transaction)
        $('#txt_if_save_Journal').val('yes');
    } else {
        $('#txt_if_save_Journal').val('');
    }
}
function click_acc_table() {
    $('.dataList_table tr').click(function () {
//        $('.ftd').css('background', 'none').css('color', '#000');
//        $(this).css('background-color', '#178d31').css('color', '#fff');
    });
}
function hide_menu() {
    $('.hide_menu').click(function () {
        $('#header2').slideToggle();
        $('.changing_title').slideToggle();
    });
}
function changed_acc_type_combo() {
    $('.cbo_account').change(function () {
        var cbo_account = $('.cbo_account option:selected').val();
        $('#txt_account_id').val(cbo_account);
        $('#txt_subacc_id').val(cbo_account);
        $('#txt_chart_account_id').val(cbo_account);
        $('#txt_acc_type_id').val(cbo_account);

    });
}
function other_accounts() {
    $('#other').click(function () {
        $('.drop_down').prop('disabled', false);
    });
}
function sub_account_checkbox() {
    $('#check_acc').on('change', function () {
        if ($(this).is(':checked')) {
            $('.cbo_account').prop('disabled', false);
        } else {
            $('.cbo_account').prop('disabled', true);
        }
    });
}
function opening_balance_btn() {
    $('#balance_btn').click(function () {
        $('.abs_full').fadeIn(function () {
            item_center('other_pane');
            $('.other_pane').slideDown(100);
        });
        return false;
    });
}
function cancel_opening_balance() {
    $('.js_cancel_btn').click(function () {
        $('.other_pane').slideUp(100, function () {
            $('.abs_full').fadeOut();
        });
    });
}
function cancel_acctype_step1_2() {
    $('.cancel_acc_type').click(function () {
        window.location.reload();
    });
}
function defaults() {
    item_center('other_pane');
    //    var left_margin=$();
    //    $('.other_pane').css('margin-left',parent_width);
}
function item_center(item) {// it is supposed that these items are inside "abs full" idv
    var parent_width = $('.' + item).parent().width();
    var parent_height = $('.abs_full').height();
    var item_w = $('.' + item).width();
    var item_h = $('.' + item).height();
    var left_space = (parent_width - item_w) / 2;
    var top_space = (parent_height - item_h) / 4;
    $('.' + item).css('margin-left', left_space);
    $('.' + item).css('margin-top', top_space);
}
function other_pane_ok() {//opening balance ok buttons
    $('#opn_balnce_btn').click(function () {
        var end_balance = $('#ending_balance').val();
        var end_date = $('#ending_date').val();
        if (end_balance != '' && end_date != '') {
            $('#txt_end_balance_id').val(end_balance);
            $('#txt_end_date_id').val(end_date);
            //clear fields
            $('#ending_balance').val('');
            $('#ending_date').val('');
            //hide the pane and full bg
            $('.other_pane').slideUp(100, function () {
                $('.abs_full').fadeOut();
            });
        }
    });
}
//</editor-fold>

//<editor-fold defaultstate="collapsed" desc="-----projects -----------">
function Projects() {
    select_a_budget();
    choose_budget();
    select_project();
    proj_select_link();
    select_item();
    show_items();
    get_proj_type_select();
}
function select_a_budget() {
    $('.p_budget_select_link').click(function () {
        var budget_id = $(this).data('bud_id');
        $('#txt_budget_id').val(budget_id);
        $('.selectable_table').hide(20);
        $('.new_data_table').show(20);
    });
}
function select_project() {
    $('.p_project_select_link').click(function () {
        var proj_id = $(this).data('proj_id');
        $('#txt_project_id').val(proj_id);
        $('.new_data_table').show(20);
        $('.selectable_table').hide();
    });
}
function proj_select_link() {
    $('.proj_select_link').click(function () {

        $('.new_data_table').hide(20);
        $('.selectable_table').show(20);

    });
}

function select_item() {
    $('.p_budget_items_select_link').click(function () {
        var itemid = $(this).data('item_id');
        $('#txt_item_id').val(itemid);
        $('.selectable_table').hide(20);
        $('.new_data_table').show(20);
    });
}
function show_items() {
    $('#item_link').click(function () {
        $('.selectable_table').show(20);
        $('.new_data_table').hide(20);
    });
}
function choose_budget() {
    $('#choose_budget_again').click(function () {
        $('.selectable_table').show(20);
        $('.new_data_table').hide(20);
    });
}

//</editor-fold>

//<editor-fold defaultstate="collapsed" desc="-----Journal entry line-----">
function get_new_account_from_combo() {
    $('.cbo_account_arr').change(function () {
        var item = $(this, 'option:selected').val();
        if (item === 'new_item') {
            $('.acc_bo_row').hide();
            $('.next_button').hide();
            $('.second_pane').hide(20);
            $('.first_pane').show(10);
            $('.tb_rows').show(10);
            $('.next_row').hide();
            $('.radios').prop('checked', false);
            new_account_pane();

        }
    });
}
function get_proj_type_select() {
    $('.p_type_project_select_link').click(function () {
        var typeid = $(this).data('type_id');
        $('#txt_type_project_id').val(typeid);
        $('.selectable_table').hide(20);
        $('.new_data_table').show(20);
    });
}
function get_second_pane() {
    $('.second_pane_caller').click(function () {
        $('.first_pane').slideUp(20);
        item_center('second_pane');
        $('.second_pane').slideDown(20);

    });
}
function ok_opening_bal() {
    $('.ok_opening').click(function () {
        end_balance = $('#ending_balance').val();
        end_date = $('#ending_date').val();
        if (end_balance != '' && end_date != '') {
            $('#txt_end_balance_id').val(end_balance);
            $('#txt_end_date_id').val(end_date);
            //clear fields
            $('#ending_balance').val('');
            $('#ending_date').val('');
            //hide the second pane and show the first pane
            $('.second_pane').slideUp(100, function () {
                $('.first_pane').slideDown(10);
            });

        }
    });
}
function save_close() {//while adding new account
    $('.save_close').click(function () {
        if (end_balance !== '') {
            var save_account = 'c';

            $.post('../admin/handler.php', {save_account: save_account, end_balance: end_balance, end_date: end_date}, function (data) {
                alert('reached: ' + data);
            }).complete(function () {

            });
        } else {

        }

    });
}
//</editor-fold>
//<editor-fold defaultstate="collapsed" desc="----Budget implementatioon---------">
function budget() {
    select_fical_year();
}
function select_fical_year() {
    $('#selct_f_year').click(function () {
//        var activity = $('.cbo_fisc_year option:selected').val();
        var the_year_name = $('.cbo_fisc_year option:selected').text();
        var selected_activity = 'c';
        var activity = $('.cbo_activity option:selected').val().trim();
        if (activity % 1 !== 0) {
            alert('You have to select an activity');
        } else {
            $('.new_data_table').show(2);
            $.post('handler.php', {selected_activity: selected_activity, activity: activity}, function (data) {
//            alert('From handler: '+ data);
            }).complete(function () {
                $('.thehidden_part').show(20);
                $('.selectable_table').hide(20);
                $('.new_data_box').slideDown(300);
                $(window).scrollTop(170);

            });
        }
    });
    $('.back_wiz').click(function () {
//        $('.thehidden_part').hide(20);
        $('.selectable_table').show(20);
        $('.rehide').hide(1);
        return false;
    });
    $('.select_activity_purchase_order_line').click(function () {
        var on_from_purchase_order_line = 'on_from_purchase_order_line';
        $.post('../admin/handler.php', {on_from_purchase_order_line: on_from_purchase_order_line}, function (data) {

        }).complete(function () {

            window.location.reload(2);
        });
    });
    $('.select_activity_purchase_invoice_line').click(function () {
        var on_from_purchase_invoice_line = 'on_from_purchase_invoice_line';
        $.post('../admin/handler.php', {on_from_purchase_invoice_line: on_from_purchase_invoice_line}, function (data) {

        }).complete(function () {

            window.location.reload(2);
        });
    });
    $('.select_activity_sales_invoice_line').click(function () {
        var on_from_sales_invoice_line = 'on_from_sales_invoice_line';
        $.post('../admin/handler.php', {on_from_sales_invoice_line: on_from_sales_invoice_line}, function (data) {

        }).complete(function () {

            window.location.reload(2);
        });
    });
}
function get_activityy_by_proj() {
    $('.cbo_proj_refill').change(function () {
        var act_by_proj = $(this, 'option:selected').val().trim();
        $('.tobe_refilled').empty();
        $('#onfly_selected_project').val();
        $('.tobe_refilled').append('<option value="fly_new_p_activity"> -- Add new -- </option>');
        $.post('../admin/handler.php', {act_by_proj: act_by_proj}, function (data) {
            var final = $.parseJSON(data.trim());
            $.each(final, function (i, option) {
                $('.tobe_refilled').append($('<option/>').attr("value", option.id).text(option.name));
            });
        });
    });
}
function get_cbo_refil_changed() {
    $('.tobe_refilled').change(function () {
        var item = $(this, 'option:selected').val().trim();
        $('#txt_selected_activity_id').val(item);
    });
}

//</editor-fold>
////<editor-fold defaultstate="collapsed" desc="---Biudget preparation---">
function get_rev_expenses_combo() {
    $('.dcbo_rev_expeses').change(function () {
        var item = $(this, 'option:selected').val();
    });
}

function show_rep_details() {
    $('.details').click(function () {

        $(this).children('span').slideToggle();
    });
}
//</editor-fold>
//<editor-fold defaultstate="collapsed" desc="----Customers-----">
function get_cbo_acc_rec_accid() {
    $('.cbo_acc_rec_accid').change(function () {
        var acc = $('.cbo_acc_rec_accid option:selected').val();

    });
}
function new_account_pane() {
    $('.abs_full').fadeIn(function () {
        item_center('other_pane');
        $('.other_pane').slideDown(100);
    });
    return false;
}
//</editor-fold>

function slideUp_figures() {

    $('.pages_bottom').show(300);
}

function hide_footer() {
    $(window).load(function () {
        $('.footer').hide();
    });
}
function get_index_session() {
    var get_menu_index = 'c';
    $.post('handler.php', {get_menu_index: get_menu_index}, function (data) {
        menu_index = data;
    }).complete(function () {

//        $('#navigated_menu').val(menu_index);
        if (menu_index == 0) {
            $('.main_link_budgt').children('span').slideDown(50);
        } else if (menu_index == 1) {
            $('.main_link_implmnt').children('span').slideDown(50);
        } else if (menu_index == 2) {
            $('.main_link_financ').children('span').slideDown(50);
        } else if (menu_index == 3) {
            $('.main_link_sales').children('span').slideDown(50);
        } else if (menu_index == 4) {
            $('.main_link_purhcase').children('span').slideDown(50);
        } else if (menu_index == 5) {
            $('.main_link_stock').children('span').slideDown(50);
        } else if (menu_index == 6) {
            $('.main_link_reporting').children('span').slideDown(50);
        } else if (menu_index == 7) {
            $('.main_link_settings').children('span').slideDown(50);
        }
    });
}
function keep_menu_open() {


}

function chk_puronvoice() {
    $('#chk_puronvoice').change(function () {
        if ($(this).is(':checked')) {
            $("#txt_quantity").prop("disabled", true);
            $('.hidable').slideDown(10);
            $('#txt_quantity').val('');
        } else {
            $("#txt_quantity").prop("disabled", false);
            $('.hidable').slideUp(10);

        }
    });
}
function request_auto_typing() {
    $('#txt_unitc1').keyup(function () {
        var qty = $('#txt_qty1').val();
        $('#txt_amnt1').val($(this).val() * qty);
    });
    $('#txt_unitc2').keyup(function () {
        var qty = $('#txt_qty2').val();
        $('#txt_amnt2').val($(this).val() * qty);
    });
    $('#txt_unitc3').keyup(function () {
        var qty = $('#txt_qty3').val();
        $('#txt_amnt3').val($(this).val() * qty);
    });
    $('#txt_unitc4').keyup(function () {
        var qty = $('#txt_qty4').val();
        $('#txt_amnt4').val($(this).val() * qty);
    });
    $('#txt_unitc5').keyup(function () {
        var qty = $('#txt_qty5').val();
        $('#txt_amnt5').val($(this).val() * qty);
    });
    $('#txt_unitc6').keyup(function () {
        var qty = $('#txt_qty7').val();
        $('#txt_amnt7').val($(this).val() * qty);
    });
    $('#txt_unitc7').keyup(function () {
        var qty = $('#txt_qty8').val();
        $('#txt_amnt8').val($(this).val() * qty);
    });
    $('#txt_unitc8').keyup(function () {
        var qty = $('#txt_qty9').val();
        $('#txt_amnt9').val($(this).val() * qty);
    });
    $('#txt_unitc9').keyup(function () {
        var qty = $('#txt_qty9').val();
        $('#txt_amnt9').val($(this).val() * qty);
    });
    $('#txt_unitc10').keyup(function () {
        var qty = $('#txt_qty10').val();
        $('#txt_amnt10').val($(this).val() * qty);
    });
    $('#txt_unitc11').keyup(function () {
        var qty = $('#txt_qty11').val();
        $('#txt_amnt11').val($(this).val() * qty);
    });
    $('#txt_unitc11').keyup(function () {
        var qty = $('#txt_qty12').val();
        $('#txt_amnt12').val($(this).val() * qty);
    });
    $('#txt_unitc12').keyup(function () {
        var qty = $('#txt_qty12').val();
        $('#txt_amnt12').val($(this).val() * qty);
    });
}
function show_alerts() {// these are the unfinished processes
    $('.pre_alert').click(function () {
        $('.alert_pane').fadeIn();
    });


}
function alert_unfished_nav() {
    $('.issue_title, .data_details_pane_close_btn').click(function () {
        $('.alert_pane').fadeOut(200);
    });
}

 
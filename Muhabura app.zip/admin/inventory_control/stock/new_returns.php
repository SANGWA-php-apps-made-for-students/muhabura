<?php
    session_start();
    require_once '../web_db/multi_values.php';
    if (!isset($_SESSION)) {
        session_start();
    }if (!isset($_SESSION['login_token'])) {
        header('location:../index.php');
    }
    if (isset($_POST['send_returns'])) {
        if (isset($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'returns') {
                require_once '../web_db/updates.php';
                $upd_obj = new updates();
                $returns_id = $_SESSION['id_upd'];
                $source_stock = trim($_POST['txt_source_stock_id']);
                $destination_stock = $_POST['txt_destination_stock_id'];
                $item = $_POST['txt_item_id'];
                $remaining_qty = $_POST['txt_remaining_qty'];
                $entry_date = date("y-m-d");
                $User = $_SESSION['userid'];
                $upd_obj->update_returns($source_stock, $destination_stock, $item, $remaining_qty, $entry_date, $User, $returns_id);
                unset($_SESSION['table_to_update']);
            }
        } else {
            require_once '../web_db/new_values.php';
            require_once '../web_db/updates.php';
            $source_stock = trim($_POST['txt_source_stock_id']);
            $destination_stock = 8; //This is the main stock
            $item = trim($_POST['txt_item_id']);
            $returned_qty = $_POST['txt_returned_qty'];
            $entry_date = date("y-m-d");
            $User = $_SESSION['userid'];

            //update the main stock
            $m = new multi_values();
            $upd = new updates();
            $obj = new new_values();
            $sml1_old_qty = $m->get_samllstock_old_qty($item, $source_stock);

            if ($sml1_old_qty < $returned_qty) {
                ?><script>alert('The quantity you want to return is bigger than the existing. The Source stock only has: <?php echo $sml1_old_qty ?>');</script><?php
            } else {
                //main stock
                $old_qty = $m->get_mainstock_old_qty($item);
                $mainstock_new_qty = $old_qty + $returned_qty;
                $upd->update_main_stock_qty($mainstock_new_qty, $item);

                //Update the small stock
                $smalstock_new_qty = $sml1_old_qty - $returned_qty;
                $upd->update_smal_stock_status_qty($smalstock_new_qty, $source_stock, $item);
                $obj->new_returns($source_stock, $destination_stock, $item, $returned_qty, $entry_date, $User);
            }
        }
    }
?>

<html>
    <head>
        <meta charset="UTF-8">
        <title>
            returns</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/> <link href="admin_style.css" rel="stylesheet" type="text/css"/>
        <meta name="viewport" content="width=device-width, initial scale=1.0"/>
    </head>
    <body>
        <form action="new_returns.php" method="post" enctype="multipart/form-data">
            <input type="hidden" id="txt_shall_expand_toUpdate" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim($_SESSION['table_to_update']) : '' ?>" />
            <!--this field  (shall_expand_toUpdate)above is for letting the form expand using js for updating-->

            <input type="hidden" id="txt_source_stock_id"   name="txt_source_stock_id"/>
            <input type="hidden" id="txt_destination_stock_id"   name="txt_destination_stock_id"/>
            <input type="hidden" id="txt_item_id"   name="txt_item_id"/>
            <?php
                include 'admin_header.php';
                $ot = new other_fx();
                $ot->get_searchNew_menu('more returns', without_admin());
            ?>
            <!--Start dialog's-->
            <div class = "parts abs_full y_n_dialog off">
                <div class = "parts dialog_yes_no no_paddin_shade_no_Border reverse_border">
                    <div class = "parts full_center_two_h heit_free margin_free skin">
                        Do you really want to delete this record?
                    </div>
                    <div class = "parts full_center_two_h heit_free no_paddin_shade_no_Border top_off_x margin_free">
                        <div class = "parts yes_no_btns no_shade_noBorder reverse_border left_off_xx link_cursor yes_dlg_btn" id = "citizen_yes_btn">Yes</div>
                        <div class = "parts yes_no_btns no_shade_noBorder reverse_border left_off_seventy link_cursor no_btn" id = "no_btn">No</div>
                    </div>
                </div>
            </div>
            <!--End dialog-->

            <div class = "parts eighty_centered off saved_dialog">
                returns saved successfully!
            </div>

            <div class = "parts eighty_centered new_data_box off">
                <div class = "parts eighty_centered new_data_title"> returns Items </div>
                <table class = "new_data_table">
                    <tr><td class="new_data_tb_frst_cols">Destination Stock </td><td> <input type="text" class="textbox" name="txt_destination_stock" disabled value="Muhabura"  />  </td></tr>
                    <tr><td class = "new_data_tb_frst_cols">Source Stock </td><td> <?php get_source_stock_combo();
            ?>  </td></tr> 
                    <tr><td class="new_data_tb_frst_cols">Item </td><td> 
                            <select class="textbox item_cbo_to_fill">
                                <option></option>
                            </select>
                            <?php // get_items_in_combo(); ?> 

                        </td></tr><tr><td><label for="txt_returned_qty">Remaining Quantity </label></td><td> <input type="text"     name="txt_returned_qty" required id="txt_remaining_qty" class="textbox" value="<?php echo trim(chosen_remaining_qty_upd()); ?>"   />  </td></tr>
                    <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_returns" value="Save"/>  </td></tr>
                </table>
            </div>


            <div class="parts eighty_centered datalist_box" >
                <div class="parts no_shade_noBorder xx_titles no_bg whilte_text dataList_title">returns List</div>
                <?php
                    $obj = new multi_values();
                    $obj->list_returns();
                ?>
            </div>  
        </form> <div class="parts no_paddin_shade_no_Border export_box  eighty_centered heit_free">
            <form action="../web_exports/returns.php" method="post">
                <input type="submit" name="returns" class="exprt_btn  exprt_btn_returns" value="Export to Excel"/>
            </form>
        </div>
        <div class="parts eighty_centered  no_paddin_shade_no_Border no_shade_noBorder check_loaded" >
            <?php require_once './navigation/add_nav.php'; ?> 
        </div>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="admin_script.js" type="text/javascript"></script> 
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
        <script src="../../../web_scripts/searches.js" type="text/javascript"></script>
        <script>
                    $('.dbo_return_items_cbo').change(function () {
                        try {
                            var the_item = $(this, ' option:changed').val();
                            var get_items_by_stock = the_item;

                            $('.item_cbo_to_fill').empty();
                            $('.item_cbo_to_fill').append('<option></option>');
                            $.post('handler.php', {get_items_by_stock: get_items_by_stock}, function (data) {
                                var final = $.parseJSON(data);
                                $.each(final, function (i, option) {
                                    $('.item_cbo_to_fill').append($('<option/>').attr("value", option.id).text(option.name));
                                });
                            }).complete(function () {

                            });
                        } catch (err) {
                            alert(err.message);
                        }

                    });
        </script>
        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
    </body>
</hmtl>
<?php

    function get_destination_stock_combo() {
        $obj = new multi_values();
        $obj->get_destination_stock_in_combo();
    }

    function get_source_stock_combo() {
        $obj = new multi_values();
        $obj->get_source_stock_in_js_combo();
    }

    function get_items_in_combo() {
        require_once '../web_db/multi_values.php';
        $ot = new multi_values();
        $ot->get_mainstock_items_in_combo();
    }

    function chosen_source_stock_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'returns') {
                $id = $_SESSION['id_upd'];
                $source_stock = new multi_values();
                return $source_stock->get_chosen_returns_source_stock($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_destination_stock_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'returns') {
                $id = $_SESSION['id_upd'];
                $destination_stock = new multi_values();
                return $destination_stock->get_chosen_returns_destination_stock($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_item_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'returns') {
                $id = $_SESSION['id_upd'];
                $item = new multi_values();
                return $item->get_chosen_returns_item($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_remaining_qty_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'returns') {
                $id = $_SESSION['id_upd'];
                $remaining_qty = new multi_values();
                return $remaining_qty->get_chosen_returns_remaining_qty($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_entry_date_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'returns') {
                $id = $_SESSION['id_upd'];
                $entry_date = new multi_values();
                return $entry_date->get_chosen_returns_entry_date($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_User_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'returns') {
                $id = $_SESSION['id_upd'];
                $User = new multi_values();
                return $User->get_chosen_returns_User($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }
    
<?php
    session_start();
    require_once '../web_db/multi_values.php';
    if (!isset($_SESSION)) {
        session_start();
    }if (!isset($_SESSION['login_token'])) {
        header('location:../index.php');
    }
    if (isset($_POST['send_small_stock'])) {
        if (isset($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'small_stock') {
                require_once '../web_db/updates.php';
                $upd_obj = new updates();
                $small_stock_id = $_SESSION['id_upd'];

                $quantity = $_POST['txt_quantity'];
                $available_qty = $_POST['txt_available_qty'];
                $in_or_out = $_POST['txt_in_or_out'];
                $measurement = $_POST['txt_measurement_id'];
                $item = $_POST['txt_item_id'];
                $entry_date = date("y-m-d");
                $User = $_SESSION['userid'];
                $location = filter_input(INPUT_POST, 'txt_location');
                $upd_obj->update_small_stock($quantity, $available_qty, $in_or_out, $measurement, $item, $entry_date, $User, $small_stock_id);
                unset($_SESSION['table_to_update']);
            }
        } else {
            $quantity = 0;
            $available_qty = 0;
            $in_or_out = 'in';
            $measurement = 0;
            $item = 0;
            $entry_date = date("y-m-d");
            $User = $_SESSION['userid'];
            $location = filter_input(INPUT_POST, 'txt_location');
            $name = filter_input(INPUT_POST, 'txt_name');
            require_once '../web_db/new_values.php';
            $obj = new new_values();
            $obj->new_small_stock($quantity, $available_qty, $in_or_out, $measurement, $item, $entry_date, $User, $location, $name);
        }
    }
?>

<html>
    <head>
        <meta charset="UTF-8">
        <title>
            small_stock</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/> <link href="admin_style.css" rel="stylesheet" type="text/css"/>
        <meta name="viewport" content="width=device-width, initial scale=1.0"/>
    </head>
    <body>
        <form action="new_small_stock.php" method="post" enctype="multipart/form-data">
            <input type="hidden" id="txt_shall_expand_toUpdate" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim($_SESSION['table_to_update']) : '' ?>" />
            <!--this field  (shall_expand_toUpdate)above is for letting the form expand using js for updating-->

            <input type="hidden" id="txt_measurement_id"   name="txt_measurement_id"/>
            <input type="hidden" id="txt_item_id"   name="txt_item_id"/>
            <?php
                include 'admin_header.php';
                $ot = new other_fx();
                $ot->get_searchNew_menu('small stock', without_admin());
            ?>

            <!--Start dialog's-->
            <div class="parts abs_full y_n_dialog off">
                <div class="parts dialog_yes_no no_paddin_shade_no_Border reverse_border">
                    <div class="parts full_center_two_h heit_free margin_free skin">
                        Do you really want to delete this record?
                    </div>
                    <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border top_off_x margin_free">
                        <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_xx link_cursor yes_dlg_btn" id="citizen_yes_btn">Yes</div>
                        <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_seventy link_cursor no_btn" id="no_btn">No</div>
                    </div>
                </div>
            </div>   
            <!--End dialog-->


            <div class="parts eighty_centered off saved_dialog">
                small_stock saved successfully!
            </div>
            <div class="parts eighty_centered new_data_box off">
                <div class="parts eighty_centered new_data_title">  small stock Registration </div>
                <table class="new_data_table">
                    <tr><td><label for="txt_quantity">Name </label></td><td> <input type="text"     name="txt_name" required id="txt_name" class="textbox" value="<?php echo trim(chosen_quantity_upd()); ?>"   />  </td></tr>
                    <tr class="off"><td><label for="txt_quantity">Initial Quantity </label></td><td> <input type="text"     name="txt_quantity"  id="txt_quantity" class="textbox" value="<?php echo trim(chosen_quantity_upd()); ?>"   />  </td></tr>
                    <tr class="off"><td><label for="txt_available_qty">Available quantity </label></td><td> <input type="text"     name="txt_available_qty"  id="txt_available_qty" class="textbox" value="<?php echo trim(chosen_available_qty_upd()); ?>"   />  </td></tr>
                    <tr class="off"><td class="new_data_tb_frst_cols">Measurement </td><td> <?php get_measurement_combo(); ?>  </td></tr>
                    <tr class="off"><td class="new_data_tb_frst_cols">Item </td><td> <?php get_items_in_combo(); ?>  </td></tr>
                    <tr><td class="new_data_tb_frst_cols">Location(Sector,District) </td><td> <input type="text" class="textbox" name="txt_location"/>  </td></tr> 

                    <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_small_stock" value="Save"/>  </td></tr>
                </table>
            </div>

            <div class="parts eighty_centered datalist_box" >
                <div class="parts no_shade_noBorder xx_titles no_bg whilte_text dataList_title">All small stocks</div>
                <?php
                    $obj = new multi_values();
                    $first = $obj->get_first_small_stock();
                    $obj->list_small_stock($first);
                ?>
            </div>  
        </form>
        <div class="parts no_paddin_shade_no_Border export_box  eighty_centered heit_free">
            <form action="../web_exports/small_stock.php" method="post">
                <input type="submit" name="small_stock" class="exprt_btn  exprt_btn_small_stock" value="Export to Excel"/>
            </form>
        </div>
        <div class="parts eighty_centered  no_paddin_shade_no_Border no_shade_noBorder check_loaded" >
            <?php require_once './navigation/add_nav.php'; ?> 
        </div>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="admin_script.js" type="text/javascript"></script> 
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
        <script src="../../../web_scripts/searches.js" type="text/javascript"></script>
        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
    </body>
</hmtl>
<?php

    function sectors_combo() {
        $obj = new multi_values();
        $obj->get_sector_in_combo();
    }

    function Cell_in_combo() {
        $obj = new multi_values();
        $obj->get_cell_in_combo();
    }

    function get_measurement_combo() {
        $obj = new multi_values();
        $obj->get_measurement_in_combo();
    }

    function get_items_in_combo() {
        require_once '../web_db/multi_values.php';
        $ot = new multi_values();
        $ot->get_items_in_combo();
    }

    function chosen_quantity_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'small_stock') {
                $id = $_SESSION['id_upd'];
                $quantity = new multi_values();
                return $quantity->get_chosen_small_stock_quantity($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_available_qty_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'small_stock') {
                $id = $_SESSION['id_upd'];
                $available_qty = new multi_values();
                return $available_qty->get_chosen_small_stock_available_qty($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_in_or_out_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'small_stock') {
                $id = $_SESSION['id_upd'];
                $in_or_out = new multi_values();
                return $in_or_out->get_chosen_small_stock_in_or_out($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_measurement_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'small_stock') {
                $id = $_SESSION['id_upd'];
                $measurement = new multi_values();
                return $measurement->get_chosen_small_stock_measurement($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_item_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'small_stock') {
                $id = $_SESSION['id_upd'];
                $item = new multi_values();
                return $item->get_chosen_small_stock_item($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_entry_date_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'small_stock') {
                $id = $_SESSION['id_upd'];
                $entry_date = new multi_values();
                return $entry_date->get_chosen_small_stock_entry_date($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_User_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'small_stock') {
                $id = $_SESSION['id_upd'];
                $User = new multi_values();
                return $User->get_chosen_small_stock_User($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }
    
<?php
    session_start();
    require_once '../web_db/multi_values.php';
    if (!isset($_SESSION)) {
        session_start();
    }if (!isset($_SESSION['login_token'])) {
        header('location:../index.php');
    }
    if (isset($_POST['send_main_stock'])) {
        if (isset($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'main_stock') {
                require_once '../web_db/updates.php';
                $upd_obj = new updates();
                $main_stock_id = $_SESSION['id_upd'];
                $item = trim($_POST['txt_item_id']);
                $quantity = $_POST['txt_quantity'];
                $available_qty = $_POST['txt_available_qty'];
                $in_or_out = $_POST['txt_in_or_out'];
                $measurement = $_POST['txt_measurement_id'];
                $entry_date = date("y-m-d");
                $User = $_SESSION['userid'];
                $upd_obj->update_main_stock($item, $quantity, $available_qty, $in_or_out, $measurement, $entry_date, $User, $main_stock_id);
                unset($_SESSION['table_to_update']);
            }
        } else {
            $item = trim($_POST['txt_item_id']);
            $quantity = $_POST['txt_quantity'];

            $in_or_out = 'in';
            $measurement = trim($_POST['txt_measurement_id']);
            $entry_date = date("Y-m-d h:m:s");
            $User = $_SESSION['userid'];
            $unit_cost = filter_input(INPUT_POST, 'txt_unit_cost');
            $tot = $unit_cost * $quantity;

            $m = new multi_values();
            $old_qty = $m->get_mainstock_old_qty($item);
            $old_amnt = $m->get_mainstock_old_amount($item);
            $new_qty = $quantity + $old_qty;
            $new_amnt = $tot + $old_amnt;

            require_once '../web_db/new_values.php';
            require_once '../web_db/updates.php';
            $obj = new new_values();
            $upd = new updates();
            $obj->new_main_stock($item, $quantity, $new_qty, $in_or_out, $measurement, $entry_date, $User, $unit_cost, $new_amnt);
        }
    }
?>

<html>
    <head>
        <meta charset="UTF-8">
        <title>
            main_stock
        </title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <link href="admin_style.css" rel="stylesheet" type="text/css"/>
        <meta name="viewport" content="width=device-width, initial scale=1.0"/>
    </head>
    <body>
        <form action="new_main_stock.php" method="post" enctype="multipart/form-data">
            <input type="hidden" id="txt_shall_expand_toUpdate" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim($_SESSION['table_to_update']) : '' ?>" />
            <!--this field  (shall_expand_toUpdate)above is for letting the form expand using js for updating-->

            <input type="hidden" id="txt_item_id"   name="txt_item_id"/>
            <input type="hidden" id="txt_measurement_id"   name="txt_measurement_id"/>
            <?php
                include 'admin_header.php';
                $ot = new other_fx();
                $ot->get_searchNew_menu('more items in main stock', without_admin());
            ?>

            <!--Start dialog's-->
            <div class="parts abs_full y_n_dialog off">
                <div class="parts dialog_yes_no no_paddin_shade_no_Border reverse_border">
                    <div class="parts full_center_two_h heit_free margin_free skin">
                        Do you really want to delete this record?
                    </div>
                    <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border top_off_x margin_free">
                        <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_xx link_cursor yes_dlg_btn" id="citizen_yes_btn">Yes</div>
                        <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_seventy link_cursor no_btn" id="no_btn">No</div>
                    </div>
                </div>
            </div>   
            <!--End dialog-->

            <div class="parts eighty_centered off saved_dialog">
                main_stock saved successfully!
            </div>
            <div class="parts eighty_centered datalist_box" >
                <div class="parts no_shade_noBorder xx_titles no_bg whilte_text dataList_title">Add more items in Main stock</div>
                <?php
                    $obj = new multi_values();
                    $first = $obj->get_first_main_stock();
                    $obj->list_main_stock($first);
                ?>
            </div>  
        </form>
        <div class="parts no_paddin_shade_no_Border export_box  eighty_centered heit_free off">
            <form action="../web_exports/main_stock.php" method="post">
                <input type="submit" name="main_stock" class="exprt_btn  exprt_btn_main_stock" value="Export to Excel"/>
            </form>
        </div>
        <div class="parts eighty_centered  no_paddin_shade_no_Border no_shade_noBorder check_loaded" >
            <?php require_once './navigation/add_nav.php'; ?> 
        </div>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="admin_script.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
        <script src="../../../web_scripts/searches.js" type="text/javascript"></script>
        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
    </body>
</hmtl>
<?php

    function get_measurement_combo() {
        $obj = new multi_values();
        $obj->get_measurement_in_combo();
    }

    function get_item_combo() {
        $obj = new multi_values();
        $obj->get_item_in_combo();
    }

    function chosen_item_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'main_stock') {
                $id = $_SESSION['id_upd'];
                $item = new multi_values();
                return $item->get_chosen_main_stock_item($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_quantity_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'main_stock') {
                $id = $_SESSION['id_upd'];
                $quantity = new multi_values();
                return $quantity->get_chosen_main_stock_quantity($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_available_qty_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'main_stock') {
                $id = $_SESSION['id_upd'];
                $available_qty = new multi_values();
                return $available_qty->get_chosen_main_stock_available_qty($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_in_or_out_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'main_stock') {
                $id = $_SESSION['id_upd'];
                $in_or_out = new multi_values();
                return $in_or_out->get_chosen_main_stock_in_or_out($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_measurement_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'main_stock') {
                $id = $_SESSION['id_upd'];
                $measurement = new multi_values();
                return $measurement->get_chosen_main_stock_measurement($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_entry_date_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'main_stock') {
                $id = $_SESSION['id_upd'];
                $entry_date = new multi_values();
                return $entry_date->get_chosen_main_stock_entry_date($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_User_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'main_stock') {
                $id = $_SESSION['id_upd'];
                $User = new multi_values();
                return $User->get_chosen_main_stock_User($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_unit_cost_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'main_stock') {
                $id = $_SESSION['id_upd'];
                $unit_cost = new multi_values();
                return $unit_cost->get_chosen_main_stock_unit_cost($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_total_amount_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'main_stock') {
                $id = $_SESSION['id_upd'];
                $total_amount = new multi_values();
                return $total_amount->get_chosen_main_stock_total_amount($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }
    
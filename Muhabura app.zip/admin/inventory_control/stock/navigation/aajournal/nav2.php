<div class="parts eighty_centered x_height_3x pages page1">

</div>
<div class="parts eighty_centered x_height_3x pages page2">

</div>
<div class="parts eighty_centered x_height_3x pages page3">

</div>
<div class="parts eighty_centered x_height_3x pages page4">

</div>
<div class="parts eighty_centered x_height_3x pages page5">

</div>
<div class="parts eighty_centered x_height_3x pages page6">

</div>
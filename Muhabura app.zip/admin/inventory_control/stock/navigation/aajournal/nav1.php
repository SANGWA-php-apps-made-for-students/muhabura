<div class="parts eighty_centered x_height_3x journal_sub_p pages page1">
    <a href="new_journal_entry_line.php">
        <div class="parts full_center_two_h heit_free margin_free link_cursor no_shade_noBorder sbu2_link">

        </div>
    </a>
    <a href="report_journal_entry.php">
        <div class="parts full_center_two_h heit_free margin_free link_cursor no_shade_noBorder sbu2_link">
            <?php
                require_once '../web_db/multi_values.php';
                $obj = new multi_values();
                $first = $obj->get_first_journal_entry_line();
            ?>
        </div>
    </a>
    <div class="parts pages_bottom link_cursor">View details</div>
</div>
<div class="parts eighty_centered x_height_3x journal_sub_p pages page2">

</div>
<div class="parts eighty_centered x_height_3x journal_sub_p pages page3">

</div>
<div class="parts eighty_centered x_height_3x journal_sub_p pages page4">

</div>
<div class="parts eighty_centered x_height_3x journal_sub_p pages page5">

</div>

 
<div class="parts full_center_two_h heit_free no_paddin_shade_no_Border no_bg  ">
    <div class="parts eighty_centered x_height_3x charts_acc pages  page1">
        <a href="new_account.php">
            <div class="parts full_center_two_h heit_free margin_free link_cursor no_shade_noBorder sbu2_link">
                All accounts
            </div>
        </a>
        <a href="#">
            <div class="parts full_center_two_h heit_free margin_free link_cursor no_shade_noBorder sbu2_link">
                Add account
            </div>
        </a>
        <a href="#">
            <div class="parts full_center_two_h heit_free margin_free link_cursor no_shade_noBorder sbu2_link">
                Edit account
            </div>
        </a>
        <div class="parts pages_bottom link_cursor">View details</div>
    </div>
    <div class="parts eighty_centered x_height_3x charts_acc pages  page2">
        <a href="#">
            <div class="parts full_center_two_h heit_free margin_free link_cursor no_shade_noBorder sbu2_link">
                <ul>
                    <li> Active accounts  <br/>32</li>
                </ul>
            </div>
        </a>
    </div>
    <div class="parts eighty_centered x_height_3x charts_acc pages  page3">

    </div>
    <div class="parts eighty_centered x_height_3x charts_acc pages  page4">

    </div>
    <div class="parts eighty_centered x_height_3x charts_acc pages  page5">

    </div>
</div>
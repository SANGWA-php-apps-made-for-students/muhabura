<div class="parts full_center_two_h heit_free no_paddin_shade_no_Border no_bg  ">
    <div class="parts eighty_centered x_height_3x charts_acc pages  page1">

    </div>
    <div class="parts eighty_centered x_height_3x charts_acc pages  page2">

    </div>
    <div class="parts eighty_centered x_height_3x charts_acc pages  page3">

    </div>
    <div class="parts eighty_centered x_height_3x charts_acc pages  page4">

    </div>
    <div class="parts eighty_centered x_height_3x charts_acc pages  page5">

    </div>
    <div class="parts eighty_centered x_height_3x charts_acc pages  page6">

    </div>
</div>
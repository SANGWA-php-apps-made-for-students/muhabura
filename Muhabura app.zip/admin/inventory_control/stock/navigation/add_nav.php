<?php

require_once './navigation/a_charts_acc/nav1.php';
//require_once './navigation/a_charts_acc/nav2.php';
//require_once './navigation/a_charts_acc/nav3.php';

require_once './navigation/aajournal/nav1.php';
require_once './navigation/b_trial_b/nav1.php';
require_once './navigation/e_income_s/nav1.php';
require_once './navigation/d_balance_s/nav1.php';
require_once './navigation/projects_trends/nav1.php';




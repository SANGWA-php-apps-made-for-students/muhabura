<?php

    session_start();

    if (isset($_POST['cbo_account_category'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_account_category_id_by_account_category_name($_POST['cbo_account_category']);
        return $id;
    }
    if (isset($_POST['cbo_profile'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_profile_id_by_profile_name($_POST['cbo_profile']);
        return $id;
    }
    if (isset($_POST['cbo_image'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_image_id_by_image_name($_POST['cbo_image']);
        return $id;
    }
    if (isset($_POST['cbo_item'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_item_id_by_item_name($_POST['cbo_item']);
        return $id;
    }
    if (isset($_POST['cbo_measurement'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_measurement_id_by_measurement_name($_POST['cbo_measurement']);
        return $id;
    }
    if (isset($_POST['cbo_source_stock'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_source_stock_id_by_source_stock_name($_POST['cbo_source_stock']);
        return $id;
    }
    if (isset($_POST['cbo_destination_stock'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_destination_stock_id_by_destination_stock_name($_POST['cbo_destination_stock']);
        return $id;
    }
    if (isset($_POST['cbo_item'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_item_id_by_item_name($_POST['cbo_item']);
        return $id;
    }
    if (isset($_POST['cbo_source_stock'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_source_stock_id_by_source_stock_name($_POST['cbo_source_stock']);
        return $id;
    }
    if (isset($_POST['cbo_destination_stock'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_destination_stock_id_by_destination_stock_name($_POST['cbo_destination_stock']);
        return $id;
    }
    if (isset($_POST['cbo_item'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_item_id_by_item_name($_POST['cbo_item']);
        return $id;
    }
    if (isset($_POST['cbo_measurement'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_measurement_id_by_measurement_name($_POST['cbo_measurement']);
        return $id;
    }
    if (isset($_POST['cbo_item'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_item_id_by_item_name($_POST['cbo_item']);
        return $id;
    }
    if (isset($_POST['cbo_item'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_item_id_by_item_name($_POST['cbo_item']);
        return $id;
    }
    if (isset($_POST['cbo_measurement'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_measurement_id_by_measurement_name($_POST['cbo_measurement']);
        return $id;
    }
    if (isset($_POST['cbo_source_stock'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_source_stock_id_by_source_stock_name($_POST['cbo_source_stock']);
        return $id;
    }
    if (isset($_POST['cbo_destination_stock'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_destination_stock_id_by_destination_stock_name($_POST['cbo_destination_stock']);
        return $id;
    }
    if (isset($_POST['cbo_item'])) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $id = $obj->get_item_id_by_item_name($_POST['cbo_item']);
        return $id;
    }

    if (isset($_POST['table_to_update'])) {
        $id_upd = $_POST['id_update'];
        $table_upd = $_POST['table_to_update'];
        $pref = 'upd_';
        $sufx = $table_upd;
        $_SESSION['table_to_update'] = $table_upd;
        $_SESSION['id_upd'] = $id_upd;
        echo $_SESSION['id_upd'];
    }


//The Delete from account
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'account') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_account($id);
    }
//The Delete from account_category
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'account_category') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_account_category($id);
    }
//The Delete from profile
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'profile') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_profile($id);
    }
//The Delete from image
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'image') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_image($id);
    }
//The Delete from main_stock
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'main_stock') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_main_stock($id);
    }
//The Delete from distriibution
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'distriibution') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_distriibution($id);
    }
//The Delete from returns
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'returns') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_returns($id);
    }
//The Delete from small_stock
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'small_stock') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_small_stock($id);
    }
//The Delete from stock_taking
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'stock_taking') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_stock_taking($id);
    }
//The Delete from ditribution_small_stock
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'ditribution_small_stock') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_ditribution_small_stock($id);
    }
//The Delete from p_budget_items
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'p_budget_items') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_p_budget_items($id);
    }
//The Delete from measurement
    if (isset($_POST['table_to_delete']) && $_POST['table_to_delete'] == 'measurement') {
        require_once '../web_db/deletions.php';
        $obj = new deletions();
        $id = $_POST['id_delete'];
        $obj->deleteFrom_measurement($id);
    }
    if (isset($_POST['pagination_n'])) {
        $_SESSION['pagination_n'] = $_POST['pagination_n'];
        $_SESSION['paginated_page'] = $_POST['paginated_page'];
        echo $_SESSION['paginated_page'];
    }
    if (isset($_POST['page_no_iteml'])) {
        unset($_SESSION['pagination_n']);
        $_SESSION['page_no_iteml'] = $_POST['page_no_iteml'];
        $_SESSION['paginated_page'] = $_POST['paginated_page'];
        echo $_SESSION['page_no_iteml'];
    }
    if (filter_has_var(INPUT_POST, 'get_items_by_stock')) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $get_items_by_stock = filter_input(INPUT_POST, 'get_items_by_stock');
        echo $obj->get_smalstock_items_by_stock($get_items_by_stock);
    }

    if (filter_has_var(INPUT_POST, 'main_stock_item')) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $main_stock_item = filter_input(INPUT_POST, 'main_stock_item');
        echo $obj->search_item_main_stock($main_stock_item);
    }
    if (isset($_POST['menu_index'])) {
        echo $_SESSION['menu_index'] = $_POST['menu_index'];
    }
    if (isset($_POST['get_menu_index'])) {
        echo $_SESSION['menu_index'];
    }
    if (filter_has_var(INPUT_POST, 'purchase_invoice')) {
        require_once '../web_db/multi_values.php';
        $obj = new multi_values();
        $pur_id = filter_input(INPUT_POST, 'purchase_invoice');
        echo $quantity_by_pur_invoice = $obj->get_quantity_by_pr_id($pur_id);
    }
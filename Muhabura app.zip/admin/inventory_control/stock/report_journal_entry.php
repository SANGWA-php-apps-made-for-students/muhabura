<?php
    session_start();
    require_once '../web_db/multi_values.php';
    require_once '../web_db/other_fx.php';
    if (!isset($_SESSION)) {
        session_start();
    }
    if (!isset($_SESSION['login_token'])) {
        header('location:../index.php');
    }
    if (isset($_POST['send_journal_entry_line'])) {
        if (isset($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'journal_entry_line') {
                require_once '../web_db/updates.php';
                $upd_obj = new updates();
                $journal_entry_line_id = $_SESSION['id_upd'];
                $accountid = trim($_POST['txt_accountid_id']);
                $dr_cr = $_POST['txt_dr_cr'];
                $amount = $_POST['txt_amount'];
                $memo = $_POST['txt_memo'];
                $journal_entry_header = $_POST['txt_journal_entry_header_id'];
                $upd_obj->update_journal_entry_line($accountid, $dr_cr, $amount, $memo, $journal_entry_header, $journal_entry_line_id);
                unset($_SESSION['table_to_update']);
            }
        } else {
            $accountid = trim($_POST['txt_accountid_id']);
            $dr_cr = $_POST['txt_dr_cr'];
            $amount = $_POST['txt_amount'];
            $memo = $_POST['txt_memo'];
            $journal_entry_header = trim($_POST['txt_journal_entry_header_id']);
            require_once '../web_db/new_values.php';
            $obj = new new_values();
            $obj->new_journal_entry_line($accountid, $dr_cr, $amount, $memo, 0);
        }
    }
?>

<html>
    <head>
        <meta charset="UTF-8">
        <title>
            journal_entry_line
        </title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <link href="admin_style.css" rel="stylesheet" type="text/css"/>
        <link href="../web_scripts/date_picker/jquery-ui.css" rel="stylesheet" type="text/css"/>
        <link href="../web_scripts/date_picker/jquery-ui.min.css" rel="stylesheet" type="text/css"/>
        <link href="../web_scripts/date_picker/jquery-ui.structure.css" rel="stylesheet" type="text/css"/>
        <link href="../web_scripts/date_picker/jquery-ui.structure.min.css" rel="stylesheet" type="text/css"/>
        <link href="../web_scripts/date_picker/jquery-ui.theme.css" rel="stylesheet" type="text/css"/>
        <link href="../web_scripts/date_picker/jquery-ui.theme.min.css" rel="stylesheet" type="text/css"/>
        <meta name="viewport" content="width=device-width, initial scale=1.0"/>

        <link rel="shortcut icon" href="../web_images/tab_icon.png" type="image/x-icon">

    </head>
    <body>
        <form action="new_journal_entry_line.php" method="post" enctype="multipart/form-data">
            <input type="hidden" id="txt_shall_expand_toUpdate" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim($_SESSION['table_to_update']) : '' ?>" />
            <!--this field  (shall_expand_toUpdate)above is for letting the form expand using js for updating-->
            <input type="hidden" id="txt_accountid_id"   name="txt_accountid_id"/>
            <input type="hidden" id="txt_journal_entry_header_id"   name="txt_journal_entry_header_id"/>
            <input type="hidden" id="txt_acc_type_id" style="float: right;"   name="txt_acc_type_id"/>
            <input type="hidden" id="txt_subacc_id" style="float: right;"   name="txt_subacc_id"/>
            <input type="hidden" id="txt_acc_class_id"   name="txt_acc_class_id"/>
            <!--when the opening balance is available the below fields are used-->
            <input type="hidden" id="txt_end_balance_id"   name="txt_end_balance_id"/>
            <input type="hidden" id="txt_end_date_id"   name="txt_end_date_id"/>
            <?php
                include 'admin_header.php';
            ?>

            <table class="new_data_table off">
                <tr><td>Account </td><td> <?php get_account_in_combo(); ?>  </td></tr>
                <tr><td><label for="txt_tuple">Debit or Credit </label></td><td> <input type="text"     name="txt_dr_cr"  id="txt_dr_cr" class="textbox" value="<?php echo trim(chosen_dr_cr_upd()); ?>"   />  </td></tr>
                <tr><td><label for="txt_tuple">Amount </label></td><td> <input type="text"     name="txt_amount"  id="txt_amount" class="textbox" value="<?php echo trim(chosen_amount_upd()); ?>"   />  </td></tr>
                <tr><td><label for="txt_tuple">Memo </label></td><td> <input type="text"     name="txt_memo"  id="txt_memo" class="textbox" value="<?php echo trim(chosen_memo_upd()); ?>"   />  </td></tr>
                <tr><td>Journal Entry Header </td><td> <?php get_journal_entry_header_combo(); ?>  </td></tr>
                <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="" value="Save"/>  </td></tr>
            </table>
        </div>
        <div class="parts eighty_centered datalist_box" >
            <div class="parts full_center_two_h heit_free no_shade_noBorder big_title ">
                <?php echo strtoupper(' Income Statement') ?>
            </div>
            <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border">
                <table class="full_center_two_h heit_free">
                    <td>Start date</td><td><input type="text" class="textbox dates"></td>
                    <td>End date</td><td><input  type="text" class="textbox dates"></td>
                </table>
            </div>
            <?php
                $tot_inc_exp = new other_fx();
                $sum_income = $tot_inc_exp->get_sum_income_or_expenses('income');
                $sum_expense = $tot_inc_exp->get_sum_income_or_expenses('expense');
                $net = $sum_income - $sum_expense;
                $obj = new multi_values();
                $other = new other_fx();
                $first = $obj->get_first_journal_entry_line();
            ?>

            <table class="dataList_table ">
                <tr class="big_title"><td>Income</td><td><?php echo number_format($sum_income); ?></td></tr>  <?php
            ?><tr><td colspan="2">
                        <a href="#" style="color: #000080; text-decoration: none;">
                            <span class="details link_cursor"><div class="parts no_paddin_shade_no_Border full_center_two_h heit_free no_bg"> Details</div>
                                <span class=" hidable full_center_two_h heit_free"> 
                                    <?php $other->list_journal_entry_line('income'); ?>
                                </span>
                            </span>
                        </a>
                    </td></tr>
                <tr class="big_title"><td>Expenses</td> <td><?php echo number_format($sum_expense); ?></td></tr>
                <tr><td colspan="2"> 
                        <a href="#" style="color: #000080; text-decoration: none;">
                            <span class="details link_cursor"><div class="parts no_paddin_shade_no_Border full_center_two_h heit_free no_bg"> Details</div>
                                <span class=" hidable full_center_two_h heit_free"> 
                                    <?php $other->list_journal_entry_line('Expense'); ?>
                                </span>
                            </span>
                        </a>
                    </td><?php ?></tr>
                <tr class="big_title">
                    <td>Net</td>
                    <td><?php echo (number_format($net) < 1) ? '<span class="red_text">' . number_format($net) . '</span>' : number_format($net); ?></td>
                </tr>
            </table>
        </div>  
    </form>
    <div class="parts  eighty_centered no_paddin_shade_no_Border no_bg margin_free export_btn_box">
        <table class="margin_free">
            <td>
                <form action="../web_exports/excel_export.php" method="post">
                    <input type="hidden" name="account" value="a"/>
                    <input type="submit" name="export" class="btn_export btn_export_excel" value="Export"/>
                </form>
            </td>
            <td>
                <form action="../prints/custom_p_income.php" target="blank" method="post">
                    <input type="submit" name="export" class="btn_export btn_export_pdf" value="Export"/>
                </form>
            </td>
        </table>
    </div>
    <div class="parts eighty_centered  no_paddin_shade_no_Border no_shade_noBorder check_loaded" >
        <?php require_once './navigation/add_nav.php'; ?> 
    </div>
    <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
    <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
    <script src="admin_script.js" type="text/javascript"></script>
    <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
    <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
    <script src="../web_scripts/date_picker/jquery-ui.js" type="text/javascript"></script>
    <script src="../web_scripts/date_picker/jquery-ui.min.js" type="text/javascript"></script>
    <script>
        $('#ending_date, .dates').datepicker({
            dataFormat: 'yy-mm-dd'
        });
    </script>
</body>
</hmtl>
<?php

    function get_acc_combo() {
        $obj = new multi_values();
        $obj->get_account_in_combo();
    }

    function chosen_name_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'account') {
                $id = $_SESSION['id_upd'];
                $name = new multi_values();
                return $name->get_chosen_account_name($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function get_parties_in_combo() {
        $obj = new other_fx();
        $obj->get_vendors_suppliers_in_combo_array();
    }

    function get_account_in_combo() {
        $obj = new other_fx();
        $obj->get_account_in_combo_array();
    }

    function get_journal_entry_header_combo() {
        $obj = new multi_values();
        $obj->get_journal_entry_header_in_combo();
    }

    function chosen_accountid_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'journal_entry_line') {
                $id = $_SESSION['id_upd'];
                $accountid = new multi_values();
                return $accountid->get_chosen_journal_entry_line_accountid($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_dr_cr_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'journal_entry_line') {
                $id = $_SESSION['id_upd'];
                $dr_cr = new multi_values();
                return $dr_cr->get_chosen_journal_entry_line_dr_cr($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_amount_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'journal_entry_line') {
                $id = $_SESSION['id_upd'];
                $amount = new multi_values();
                return $amount->get_chosen_journal_entry_line_amount($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_memo_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'journal_entry_line') {
                $id = $_SESSION['id_upd'];
                $memo = new multi_values();
                return $memo->get_chosen_journal_entry_line_memo($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function chosen_journal_entry_header_upd() {
        if (!empty($_SESSION['table_to_update'])) {
            if ($_SESSION['table_to_update'] == 'journal_entry_line') {
                $id = $_SESSION['id_upd'];
                $journal_entry_header = new multi_values();
                return $journal_entry_header->get_chosen_journal_entry_line_journal_entry_header($id);
            } else {
                return '';
            }
        } else {
            return '';
        }
    }

    function send_journal() {
        if (isset($_POST['send_journal'])) {
            require_once '../web_db/new_values.php';
            $debit = $_POST['txt_debit'];
            $credit = $_POST['txt_credit'];
            $memos = $_POST['txt_memo'];
            $all_debit = 0;
            $all_credit = 0;
            $amnt_debt = 0;
            $amnt_crdt = 0;
            //get sums
            $sum_debt = 0;
            $sum_crdt = 0;
            $account = $_POST['acc_name_combo'];

            foreach ($debit as $dbt) {
                $sum_debt += $dbt;
            }
            foreach ($credit as $crdt) {
                $sum_crdt += $crdt;
            }
            if ($sum_debt != $sum_crdt) {
                ?><script>alert('The credit side is not equal debit side');</script><?php
            } else {
                foreach ($account as $acc) {
                    if (!empty($acc)) {
                        foreach ($debit as $dbt) {
                            if (!empty($dbt)) {
                                $all_debit += 1;
                                $amnt_debt += $dbt;
                                $newobj = new new_values();
                            }
                            break;
                        }
                        foreach ($credit as $crdt) {
                            if (!empty($crdt)) {
                                $amnt_crdt += $crdt;
                                $all_credit += 1;
                                $newobj = new new_values();
                            } break;
                        }
                        foreach ($memos as $memo) {
                            if (!empty($memo)) {
                                
                            }
                            break;
                        }
                        $newobj->new_journal_entry_line($acc, 0, $amnt_crdt, $memo, 0);
                        echo 'Account: ' . $acc . '  Debit side: ' . $sum_crdt . ' Credit side: ' . $sum_debt . '   <br/>';
                    }
                }
            }
        }
    }
    
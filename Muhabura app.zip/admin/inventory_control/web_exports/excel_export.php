<?php

    require_once '../web_db/dbConnection.php ';


    if (filter_has_var(INPUT_POST, 'p_request')) {
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from p_request";
        $stmt = $db->prepare($sql);
        $stmt->execute();
        $output = '';
        $output .= '                    
            <table class="export_excel_table">
                <thead><tr>
               <td>Item</td>
               <td>Quantity</td>
               <td>Unit Cost</td>
               <td>Amount</td>
               <td>Entry Date</td>
               <td>User</td>
               <td>Measurement</td>
               <td>Request Number</td>
                        </tr></thead>
               ';

        while ($row = $stmt->fetch()) {
            $output .= '<tr> 

                 <td>' . $row['item'] . '</td>
                 <td>' . $row['quantity'] . '</td>
                 <td>' . $row['unit_cost'] . '</td>
                 <td>' . $row['amount'] . '</td>
                 <td>' . $row['entry_date'] . '</td>
                 <td>' . $row['User'] . '</td>
                 <td>' . $row['measurement'] . '</td>
                 <td>' . $row['request_no'] . '</td>

                        </tr>';
        }

        $output .= '</table>';
        header("Content-Type: vnd.ms-excel");
        header("Content-Disposition:attachment; filename=p_request.xls");
        header("Pragma: no-cache");
        header("Expires: 0");
        echo $output;
    }
 
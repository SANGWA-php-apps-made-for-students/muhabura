<?php

require_once 'Fpdf/fpdf.php';
require_once '../web_db/connection.php';
class PDF extends FPDF {

// Load data
    function LoadData() {
        // Read file lines

        $database=new dbconnection();
        $db = $database->openconnection();        $sql = "select * from returns  ";
   // <editor-fold defaultstate="collapsed" desc="----text Above (header = company addresses) ------">
        $this->Cell(120, 7,'MUHABURA STOCK', 0, 0, 'L');
        $this->Cell(60, 7, 'DISTRICT: GASABO', 0, 0, 'L');
        $this->Ln();
        $this->Cell(120, 7, 'RWANDA ', 0, 0, 'E');
        $this->Cell(60, 7, 'TELEPHONE: . ', 0, 0, 'L');

        $this->Ln();
        $this->Ln();
        $this->Ln();
        $this->Ln();
        $this->SetFont("Arial", 'B', 14);
        $this->Cell(170, 7, 'returns REPORT ', 0, 0, 'C');

        $this->Ln();
        $this->Ln();
        $this->SetFont("Arial", '', 14);
// </editor-fold>

$this->Cell(30, 7, 'returns_id', 1, 0, 'L');$this->Cell(30, 7, 'source_stock', 1, 0, 'L');$this->Cell(30, 7, 'destination_stock', 1, 0, 'L');$this->Cell(30, 7, 'item', 1, 0, 'L');$this->Cell(30, 7, 'returned_qty', 1, 0, 'L');$this->Cell(30, 7, 'entry_date', 1, 0, 'L');$this->Cell(30, 7, 'User', 1, 0, 'L');
 $this->Ln();
        foreach ($db->query($sql) as $row) {
$this->cell(30, 7, $row['returns_id'], 1, 0, 'L');
$this->cell(30, 7, $row['source_stock'], 1, 0, 'L');
$this->cell(30, 7, $row['destination_stock'], 1, 0, 'L');
$this->cell(30, 7, $row['item'], 1, 0, 'L');
$this->cell(30, 7, $row['returned_qty'], 1, 0, 'L');
$this->cell(30, 7, $row['entry_date'], 1, 0, 'L');
$this->cell(30, 7, $row['User'], 1, 0, 'L');


 $this->Ln();
        }
    }
}

$pdf = new PDF();
$pdf->SetFont('Arial', '', 13);
$pdf->AddPage();
$pdf->LoadData();
$pdf->Output(); 

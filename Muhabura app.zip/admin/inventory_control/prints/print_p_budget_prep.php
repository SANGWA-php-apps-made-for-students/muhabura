<?php

    require_once 'Fpdf/fpdf.php';
    require_once '../web_db/connection.php';

    class PDF extends FPDF {

// Load data
        function LoadData() {
            // Read file lines

            $database = new dbconnection();
            $db = $database->openconnection();
            $sql = "select * from p_budget_prep  ";
            // <editor-fold defaultstate="collapsed" desc="----text Above (header = company addresses) ------">
            $this->Image('../web_images/report_header.png');

            $this->Ln();
            $this->Ln();
            $this->Ln();

            $this->Ln();
            $this->Ln();
            $this->Ln();
            $this->Ln();
            $this->SetFont("Arial", 'B', 14);
            $this->Cell(270, 7, 'BUDGET PREPARATION REPORT ', 0, 0, 'C');

            $this->Ln();
            $this->Ln();
            $this->SetFont("Arial", '', 11);
// </editor-fold>

            $this->Cell(15, 7, 'S/N', 1, 0, 'L');
            $this->Cell(60, 7, strtoupper('project type'), 1, 0, 'L');
//            $this->Cell(30, 7, strtoupper('user'), 1, 0, 'L');
            $this->Cell(44, 7, strtoupper('entry date'), 1, 0, 'L');
            $this->Cell(30, 7, strtoupper('budget type'), 1, 0, 'L');
//            $this->Cell(30, 7, 'activity_desc', 1, 0, 'L');
//            $this->Cell(30, 7, strtoupper('amount'), 1, 0, 'L');
            $this->Cell(70, 7, strtoupper(wordwrap('name')), 1, 0, 'L');
            $this->Ln();
            foreach ($db->query($sql) as $row) {
                $this->cell(15, 7, $row['p_budget_prep_id'], 1, 0, 'L');
                $this->cell(60, 7, $row['project_type'], 1, 0, 'L');
//                $this->cell(30, 7, $row['user'], 1, 0, 'L');
                $this->cell(44, 7, $row['entry_date'], 1, 0, 'L');
                $this->cell(30, 7, $row['budget_type'], 1, 0, 'L');
//                $this->cell(30, 7, $row['activity_desc'], 1, 0, 'L');
//                $this->cell(30, 7, number_format($row['amount']), 1, 0, 'L');
                $this->cell(70, 7, $row['name'], 1, 0, 'L');


                $this->Ln();
            }
        }

    }

    $pdf = new PDF();
    $pdf->SetFont('Arial', '', 11);
    $pdf->AddPage('L');
    $pdf->LoadData();
    $pdf->Output();
    
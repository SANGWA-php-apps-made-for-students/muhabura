<?php ?>
<script>

    $('#ending_date, .dates').datepicker({dateFormat: 'yy-mm-dd'});
    $('#save_journal').click(function () {
        var update_now = $('#txt_shall_expand_toUpdate').val();
        if (update_now != '') {

            $('.load_in_center').fadeIn(100);
            $('.upd_refill').each(function (i, value) {// Thiso is the combobox that holds the accountid. It was renamed to upd_refill
                if ($(this).val() != '') {
                    var cont = 'c';
                    var get_journal_by_transaction = the_transactionId;
                    var cont = 'c';
                    $.post('handler_update_details.php', {get_journal_by_transaction: get_journal_by_transaction}, function (data) {
                        console.log('The journal_is: ' + data);
                        //Get the jornal id 
                        var final = $.parseJSON(data.trim());
                        var c = 0;
                        $.each(final, function (i, option) {
                            var acc = $('.upd_refill:eq(' + i + ')').val();
                            var debit = $('.j_debit_txt:eq(' + i + ')').val();
                            var credit = $('.j_credit_txt:eq(' + i + ')').val();
                            var memo = $('.txt_memo:eq(' + i + ')').val();
                            var tax = $('.cbo_tax_arr:eq(' + i + ')').val();
                            var proj = $('.link_to_project:eq(' + i + ')').val();
                            var party = $('.cbo_party_upd:eq(' + i + ')').val();
                            var update_whole_journal = option.journal_entry_line_id;
                            console.log(i + ' - Before\n: ' + acc + 'debit: ' + debit + 'creadit; ' + credit + 'memo: ' + memo + 'tax:  ' + tax + 'Finally the account: ' + acc);
                            $.post('handler_update_details.php', {acc: acc, debit: debit.replace(',', '').replace('', ''), credit: credit.replace(',', '').replace('', ''), memo: memo, tax: tax, proj: proj, party: party, update_whole_journal: update_whole_journal}, function (data) {
                                console.log('After updating: ' + data);
                            });
                        });
                        console.log('_______________');
                    }).complete(function () {
                        //Reload the table
                        var reload_journal_entry = 'c';
                        var res = '';
                        $.post('handler_update_details.php', {reload_journal_entry: reload_journal_entry}, function (data) {
                            res = data;
                            console.log(res);
                        }).complete(function () {
                            $('.data_reload').html(res);
                        });
                    });
                }
                $('.load_in_center').fadeOut(100);
                //                                    clear_fields();
                $('.new_data_box').slideUp(100);
                unset_update_session();

            });
            unset_update_session();
            window.location.reload();
            return false;
        } else {
            return true;
        }
    });
    function clear_fields() {
        $('.cbo_account_arr').val('');
        $('.j_debit_txt').val('');
        $('.j_credit_txt').val('');
        $('.txt_memo').val('');
        $('.cbo_tax_arr').val('');
        $('.link_to_project').val('');
        $('.cbo_account_arr').val('');
        $('#txt_shall_expand_toUpdate').val('');
        //See fi there are no duplicates
    }

</script>
<?php

if (!isset($_SESSION)) {
    session_start();
}
/**
 * Description of handler_update_details2
 *
 * @author SANGWA
 */
if (filter_has_var(INPUT_POST, 'payment_vchr_details')) {
    require_once '../web_db/Other_fx2.php';
    $obj = new Other_fx2();
    $obj->get_payment_voucher_details();
}

if (filter_has_var(INPUT_POST, 'cbo_invoice_for_details')) {
    require_once '../web_db/Other_fx2.php';
    $obj = new Other_fx2();
    $cbo_invoice_for_details = filter_input(INPUT_POST, 'cbo_invoice_for_details');
    echo $obj->get_purchase_invoice_details($cbo_invoice_for_details);
}
if (filter_has_var(INPUT_POST, 'cbo_p_order_for_details')) {
    require_once '../web_db/Other_fx2.php';
    $obj = new Other_fx2();
    $cbo_p_order_for_details = filter_input(INPUT_POST, 'cbo_p_order_for_details');
    echo $obj->get_purchase_order_details_voucher($cbo_p_order_for_details);
}
if (filter_has_var(INPUT_POST, 'get_payment_vchr_details')) {
    require_once '../web_db/Other_fx2.php';
    $obj = new Other_fx2();
    $get_payment_vchr_details = filter_input(INPUT_POST, 'get_payment_vchr_details');
    echo $obj->get_payment_vchr_details($get_payment_vchr_details);
}

if (filter_has_var(INPUT_POST, 'all_activities_cbo')) {
    require_once '../web_db/Other_fx2.php';
    $ot = new Other_fx2();
    $all_activities_cbo = filter_input(INPUT_POST, 'all_activities_cbo');
    echo $ot->list_all_activities_cbo();
}
if (filter_has_var(INPUT_POST, 'all_project_cbo')) {
    $all_project_cbo = filter_input(INPUT_POST, 'all_project_cbo');
    require_once '../web_db/Other_fx2.php';
    $ot = new Other_fx2();
    echo $ot->list_all_project_cbo();
}
 
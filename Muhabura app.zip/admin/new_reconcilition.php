<?php
session_start();
require_once '../web_db/multi_values.php';
require_once '../web_db/updates.php';
require_once '../web_db/other_fx.php';
$obj = new other_fx();
if (!isset($_SESSION)) {
    session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
if (isset($_POST['send_reconcilition'])) {
    if (isset($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'reconcilition') {
            require_once '../web_db/updates.php';
            $upd_obj = new updates();
            $reconcilition_id = $_SESSION['id_upd'];
            $entry_date = date("y-m-d");
            $User = $_SESSION['userid'];
            $transaction = $_POST['txt_transaction_id'];
            $amount_due = $_POST['txt_amount_due'];
            $amount_done = $_POST['txt_amount_done'];
            $remaining_amount = $_POST['txt_remaining_amount'];
            $comments = $_POST['txt_comments'];
            $upd_obj->update_reconcilition($entry_date, $User, $transaction, $amount_due, $amount_done, $remaining_amount, $comments, $reconcilition_id);
            unset($_SESSION['table_to_update']);
        }
    } else {
        $entry_date = date("y-m-d");
        $User = $_SESSION['userid'];
        require_once '../web_db/new_values.php';
        $obj = new new_values();
        $upd = new updates();

        $payments = $_POST['reconcil_payments'];
        $amount = $_POST['amount'];
        $index_payment = new ArrayIterator($payments);
        $index_amount = new ArrayIterator($amount);
        $mit = new MultipleIterator(MultipleIterator::MIT_KEYS_ASSOC);
        $mit->attachIterator($index_payment, "reconcil_payments");
        $mit->attachIterator($index_amount, "amount");
        foreach ($mit as $fruit) {
            $dc = json_decode(json_encode($fruit), true);
            foreach ($dc as $val) {
                if (!empty($dc['reconcil_payments'])) {
                    $journal_line=$dc['reconcil_payments'];
                    $obj->new_reconcilition($entry_date, $User, $journal_line, $dc['amount'], $dc['amount'], 0,'', $journal_line);
                    $upd->update_journal_status('reconciled', $journal_line);
                    break;
                }
            }
        }
        //            foreach ($payments as $journal_line) {//Here the journal line is an individual "journal_entry_line_id"
        //                $obj->new_reconcilition($entry_date, $User, $transaction, $amount_due, $amount_done, 0, $journal_line);
        //                $upd->update_journal_status('reconcilied', $journal_line);
        //            }
    }
}
?>

<html>
    <head>
        <meta charset="UTF-8">
        <title>
            reconcilition</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <link href="admin_style.css" rel="stylesheet" type="text/css"/>
        <meta name="viewport" content="width=device-width, initial scale=1.0"/>
        <link href="../web_scripts/date_picker/jquery-ui.css" rel="stylesheet" type="text/css"/>
        <link href="../web_scripts/date_picker/jquery-ui.min.css" rel="stylesheet" type="text/css"/>
        <link href="../web_scripts/date_picker/jquery-ui.structure.css" rel="stylesheet" type="text/css"/>
        <link href="../web_scripts/date_picker/jquery-ui.structure.min.css" rel="stylesheet" type="text/css"/>
        <link href="../web_scripts/date_picker/jquery-ui.theme.css" rel="stylesheet" type="text/css"/>
        <link href="../web_scripts/date_picker/jquery-ui.theme.min.css" rel="stylesheet" type="text/css"/>
        <link rel="shortcut icon" href="../web_images/tab_icon.png" type="image/x-icon">

        <style>
            .fifty_left p{
                padding: 0px;
                margin: 0px;
            }
        </style>
    </head>
    <body>
        <form action="new_reconcilition.php" method="post" enctype="multipart/form-data">
            <input type="hidden" id="txt_shall_expand_toUpdate" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim($_SESSION['table_to_update']) : '' ?>" />
            <!--this field  (shall_expand_toUpdate)above is for letting the form expand using js for updating-->

            <input type="hidden" id="txt_transaction_id"   name="txt_transaction_id"/>
            <?php
            include 'admin_header.php';
            $ot = new other_fx();
            $ot->get_searchNew_menu('reconciliation', without_admin());
            ?>

            <!--Start dialog's-->
            <div class="parts abs_full y_n_dialog off">
                <div class="parts dialog_yes_no no_paddin_shade_no_Border reverse_border">
                    <div class="parts full_center_two_h heit_free margin_free skin">
                        Do you really want to delete this record?
                    </div>
                    <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border top_off_x margin_free">
                        <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_xx link_cursor yes_dlg_btn" id="citizen_yes_btn">Yes</div>
                        <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_seventy link_cursor no_btn" id="no_btn">No</div>
                    </div>
                </div>
            </div>   
            <!--End dialog-->

            <div class="parts eighty_centered off saved_dialog">
                reconcilition saved successfully!
            </div>
            <div class="parts eighty_centered new_data_box off">
                <div class="parts eighty_centered new_data_title">  reconcilition Registration </div>
                <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border ">
                    <div class="parts fifty_left no_paddin_shade_no_Border ">
                        <p>Cheques and Payments</p>
                        <?php
                        $obj->list_journal_entry_for_rec(1, 30, 'not reconciled', 'Debit');
//                            $obj->single_while(1, 30);
                        ?> 
                    </div>
                    <div class="parts fifty_left no_paddin_shade_no_Border margin_free" >
                        <p>Deposits </p>
                        <?php
                        $obj->list_journal_entry_for_rec(1, 30, 'not reconciled', 'Credit');
                        ?>
                    </div>

                </div>
                <div class="parts  full_center_two_h  no_shade_noBorder heit_free">
                    <div class="parts full_center_two_h  no_shade_noBorder  heit_free">
                        <input type="submit" class="confirm_buttons" name="send_reconcilition" value="Confirm" /> 
                    </div>
                </div>
                <table class="new_data_table off">
                    <tr><td class="new_data_tb_frst_cols">Transaction </td><td> <?php get_transaction_combo(); ?>  </td></tr><tr><td><label for="txt_amount_due">Amount due </label></td><td> <input type="text"     name="txt_amount_due" id="txt_amount_due" class="textbox" value="<?php echo trim(chosen_amount_due_upd()); ?>"   />  </td></tr>
                    <tr><td><label for="txt_amount_done">Amount done </label></td><td> <input type="text"     name="txt_amount_done" id="txt_amount_done" class="textbox" value="<?php echo trim(chosen_amount_done_upd()); ?>"   />  </td></tr>
                    <tr><td><label for="txt_remaining_amount">Remaining amount </label></td><td> <input type="text"     name="txt_remaining_amount" id="txt_remaining_amount" class="textbox" value="<?php echo trim(chosen_remaining_amount_upd()); ?>"   />  </td></tr>
                    <tr><td><label for="txt_comments">comments </label></td><td> <input type="text"     name="txt_comments" id="txt_comments" class="textbox" value="<?php echo trim(chosen_comments_upd()); ?>"   />  </td></tr>
                    <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_reconcilition" value="Save"/>  </td></tr>
                </table>
            </div>
            <div class="parts eighty_centered datalist_box" >
                <div class="parts no_shade_noBorder xx_titles no_bg whilte_text dataList_title">reconcilition List</div>
                <?php
                $obj = new other_fx();
                $first = $obj->get_first_reconcilition();
                $obj->list_reconcilition($first);
                ?>
                <div class="parts no_paddin_shade_no_Border two_fifty_left">
                
            </div>
            </div>
            
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="admin_script.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
        <script src="../web_scripts/date_picker/jquery-ui.js" type="text/javascript"></script>
        <script src="../web_scripts/date_picker/jquery-ui.min.js" type="text/javascript"></script>
        <script src="../web_scripts/searches.js" type="text/javascript"></script>
        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
    </body>
</hmtl>
<?php

function get_transaction_combo() {
    $obj = new other_fx();
    $obj->get_transaction_in_combo();
}

function chosen_entry_date_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'reconcilition') {
            $id = $_SESSION['id_upd'];
            $entry_date = new multi_values();
            return $entry_date->get_chosen_reconcilition_entry_date($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_User_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'reconcilition') {
            $id = $_SESSION['id_upd'];
            $User = new multi_values();
            return $User->get_chosen_reconcilition_User($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_transaction_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'reconcilition') {
            $id = $_SESSION['id_upd'];
            $transaction = new multi_values();
            return $transaction->get_chosen_reconcilition_transaction($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_amount_due_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'reconcilition') {
            $id = $_SESSION['id_upd'];
            $amount_due = new multi_values();
            return $amount_due->get_chosen_reconcilition_amount_due($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_amount_done_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'reconcilition') {
            $id = $_SESSION['id_upd'];
            $amount_done = new multi_values();
            return $amount_done->get_chosen_reconcilition_amount_done($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_remaining_amount_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'reconcilition') {
            $id = $_SESSION['id_upd'];
            $remaining_amount = new multi_values();
            return $remaining_amount->get_chosen_reconcilition_remaining_amount($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_comments_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'reconcilition') {
            $id = $_SESSION['id_upd'];
            $comments = new multi_values();
            return $comments->get_chosen_reconcilition_comments($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

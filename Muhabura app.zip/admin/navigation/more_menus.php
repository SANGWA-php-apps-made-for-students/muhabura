  <a id="sett_location" href="new_p_province.php"> Locations </a>
            <a id="sett_department" href="new_staff_positions.php"> Staff Departments</a>
            <a id="sett_measurement" href="new_measurement.php">measurement</a>
            <a style="display:none" id="sett_ledger" href="new_ledger_settings.php">ledger settings</a>
            <a style="display:none" id="sett_request" href="new_p_request_type.php">Request types</a>
            <a id="sett_currency" href="new_p_Currency.php">Currency</a>
            <a id="sett_currency" href="new_bank.php">Bank</a>
            <a id="sett_currency" href="new_tax_type.php">tax Percentages</a>
            <a id="sett_currency" href="new_tax_calculations.php">tax Firmulae</a>
            <input type="hidden" id="txt_shall_expand_toUpdate" value=""/>
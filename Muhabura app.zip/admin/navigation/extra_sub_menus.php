

<?php

    /**
     * Description of extra_sub_menus
     *
     * SANGWA at CODEGURU
     */
    class extra_sub_menus {

        function get_budget_line_newdata_smenu() {
            return $mnu = ""
                    . "";
            ?>
            <div class="parts sub_menus">
                <a href="#">Search</a>
                <a href="#"></a>
            </div>
            <?php
        }

        function get_budget_line_datalist_smenu() {
            ?>
            <div class="parts full_center_two_h heit_free margin_free no_paddin_shade_no_Border">
                <div class="parts no_paddin_shade_no_Border smenu_item margin_free" id="smenu1">
                    Preparation
                </div>
                <div class="parts no_paddin_shade_no_Border smenu_item margin_free" id="smenu2">
                    Implementation
                </div>
            </div> 
            <?php
        }

        function get_purchase_order_line_smenu() {
            ?>
            <div class="parts full_center_two_h heit_free margin_free no_paddin_shade_no_Border">
                <div class="parts no_paddin_shade_no_Border smenu_item margin_free" id="smenu1">
                    Approved Purchase orders
                </div>
                <div class="parts no_paddin_shade_no_Border smenu_item margin_free" id="smenu2">
                    Purchase Order by location
                </div>
                <div class="parts no_paddin_shade_no_Border smenu_item margin_free accept_abs" id="smenu3">
                    Pending Purchase Order
                    <?php
                    $ot3 = new other_fx();
                    //Cout notify
                    $po_count = $ot3->get_pending_purchase_order_request();
                    $ot3->get_count_notify($po_count);
                    ?>
                </div>
            </div> 
            <?php
        }

        function get_request_smenu() {
            ?> 
            <div class="parts full_center_two_h heit_free margin_free no_paddin_shade_no_Border">
                <div class="parts no_paddin_shade_no_Border smenu_item margin_free" id="smenu1">
                    All requests
                </div>
                <div class="parts no_paddin_shade_no_Border smenu_item margin_free" id="smenu2">
                    Request by location
                </div>

            </div> 

            <?php
        }

    }
    
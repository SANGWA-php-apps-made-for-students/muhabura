<div class="parts  no_shade_noBorder rep_data_box no_paddin_shade_no_Border off"> 
    <div class="parts full_center_two_h heit_free margin_free no_shade_noBorder rep_title">Title</div>
    <div class="parts fifty_centered no_paddin_shade_no_Border load_gif"> </div>
    <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border margin_free fin_data_res">

    </div>
</div>

<?php
$names = filter_input(INPUT_POST, 'txt_name');

$db = new PDO('mysql:host=localhost;dbname=accounting_db;charset=utf8mb4', 'sangwa', 'A.manigu125');
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stm = $db->prepare("insert into user values(:user_id, :names)");
$stm->execute(array(':user_id' => 0, ':names' => $names));


// View data

$sql = "  select * from customer";
$stmt = $db->prepare($sql);
$stmt->execute();
?>
<table class="dataList_table">
    <thead><tr>
            <td> ID </td>
            <td> Name </td> 
            
            
                <td class=" delete_cols">Delete</td>
                <td class=" update_cols">Update</td>
          
        </tr>
    </thead>
    <?php
    $pages = 1;
    while ($row = $stmt->fetch()) {
        ?><tr>
            <td style="padding-left: 10px">
                <?php echo $row['customer_id']; ?>
            </td>
            <td class="acc_type_id_cols account " >
                <?php echo $this->_e($row['name']); ?>
            </td> 
            <td class="delete_cols">
                <a href="#">Delete</a>
            </td>
            <td class="update_cols">
                <a href="#">Update</a>
            </td>
        </tr>
        <?php
    }
    ?></table>




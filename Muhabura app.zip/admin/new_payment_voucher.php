<?php
session_start();
require_once '../web_db/multi_values.php';
require_once '../web_db/other_fx.php';
require_once '../web_db/Other_fx2.php';
if (!isset($_SESSION)) {
    session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
if (isset($_POST['send_payment_voucher'])) {
    require_once '../web_db/new_values.php';
    $m = new multi_values();
    $ot = new other_fx();

    $obj = new new_values();
//      $item = trim($_POST['txt_item_id']);
    $entry_date = date("y-m-d h:m:s");
    $User = $_SESSION['userid'];
    $ot2 = new Other_fx2();
    $budget_prep = trim($_POST['txt_activity_id']);
    $accountid = filter_input(INPUT_POST, 'acc_name_combo');
    $supplier = filter_input(INPUT_POST, 'supplier_cbo');
    $staff = filter_input(INPUT_POST, 'cbo_staff');
    $payee = (empty($staff)) ? $supplier : $staff;
    $payment_method = filter_input(INPUT_POST, 'rd_bank_cash');
    $bank = (filter_input(INPUT_POST, 'rd_bank_cash') == 'bank') ? filter_input(INPUT_POST, 'txt_bank') : '';
    $chart_acc = ($bank != 0) ? ($ot->get_chartacc_by_bank($bank)) : $ot2->get_first_cash_account();
    
 
    
    $details = filter_input(INPUT_POST, 'txt_description');
    $rd_supplier_staff = filter_input(INPUT_POST, 'rd_supplier_staff');
    $payee_type = ($rd_supplier_staff == 'supplier') ? 'supplier client' : 'staff';
    $cheque_no = (filter_has_var(INPUT_POST, 'txt_chek_no')) ? filter_input(INPUT_POST, 'txt_chek_no') : "";
    $ref = "";
    $reference = filter_input(INPUT_POST, 'rd_payment_reference');
    $qty = 0;
    $uc = 0;
    $tot = 0;
    
    if (!empty($accountid)) {
         
        if (!empty($budget_prep)) {
            if (!empty($payee)) {
                if (isset($_SESSION['table_to_update'])) {
                    if ($_SESSION['table_to_update'] == 'payment_voucher') {
                        require_once '../web_db/updates.php';
                        $upd_obj = new updates();
                        $payment_voucher_id = $_SESSION['id_upd'];

                        if (filter_has_var(INPUT_POST, 'rd_payment_reference')) {//there us a reference
                            if (filter_input(INPUT_POST, 'rd_payment_reference') == 'purchase order') {//po
                                $ref = filter_input(INPUT_POST, 'txt_main_req'); //get Purchase order
                                $reference = "purchase order";
                                //Get arrays and make the total
                                $uc = filter_input(INPUT_POST, 'txt_tot_uc');
                                $qty = filter_input(INPUT_POST, 'txt_tot_qty');
                                $tot = filter_input(INPUT_POST, 'txt_tot_amount');
                            } else if (filter_input(INPUT_POST, 'rd_payment_reference') == 'invoice') {
                                $ref = filter_input(INPUT_POST, 'txt_main_req'); //Get Purchase invoice
                                $reference = "invoice";
                                //Get arrays and make the total
                                $uc = filter_input(INPUT_POST, 'txt_tot_uc');
                                $qty = filter_input(INPUT_POST, 'txt_tot_qty');
                                $tot = filter_input(INPUT_POST, 'txt_tot_amount');
                            } else {
                                $ref = 0;
                                $reference = "payment voucher";
                                $quantity = filter_input(INPUT_POST, 'txt_init_quantity');
                                $unit_cost = filter_input(INPUT_POST, 'txt_init_unit_cost', FILTER_SANITIZE_NUMBER_INT);
                                $total = $unit_cost * $quantity;
                                $tot = $total;
                            }
                        }
                        $reference = (filter_has_var(INPUT_POST, 'rd_payment_reference')) ? $reference : "no";
                        $upd_obj->update_payment_voucher(0, $entry_date, $User, $quantity, $unit_cost, $amount, $budget_prep, $payee, $payment_method, $bank, $cheque_number, $details, $payee_type, $reference, $ref_number, $payment_voucher_id);
                        $journal_line = $ot2->get_chosen_journal_entry_line_transaction(chosen_ref_number_upd());
                        $journal_header = $ot2->get_journalheader_by_journalline($journal_line);    //no need

                        $upd_obj->update_journal_entry_line_pyt_voucher($accountid, $qty * $uc, "payment voucher", "payment voucher", $activity, $journal_line, 'debit');
                        $upd_obj->update_journal_entry_line_pyt_voucher($accountid, $qty * $uc, "payment voucher", "payment voucher", $activity, $journal_line, 'credit');
                        unset($_SESSION['table_to_update']);
                    }
                } else {//when we are adding a new one
                    if (filter_has_var(INPUT_POST, 'rd_payment_reference')) {//there is a reference
                        if (filter_input(INPUT_POST, 'rd_payment_reference') == 'purchase order') {//po
                            $ref = filter_input(INPUT_POST, 'txt_main_req'); //get Purchase order
                            $reference = "purchase order";
                            //Get arrays and make the total
                            $uc = filter_input(INPUT_POST, 'txt_tot_uc');
                            $qty = filter_input(INPUT_POST, 'txt_tot_qty');
                            $tot = filter_input(INPUT_POST, 'txt_tot_amount');
                        } else if (filter_input(INPUT_POST, 'rd_payment_reference') == 'invoice') {
                            $ref = filter_input(INPUT_POST, 'txt_main_req'); //Get Purchase invoice
                            $reference = "invoice";
                            //Get arrays and make the total
                            $uc = filter_input(INPUT_POST, 'txt_tot_uc');
                            $qty = filter_input(INPUT_POST, 'txt_tot_qty');
                            $tot = filter_input(INPUT_POST, 'txt_tot_amount');
                        } else {
                            $ref = 0;
                            $reference = "payment voucher";
                            $qty = filter_input(INPUT_POST, 'txt_init_quantity');
                            $uc = filter_input(INPUT_POST, 'txt_init_unit_cost', FILTER_SANITIZE_NUMBER_INT);
                            $total = $unit_cost * $quantity;
                            $tot = $total;
                        }
                    }

                    $ref_number = filter_has_var(INPUT_POST, 'txt_main_req') ? filter_input(INPUT_POST, 'txt_main_req') : 0;
                    $obj->new_journal_entry_header(0, 'payable', $entry_date, 'Payment voucher', 0, 'yes');
                    $last_head = $m->get_last_journal_entry_header();
                    $obj->new_journal_transactions(date('h:m:d'));
                    $last_transaction = $m->get_last_journal_transactions(); //This is the main transaction that may have many accounts (journal transactions)
                    $payment_method = ($payment_method == 'bank') ? 'not reconciled' : 'neutral'; //this help in reconciliation
                    $obj->new_journal_entry_line($accountid, "debit", $qty * $uc, "payment voucher", $last_head, $entry_date, "payment voucher", 'neutral', 0, $User, $last_transaction);
                    $obj->new_journal_entry_line($chart_acc, "credit", $qty * $uc, "payment voucher", $last_head, $entry_date, "payment voucher", $payment_method, 0, $User, $last_transaction);
                    $obj->new_payment_voucher(0, $entry_date, $User, $qty, $uc, $tot, $budget_prep, $payee, $payment_method, $bank, $cheque_no, $details, $payee_type, $reference, $ref_number, $last_transaction);
                }
            } else {
                ?>  <script> alert('You have to choose an the payee');</script> <?php
            }
        } else {
            ?>  <script> alert('You have to choose an  activity');</script> <?php
        }
    } else {
        ?>  <script> alert('You have to choose an account');</script> <?php
    }


//Vat
    if (filter_has_var(INPUT_POST, $ref)) {//if vat i inclusive
    }
}
?>

<html>
    <head>
        <meta charset="UTF-8">
        <title>
            payment_voucher
        </title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <link href="admin_style.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/financial_rep.css" rel="stylesheet" type="text/css"/>
        <meta name="viewport" content="width=device-width, initial scale=1.0"/>
        <link rel="shortcut icon" href="../web_images/tab_icon.png" type="image/x-icon">

        <style>
            .journal_entry_table thead{
                background-color: #234094;
            }
            .journal_entry_table .textbox{
                background-color: #f0f2f7;
                width: 100%;
                margin: auto;
            }
            .fixed_pos{
                position: fixed;
            }
            .of_req_form{
                right: 5%;
                top: 200px;
                width: 120px;
            }
            .sml_txt{
                width: 300px;
            }
        </style>
    </head>
    <body>
        <form action="new_payment_voucher.php" method="post" enctype="multipart/form-data">
            <input type="hidden" id="txt_shall_expand_toUpdate" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim($_SESSION['table_to_update']) : '' ?>" />

            <input type="hidden" id="txt_chsn_budget_prep_upd" class="textbox push_right" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim(chosen_budget_prep_upd()) : '' ?>" />
            <input type="hidden" id="txt_chsn_project_by_activity" class="push_right" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim(get_project_by_activity(chosen_budget_prep_upd())) : '' ?>" />
            <input type="hidden" id="txt_chsn_budget_by_project" class="push_right" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim(get_budget_by_project(get_project_by_activity(chosen_budget_prep_upd()))) : '' ?>" />
            <input type="hidden" id="get_chsn_payee_type_upd" class="push_right" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim(chosen_payee_type_upd()) : '' ?>" />
            <input type="hidden" id="txt_chsn_payment_method_upd" class="push_right" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim(chosen_payment_method_upd()) : '' ?>" />
            <input type="hidden" id="txt_chsn_reference_upd" class="push_right" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim(chosen_reference_upd()) : '' ?>" />
            <input type="hidden" id="txt_chsn_reference_no_upd" class="push_right" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim(chosen_ref_number_upd()) : '' ?>" />
            <input type="hidden" id="txt_chsn_unit_cost_upd" class="push_right" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim(chosen_unit_cost_upd()) : '' ?>" />
            <input type="hidden" id="txt_chsn_quantity_upd" class="push_right" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim(chosen_quantity_upd()) : '' ?>" />
            <input type="hidden" id="txt_chsn_cheque_number_upd" class="push_right" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim(chosen_cheque_number_upd()) : '' ?>" />
            <input type="hidden" id="txt_chsn_details_upd" class="push_right" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim(chosen_details_upd()) : '' ?>" />
            <input type="hidden" id="txt_chsn_account_upd" class="push_right" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim(chosen_account_upd()) : '' ?>" />
            <input type="hidden" id="txt_chsn_bank_upd" class="push_right" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim(chosen_bank_upd()) : '' ?>" />

            <!--this field  (shall_expand_toUpdate)above is for letting the form expand using js for updating-->
            <input type="hidden" id="txt_item_id"   name="txt_item_id"/>
            <input type="hidden" id="txt_budget_prep_id"   name="txt_budget_prep_id"/>
            <input type="hidden" style="float: right;" id="txt_activity_id"   name="txt_activity_id"/>
<?php
include 'admin_header.php';
$ot = new other_fx();
$ot2 = new Other_fx2();
$ot->get_searchNew_menu('New Payment voucher', without_admin());
$ot->get_yes_no_dialog();

$ot2->get_details_result_pane(); //This is where details results will be ocmming to be displayed
?>

            <!--Start dialog's-->
            <div class="parts abs_full y_n_dialog off">
                <div class="parts dialog_yes_no no_paddin_shade_no_Border reverse_border">
                    <div class="parts full_center_two_h heit_free margin_free skin">
                        Do you really want to delete this record?
                    </div>
                    <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border top_off_x margin_free">
                        <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_xx link_cursor yes_dlg_btn" id="citizen_yes_btn">Yes</div>
                        <div class="parts yes_no_btns no_shade_noBorder reverse_border left_off_seventy link_cursor no_btn" id="no_btn">No</div>
                    </div>
                </div>
            </div>   
            <!--End dialog-->

            <div class="parts no_paddin_shade_no_Border white_bg abs_full view_transp">
                <div class="parts fifty_centered no_paddin_shade_no_Border heit_free add_load_gif off">.</div> 
            </div>
            <div class="parts no_paddin_shade_no_Border data_res full_center_two_h heit_free off payment_voucher_items_form abs_child fixed_pos" style="height: 100%; overflow-y: scroll;  z-index: 300;">
                <table class="dataList_table journal_entry_table thehidden_part " style="  width: 80%;">
<?php
$req_form = new Other_fx2();
$req_form->get_request_form();
?>
                </table>
                <button class="parts done_btn confirm_buttons fixed_pos of_req_form link_cursor" value="Ok">Ok</button>
            </div>
            <div class="parts eighty_centered off saved_dialog">
                payment_voucher saved successfully!
            </div>

            <div class="parts eighty_centered new_data_box margin_free off">
                <div class="parts eighty_centered new_data_title margin_free">  payment voucher Registration </div>
                <p class="warn_msg"></p>
                <div class="parts no_paddin_shade_no_Border margin_free">

                    <table class="new_data_table initial_table no_margin_top">
                        <tr><td>
                                Budget
                            </td><td>
                                <table class="margin_free">
                                    <tr>
                                        <td>Budget line <br/><?php get_type_project_combo(); ?> </td>
                                        <td>project<br/> 
                                            <select class="textbox cbo_fill_projects cbo_project cbo_onfly_p_project_change" required="" style="width: 150px;">
                                                <option> </option>
                                            </select> 
                                        </td>
                                        <td>Select the Activity<br/>
                                            <select required="" class="textbox tobe_refilled cbo_fill_activity cbo_activity  cbo_onfly_p_activity_change" style="width: 150px;">
                                                <option> </option>
                                            </select> 
                                        </td>
                                        </td>
                                    </tr>
                                </table></td>
                        </tr>
                        <tr>
                            <td class="new_data_tb_frst_cols"></td><td>  </td>
                        </tr>
                        <tr>
                            <td></td><td>
                            </td>
                        </tr>
                        <tr>
                            <td>Account</td><td>
<?php account_in_combo(); ?>
                            </td>
                        </tr>
                        <tr class="off"><td class="new_data_tb_frst_cols">Item </td><td> <?php get_item_combo(); ?>  </td></tr>
                        <tr><td><label for="txt_payee">Payee </label></td><td> 
                                <span style="padding: 6px;   float: left;">
                                    <input type="radio" name="rd_supplier_staff" class="push_left" checked="true"  value="staff" id="rd_staff">         <label for="rd_staff" class="push_left">      Staff </label>
                                    <input type="radio" name="rd_supplier_staff" class="push_left"                 value="supplier" id="rd_supplier">   <label for="rd_supplier" class="push_left">supplier </label>
                                </span>
                                <span id="supplier_auto_hide" class="push_right">  <?php get_supplier(); ?>    </span>
                                <span id="staff_auto_hide" class="push_right">   <?php get_staff_combo(); ?>   </span>
                            </td>
                        </tr>
                        <tr>
                            <td>Payment method</td><td> 
                                <span style="padding: 6px;   float: left;">
                                    <input type="radio" name="rd_bank_cash" class="push_left" checked="true" value="bank" id="rd_bank"><label for="rd_bank" class="push_left">Bank </label>
                                    <input type="radio" name="rd_bank_cash" class="push_left"                value="cash" id="rd_cash"><label for="rd_cash" class="push_left">Cash </label>
                                </span>
                                <span class="push_right off" id="bank_used">
                                    <span class="push_right">   <?php get_bank_combo() ?></span>
                                </span>
                            </td>
                        </tr>  
                        <tr>
                            <td>payment reference</td>
                            <td>
                                <span style="padding: 6px;   float: left;">
                                    <input type="radio" name="rd_payment_reference" class="push_left"          value="purchase order" id="rd_Purchase_order"><label for="rd_Purchase_order" class="push_left">Purchase Order </label>
                                    <input type="radio" name="rd_payment_reference" class="push_left"         value="invoice" id="rd_purchase_invoice"><label for="rd_purchase_invoice" class="push_left">Purchase Invoice </label>
                                    <input type="radio" name="rd_payment_reference" class="push_left"   checked="true"       value="payment voucher" id="rd_ref"><label for="rd_ref" class="push_left">No reference </label>
                                </span>
                            </td>
                        </tr>
                        <tr id="po_data_row" class="off">
                            <td>Purchase Order </td><td><?php get_purchase_order_line(); ?></td>
                        </tr>
                        <tr id="invc_data_row" class="off">
                            <td>Purchase Invoice </td><td><?php get_purchase_invoice_combo(); ?></td>
                        </tr>
                        <tr>
                            <td colspan="2">
                                <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border add_load_gif off" >.</div>
                                <span class="po_invoice_res"> </span>
                            </td>
                        </tr>

                        <tr>
                            <td colspan="2">
                                <button class="  push_right" id="py_vchr_btn_show_req_form" value="Add Items">Specify Items</button>
                            </td>
                        </tr>
                        <tr id="existing_qty_uc_row"><td><label for="txt_init_quantity">Quantity </label></td><td> <input type="text"  autocomplete="off"   name="txt_init_quantity"  id="txt_quantity" class="textbox" style="width: 200px;" value="<?php echo trim(chosen_quantity_upd()); ?>"   />
                                <span class="push_right">
                                    <label for="txt_unit_cost">unit cost </label>
                                    <input type="text" autocomplete="off"    name="txt_init_unit_cost"  id="txt_unit_cost" class="textbox only_numbers"style="width: 200px;" value="<?php echo trim(chosen_unit_cost_upd()); ?>"   />
                                </span>
                            </td>
                        </tr>
                        <tr> <td></td><td></td>  </tr>
                        <tr class="off"><td class="new_data_tb_frst_cols">Budget prep </td><td> <?php //get_budget_prep_combo();                                                                                                                                                                                                                                                                                  ?>  </td></tr>
                    </table>
                </div>
                <div class="parts no_shade_noBorder ">
                    <table class="new_data_table">
                        <tr class="check_no_row">
                            <td colspan="2">Check Number</td>
                        </tr>
                        <tr class="check_no_row">

                            <td colspan="2"><input type="text" class="textbox sml_txt" id="txt_chek_no"  name="txt_chek_no" style="width: 350px"  /></td>
                        </tr>


                        <tr>
                            <td colspan="2">Description</td>

                        </tr>
                        <tr>
                            <td colspan="2"><textarea   class="textbox" id="txt_description"  name="txt_description" style="width:350px;"  ></textarea></td>

                        </tr>

                    </table>
                </div>

                <table  class="new_data_table appendable_table" style="width: 55%;">
                    <tr class="">
                        <td colspan="2"> <input type="submit" class="confirm_buttons" id="send_payment_voucher" name="send_payment_voucher" value="Save"/> 
<?php get_cancel_btn(); ?>
                        </td>
                    </tr>
                </table>
            </div>
            <div class="parts eighty_centered datalist_box" >
                <div class="parts no_shade_noBorder xx_titles no_bg whilte_text dataList_title">payment vouchers List</div>
<?php
$obj = new multi_values();
$obj->list_payment_voucher();
?>
            </div>  
        </form> 
                <?php
                $obj_exp = new other_fx();
                $obj_exp->get_pdf_excel('../prints/print_paymet_voucher.php', '../web_exports/excel_export.php');
                ?>
        <div class="parts eighty_centered  no_paddin_shade_no_Border no_shade_noBorder check_loaded">
        <?php require_once './navigation/add_nav.php'; ?> 
        </div>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="admin_script.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
        <script src="../web_scripts/date_picker/jquery-ui.js" type="text/javascript"></script>
        <script src="../web_scripts/date_picker/jquery-ui.min.js" type="text/javascript"></script>
        <script src="../web_scripts/searches.js" type="text/javascript"></script>
        <script src="../web_scripts/hide_headers.js" type="text/javascript"></script>
        <script type="text/javascript">
          $(document).ready(function () {
              var init_table = $('.textbox').width();
              console.log(init_table);
              var timer1_closed = false;
              var get_width;
              setTimeout(function () {});
              get_width = setTimeout(function () {

              }, 3000);
          });

        </script>
<?php
require_once './payment_voucher_js.php';
?>
        <div class="parts full_center_two_h heit_free footer"> Copyrights <?php echo '2018 - ' . date("Y") . ' MUHABURA MULTICHOICE COMPANY LTD Version 1.0' ?></div>
    </body>
</hmtl>
<?php

// <editor-fold defaultstate="collapsed" desc="---------Other fnxs --------------">

function chosen_transaction_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'journal_entry_line') {
            $id = chosen_reference_no_upd();
            $transaction = new Other_fx2();
            return $transaction->get_chosen_journal_entry_line_transaction();
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function get_purchase_order_line() {
    require_once '../web_db/other_fx.php';
    $other = new other_fx();
    $other->get_purchase_order_in_combo();
}

function get_purchase_invoice_combo() {
    $obj = new Other_fx2();
    $obj->get_purchase_inv_pytvoucher_in_combo();
}

function get_supplier() {
    $obj = new other_fx();
    $obj->get_supplier_sml_combo();
}

function account_in_combo() {
    $obj = new multi_values();
    $obj->get_account_in_combo_enabled();
}

function get_cancel_btn() {
    $obj = new other_fx;
    $obj->get_cancel_button();
}

function get_bank_combo() {
    $obj = new multi_values();
    $obj->get_bank_in_combo_sml();
}

function get_type_project_combo() {
    $obj = new multi_values();
    $obj->get_type_project_in_sml_cbo();
}

function get_project_combo() {
    $obj = new multi_values();
    $obj->get_project_in_combo_refill();
}

function get_item_combo() {
    $obj = new multi_values();
    $obj->get_item_in_combo();
}

function get_staff_combo() {
    $obj = new multi_values();
    $obj->get_staff_sml_combo();
}

// </editor-fold>
// <editor-fold defaultstate="collapsed" desc="--while going to update----">


function chosen_payment_method_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'payment_voucher') {
            $id = $_SESSION['id_upd'];
            $payment_method = new Other_fx2();
            return $payment_method->get_chosen_payment_voucher_payment_method($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_bank_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'payment_voucher') {
            $id = $_SESSION['id_upd'];
            $bank = new Other_fx2();
            return $bank->get_chosen_payment_voucher_bank($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_cheque_number_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'payment_voucher') {
            $id = $_SESSION['id_upd'];
            $cheque_number = new Other_fx2();
            return $cheque_number->get_chosen_payment_voucher_cheque_number($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_details_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'payment_voucher') {
            $id = $_SESSION['id_upd'];
            $details = new Other_fx2();
            return $details->get_chosen_payment_voucher_details($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_payee_type_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'payment_voucher') {
            $id = $_SESSION['id_upd'];
            $payee_type = new Other_fx2();
            return $payee_type->get_chosen_payment_voucher_payee_type($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_reference_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'payment_voucher') {
            $id = $_SESSION['id_upd'];
            $reference = new Other_fx2();
            return $reference->get_chosen_payment_voucher_reference($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_ref_number_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'payment_voucher') {
            $id = $_SESSION['id_upd'];
            $ref_number = new Other_fx2();
            return $ref_number->get_chosen_payment_voucher_ref_number($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_item_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'payment_voucher') {
            $id = $_SESSION['id_upd'];
            $item = new multi_values();
            return $item->get_chosen_payment_voucher_item($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_entry_date_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'payment_voucher') {
            $id = $_SESSION['id_upd'];
            $entry_date = new multi_values();
            return $entry_date->get_chosen_payment_voucher_entry_date($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_User_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'payment_voucher') {
            $id = $_SESSION['id_upd'];
            $User = new multi_values();
            return $User->get_chosen_payment_voucher_User($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_quantity_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'payment_voucher') {
            $id = $_SESSION['id_upd'];
            $quantity = new multi_values();
            return $quantity->get_chosen_payment_voucher_quantity($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_unit_cost_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'payment_voucher') {
            $id = $_SESSION['id_upd'];
            $unit_cost = new multi_values();
            return $unit_cost->get_chosen_payment_voucher_unit_cost($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_amount_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'payment_voucher') {
            $id = $_SESSION['id_upd'];
            $amount = new multi_values();
            return $amount->get_chosen_payment_voucher_amount($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_budget_prep_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'payment_voucher') {
            $id = $_SESSION['id_upd'];
            $budget_prep = new Other_fx2();
            return $budget_prep->get_chosen_payment_voucher_budget_prep($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_payee_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'payment_voucher') {
            $id = $_SESSION['id_upd'];
            $payee = new multi_values();


            return $payee->get_chosen_payment_voucher_payee($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_account_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'payment_voucher') {
            $id = $_SESSION['id_upd'];
            $payee = new multi_values();
            return $payee->get_chosen_payment_voucher_account($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

// </editor-fold>




function get_items_in_combo() {
    require_once '../web_db/other_fx.php';

    $ot = new other_fx();
    $ot->get_items_in_combo();
}

function get_measurement_combo() {
    $obj = new other_fx();
    $obj->get_measurement_in_combo_arr();
}

function get_project_by_activity($activity) {
    $ot2 = new Other_fx2();
    return $proj = $ot2->get_chosen_project_by_activity($activity);
}

function get_budget_by_project($project) {
    $ot2 = new Other_fx2();
    return $ot2->get_chosen_budgetline_by_project($project);
}

<?php
session_start();
require_once '../web_db/multi_values.php';
require_once '../web_db/other_fx.php';
require_once '../web_db/Other_fx2.php';
require_once '../web_db/new_values.php';
require_once '../web_db/multi_values.php';
if (!isset($_SESSION)) {
    session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
if (isset($_POST['send_bank'])) {
    if (isset($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'bank') {
            require_once '../web_db/updates.php';
            $upd_obj = new updates();
            $bank_id = $_SESSION['id_upd'];
            $account = trim($_POST['txt_account_id']);
            $bank_name = trim($_POST['txt_name']);
            $chart_acc = trim($_POST['acc_name_combo']);
            $upd_obj->update_bank($account, $bank_name, $chart_acc, $bank_id);
            unset($_SESSION['table_to_update']);
        }
    } else {
        $account = trim($_POST['txt_account_id']);
        $bank_name = trim($_POST['txt_name']);
        $chart_acc = trim($_POST['acc_name_combo']);

        $obj = new new_values();
        $m = new multi_values();
        $ot = new other_fx();
        $ot2 = new Other_fx2();
        $acc_classid = $ot->get_acc_classid_byname('Cash_hand_bank');
        $acc_type = $ot2->get_acc_typeid_by_name('Income statement');

        $obj->new_account($acc_type, $acc_classid, $bank_name, 'Debit', 0, 1, 'yes', 'yes', 'no', 'current asset');
        $last_acc = $m->get_last_account();
        $obj->new_bank($account, $bank_name, $last_acc);
    }
}
?>

<html>
    <head>
        <meta charset="UTF-8">
        <title>
            bank</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <link href="admin_style.css" rel="stylesheet" type="text/css"/>
        <meta name="viewport" content="width=device-width, initial scale=1.0"/>
    </head>
    <body>
        <form action="new_bank.php" method="post" enctype="multipart/form-data">
            <input type="hidden" id="txt_shall_expand_toUpdate" value="<?php echo (isset($_SESSION['table_to_update'])) ? trim($_SESSION['table_to_update']) : '' ?>" />
            <!--this field  (shall_expand_toUpdate)above is for letting the form expand using js for updating-->
            <input type="hidden" id="txt_account_id"   name="txt_account_id"/>
            <?php
            include 'admin_header.php';
            $ot = new other_fx();
            $ot->get_yes_no_dialog();
            ?>
            <div class="parts eighty_centered more_settings">  <?php require_once './navigation/more_menus.php'; ?>   </div>

            <div class="parts eighty_centered no_paddin_shade_no_Border">  
                <div class="parts  no_paddin_shade_no_Border new_data_hider <?php echo without_admin(); ?>"> Add new record </div>
            </div>
            <div class="parts eighty_centered off saved_dialog">
                bank saved successfully!
            </div> 
            <div class="parts eighty_centered new_data_box off">
                <div class="parts eighty_centered "> Add bank accounts</div>
                <table class="new_data_table">
                    <tr><td>Name </td><td>  <input type="text" name="txt_name" id="bank_name" class="textbox">  </td></tr>
                    <tr><td>Account no. </td><td>  <input type="text" name="txt_account_id" id="txt_account" class="textbox">  </td></tr>
                    <tr><td>Chart of account . </td><td>  
                            <?php get_account_combo(); ?>
                        </td></tr>

                    <tr><td colspan="2"> 
                            <input type="submit" class="confirm_buttons" name="send_bank" value="Save"/>    <?php $ot->get_cancel_button(); ?> </td></tr>
                </table>
            </div>

            <div class="parts eighty_centered datalist_box" >
                <div class="parts no_shade_noBorder xx_titles no_bg whilte_text">Our banks</div>
                <?php
                $obj = new multi_values();
                $first = $obj->get_first_bank();
                $obj->list_bank($first);
                ?>
            </div>  
        </form>
        <!--Start of Type Details-->
        <div class="parts p_project_type_details data_details_pane abs_full margin_free white_bg">

        </div>
        <!--End Tuype Details-->
        <div class="parts  eighty_centered no_paddin_shade_no_Border no_bg margin_free export_btn_box">
            <table class="margin_free">
                <td>
                    <form action="../web_exports/excel_export.php" method="post">
                        <input type="hidden" name="bank" value="a"/>
                        <input type="submit" name="export" class="btn_export btn_export_excel" value="Export"/>
                    </form>
                </td>
                <td>
                    <form action="../prints/print_bank.php" method="post">
                        <input type="submit" name="export" class="btn_export btn_export_pdf" value="Export"/>
                    </form>
                </td>
            </table>
        </div>
        <div class="parts eighty_centered  no_paddin_shade_no_Border no_shade_noBorder check_loaded" >
            <?php require_once './navigation/add_nav.php'; ?> 
        </div>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="admin_script.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
        <script src="../web_scripts/date_picker/jquery-ui.min.js" type="text/javascript"></script>
        <script src="../web_scripts/date_picker/jquery-ui.js" type="text/javascript"></script>
        <script>
            var updname = $('#txt_shall_expand_toUpdate').val();
            if (updname != '') {
                var account = '<?php echo chosen_account_upd(); ?>';
                var name = '<?php echo chosen_name(); ?>';
                var char_acc = '<?php echo chosen_chart_acc_upd(); ?>';
                $('#txt_account').val(account);
                $('#bank_name').val(name);
                $('.cbo_account').val(char_acc);
                console.log(char_acc);

            }
        </script>
        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
    </body>
</hmtl>
<?php

function get_bal_sheet_only_cash_combo() {//this is diffe
    $obj = new multi_values();
    $obj->get_account_in_combo_bal_assetsect_cash();
}

function get_account_combo() {
    $obj = new multi_values();
    $obj->get_account_in_combo_enabled();
}

function chosen_account_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'bank') {
            $id = $_SESSION['id_upd'];
            $account = new multi_values();
            return $account->get_chosen_bank_account($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_chart_acc_upd() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'bank') {
            $id = $_SESSION['id_upd'];
            $account = new multi_values();
            return $account->get_chosen_chart_acc($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

function chosen_name() {
    if (!empty($_SESSION['table_to_update'])) {
        if ($_SESSION['table_to_update'] == 'bank') {
            $id = $_SESSION['id_upd'];
            $account = new multi_values();
            return $account->get_chosen_bank_name($id);
        } else {
            return '';
        }
    } else {
        return '';
    }
}

   
<div class="parts menu eighty_centered off">
    <a href="new_account.php">account</a>
    <a href="new_account_type.php">account_type</a>
    <a href="new_ledger_settings.php">ledger_settings</a>
    <a href="new_bank.php">bank</a>
    <a href="new_account_class.php">account_class</a>
    <a href="new_general_ledger_line.php">general_ledger_line</a>
    <a href="new_main_contra_account.php">main_contra_account</a>
    <a href="new_sales_receit_header.php">sales_receit_header</a>
    <a href="new_measurement.php">measurement</a>
    <a href="new_journal_entry_line.php">journal_entry_line</a>
    <a href="new_tax.php">tax</a>
    <a href="new_vendor.php">vendor</a>
    <a href="new_general_ledger_header.php">general_ledger_header</a>
    <a href="new_party.php">party</a>
    <a href="new_contact.php">contact</a>
    <a href="new_customer.php">customer</a>
    <a href="new_taxgroup.php">taxgroup</a>
    <a href="new_journal_entry_header.php">journal_entry_header</a>
    <a href="new_Payment_term.php">Payment_term</a>
    <a href="new_item.php">item</a>
    <a href="new_item_group.php">item_group</a>
    <a href="new_item_category.php">item_category</a>
    <a href="new_vendor_payment.php">vendor_payment</a>
    <a href="new_sales_delivery_header.php">sales_delivery_header</a>
    <a href="new_sale_delivery_line.php">sale_delivery_line</a>
    <a href="new_sales_invoice_line.php">sales_invoice_line</a>
    <a href="new_sales_invoice_header.php">sales_invoice_header</a>
    <a href="new_sales_order_line.php">sales_order_line</a>
    <a href="new_sales_order_header.php">sales_order_header</a>
    <a href="new_sales_quote_line.php">sales_quote_line</a>
    <a href="new_sales_quote_header.php">sales_quote_header</a>
    <a href="new_sales_receit_header.php">sales_receit_header</a>
    <a href="new_purchase_invoice_header.php">purchase_invoice_header</a>
    <a href="new_purchase_invoice_line.php">purchase_invoice_line</a>
    <a href="new_purchase_order_header.php">purchase_order_header</a>
    <a href="new_purchase_order_line.php">purchase_order_line</a>
    <a href="new_purchase_receit_header.php">purchase_receit_header</a>
    <a href="new_purchase_receit_line.php">purchase_receit_line</a>
    <a href="new_Inventory_control_journal.php">Inventory_control_journal</a>
    <div class="parts two_fifty_right heit_free no_paddin_shade_no_Border">
        <a href="login.php">Login</a>
    </div>

</div>

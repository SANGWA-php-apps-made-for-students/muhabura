LOCK TABLES `account_type` WRITE;
/*!40000 ALTER TABLE `account_type` DISABLE KEYS */;
INSERT INTO `account_type` VALUES (1,'Income statement'),(2,'Balance sheet');
/*!40000 ALTER TABLE `account_type` ENABLE KEYS */;
UNLOCK TABLES;



LOCK TABLES `account` WRITE;
/*!40000 ALTER TABLE `account` DISABLE KEYS */;

INSERT INTO `account` VALUES (8,1,0,'Sales revenue','none','0','asdf','0','no','','income'),
(9,1,0,'Cost Of Good Sold','none','0','this is the my bk bank','0','no','','income'),
(10,1,0,'Research and Development','none','0','this is the my bk bank','0','no','','expense'),
(11,1,0,'Sales And Marketing','none','0','This is my main income','0','no','','expense'),
(12,1,0,'General & administrative','none','0','This is my second income','0','no','','expense'),
(13,2,0,'Interest Income','none','0','This is my second income','0','no','','expense'),
(14,1,0,'Income Tax','none','0','Salaries, electricity, etc','0','no','','expense'),
(15,2,0,'Cash_hand_bank','none','0','','0','no','','asset'),
(16,2,0,'Accounts Receivable','none','0','This is my income','yes','no','','curernt asset'),
(17,2,0,'Inventory','none','0','this is my house','yes','no','','current asset'),
(18,2,0,'Prepaid Expenses','none','0','this is my house','yes','no','','current asset'),
(19,2,0,'Other Current Asset','none','0','this is my house','yes','no','','current asset'),
(20,2,0,'Fixed asset At Cost','none','0','this is my house','yes','no','','fixed asset'),
(25,2,0,'accumulated depreciation','none','0','this is big table','yes','no','','liability'),
(26,2,0,'Accounts Payable','none','0','this is big table','yes','no','','liability'),
(27,2,0,'Accrued Expenses','none','0','this is big table','yes','no','','liability'),
(28,2,0,'Income tax payable','none','0','this is big table','yes','no','','liability'),
(29,2,0,'Current portion of debt','none','0','this is big table','yes','no','','liability'),
(30,2,0,'Long term debt','none','0','Main transport expenses','yes','no','','equity'),
(31,2,0,'Share Capital','none','0','Using cars, mine from others','yes','no','','equity'),
(39,2,0,'Retained Earnings','none','0','online transactions','yes','no','','equity'),
(40,1,0,'Other income','none','0','These are rare income','yes','no',NULL,'income'),
(41,1,0,'Other expense','none','0','These are rare expenses','yes','no',NULL,'expense'),
(42,2,NULL,'Other liabilities','none','0','These are other liabilities','yes','no',NULL,'liability'),
(43,1,0,'agro sales','none',NULL,NULL,'yes','yes',NULL,'current asset');



/*!40000 ALTER TABLE `account` ENABLE KEYS */;
UNLOCK TABLES;


 












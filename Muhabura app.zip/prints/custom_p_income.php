<?php

    /**
     * Description of custom_p_income
     *
     * SANGWA 
     */
    require_once 'Fpdf/fpdf.php';
    require_once '../web_db/connection.php';

    class PDF extends FPDF {

// Load data
        function LoadData() {
            // Read file lines

            $database = new dbconnection();
            $db = $database->openconnection();
            $sql = "select distinct journal_entry_line.journal_entry_line_id,  journal_entry_line.accountid,  journal_entry_line.dr_cr,  sum(journal_entry_line.amount) as amount,  journal_entry_line.memo,  journal_entry_line.journal_entry_header,  account.name as account, party.name as party from journal_entry_line 
                   join account on journal_entry_line.accountid=account.account_id
                        join journal_entry_header on journal_entry_header.journal_entry_header_id=journal_entry_line.journal_entry_header
                        join account_type on account_type.account_type_id=account.acc_type
                        join party on journal_entry_header.party = party.party_id 
                        where  account_type.name='income'
                        group by account.name 
                         ";
            // <editor-fold defaultstate="collapsed" desc="----text Above (header = company addresses) ------">
            $this->Image('../web_images/report_header.png');
            $this->Cell(120, 7, ' ', 0, 0, 'L');

            $this->Ln();
            $this->SetFont("Arial", 'B', 14);
            $this->Cell(170, 7, 'INCOME STATEMENT', 0, 0, 'C');
            $this->Ln();
            $this->SetFont("Arial", 'B', 12);
            $this->Cell(170, 7, 'INCOME ', 0, 0, 'L');

            $this->Ln();
            $this->SetFont("Arial", '', 11);
// </editor-fold>

            $this->Cell(35, 7, strtoupper('Account'), 1, 0, 'L');
            $this->Cell(30, 7, strtoupper('Amount'), 1, 0, 'L');
            $this->Cell(60, 7, strtoupper('Memo'), 1, 0, 'L');
            $this->Cell(45, 7, strtoupper('Client/Supplier'), 1, 0, 'L');

            $this->Ln();
            foreach ($db->query($sql) as $row) {
                $this->cell(35, 7, $row['account'], 1, 0, 'L');
                $this->cell(30, 7, number_format($row['amount']), 1, 0, 'L');
                $this->cell(60, 7, $row['memo'], 1, 0, 'L');
                $this->cell(45, 7, $row['party'], 1, 0, 'L');

                $this->Ln();
            }

            $this->Ln();
            $this->Ln();
            $this->SetFont("Arial", 'B', 12);
            $this->Cell(170, 7, 'EXPENSES ', 0, 0, 'L');
            $this->SetFont("Arial", '', 12);
            $this->Ln();
            $this->Cell(35, 7, strtoupper('Account'), 1, 0, 'L');
            $this->Cell(30, 7, strtoupper('Amount'), 1, 0, 'L');
            $this->Cell(60, 7, strtoupper('Memo'), 1, 0, 'L');
            $this->Cell(45, 7, strtoupper('Client/Supplier'), 1, 0, 'L');
            $this->Ln();
            $sql2 = "select distinct journal_entry_line.journal_entry_line_id,  journal_entry_line.accountid,  journal_entry_line.dr_cr,  sum(journal_entry_line.amount) as amount,  journal_entry_line.memo,  journal_entry_line.journal_entry_header,  account.name as account, party.name as party from journal_entry_line 
                   join account on journal_entry_line.accountid=account.account_id
                        join journal_entry_header on journal_entry_header.journal_entry_header_id=journal_entry_line.journal_entry_header
                        join account_type on account_type.account_type_id=account.acc_type
                        join party on journal_entry_header.party = party.party_id 
                        where  account_type.name='Expense'
                        group by account.name 
                         ";


            foreach ($db->query($sql2) as $row) {
                $this->cell(35, 7, $row['account'], 1, 0, 'L');
                $this->cell(30, 7, number_format($row['amount']), 1, 0, 'L');
                $this->cell(60, 7, $row['memo'], 1, 0, 'L');
                $this->cell(45, 7, $row['party'], 1, 0, 'L');

                $this->Ln();
            }
        }

        function get_font() {
            $obj = new preppared_footer();
            return $font = $obj->fonts();
        }

        function prepared_by() {
            $this->SetFont('Arial', 'I', 8);
            // Print centered page number
            $this->Cell(0, 10, ' ', 0, 0, 'R');
            $this->Ln();
            $this->Cell(0, 10, ' ', 0, 0, 'R');
            $this->Ln();
            $this->Image('../web_images/prepared_by_protrait.png');
        }

    }

    $pdf = new PDF();
    $pdf->SetFont('Arial', '', 11);
    $pdf->AddPage();
    $pdf->LoadData();
    $pdf->prepared_by();
    $pdf->Output();

    
<?php

    require_once 'Fpdf/fpdf.php';
    require_once '../web_db/connection.php';
    require_once './preppared_footer.php';

    class PDF extends FPDF {

// Load data
        function LoadData() {
            // Read file lines

            $database = new dbconnection();
            $db = $database->openconnection();
            $sql = "select * from user  ";
            // <editor-fold defaultstate="collapsed" desc="----text Above (header = company addresses) ------">
            $this->Cell(120, 7, 'MUHABURA MULTI CHOICE LTD', 0, 0, 'L');
            $this->Cell(60, 7, 'DISTRICT: GASABO', 0, 0, 'L');
            $this->Ln();
            $this->Cell(120, 7, 'RWANDA ', 0, 0, 'E');
            $this->Cell(60, 7, 'TELEPHONE: . ', 0, 0, 'L');

            $this->Ln();
            $this->Ln();
            $this->Ln();
            $this->Ln();
            $this->SetFont("Arial", 'B', 14);
            $this->Cell(170, 7, 'USERS LIST ', 0, 0, 'C');

            $this->Ln();
            $this->Ln();
            $this->SetFont("Arial", '', 14);
// </editor-fold>

            $this->Cell(20, 7, 'ID', 1, 0, 'L');
            $this->Cell(38, 7, 'First name', 1, 0, 'L');
            $this->Cell(38, 7, 'Last name', 1, 0, 'L');
            $this->Cell(42, 7, 'Username', 1, 0, 'L');
            $this->Cell(42, 7, 'Email', 1, 0, 'L');
            $this->Ln();
            $this->SetFont("Arial", '', $this->get_font());
            foreach ($db->query($sql) as $row) {
                $this->cell(20, 7, $row['StaffID'], 1, 0, 'L');
                $this->cell(38, 7, $row['Firstname'], 1, 0, 'L');
                $this->cell(38, 7, $row['Lastname'], 1, 0, 'L');
                $this->cell(42, 7, $row['UserName'], 1, 0, 'L');
                $this->cell(42, 7, $row['EmailAddress'], 1, 0, 'L');



                $this->Ln();
            }
        }

        function prepared_by() {
            $this->SetFont('Arial', 'I', 8);
            // Print centered page number
            $this->Cell(0, 10, ' ', 0, 0, 'R');
            $this->Ln();
            $this->Cell(0, 10, ' ', 0, 0, 'R');
            $this->Ln();

            $this->Image('../web_images/prepared_by_protrait.png');
        }

        function get_font() {
            $obj = new preppared_footer();
            return $font = $obj->fonts();
        }

    }

    $pdf = new PDF();
    $pdf->SetFont('Arial', '', 13);
    $pdf->AddPage();
    $pdf->LoadData();
    $pdf->prepared_by();
    $pdf->Output();
    
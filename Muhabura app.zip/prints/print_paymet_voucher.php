<?php

require_once 'Fpdf/fpdf.php';
require_once '../web_db/connection.php';
require_once './preppared_footer.php';

class PDF extends FPDF {

// Load data
    function LoadData() {
        // Read file lines

        $database = new dbconnection();
        $db = $database->openconnection();
        require_once '../web_db/Other_fx2.php';
        $ot2 = new Other_fx2();
        $reference = $ot2->get_chosen_payment_voucher_reference(filter_input(INPUT_POST, 'pay_v_id'));
        $payt_id = filter_input(INPUT_POST, 'pay_v_id');
        $sql = " select payment_voucher.payment_voucher_id, payment_voucher.bank, payment_voucher.details,payment_voucher.item,  payment_voucher.entry_date,  payment_voucher.User,  payment_voucher.quantity,  payment_voucher.unit_cost,  payment_voucher.amount,  payment_voucher.budget_prep,  payment_voucher.payee,
                     user.Lastname,  user.Firstname ,
                     bank.name as bank 
                     from payment_voucher
                     left join bank on bank.bank_id=payment_voucher.bank
                     join user on user.StaffID=payment_voucher.User
                     where payment_voucher.payment_voucher_id=:id";
        if ($reference == 'invoice') {
            $sql2 = "select payment_voucher.payment_voucher_id, payment_voucher.bank, payment_voucher.details,payment_voucher.item,  payment_voucher.entry_date,  payment_voucher.User,  p_request.quantity,  p_request.unit_cost,  p_request.amount,  payment_voucher.budget_prep,  payment_voucher.payee,
                     user.Lastname,  user.Firstname ,
                     bank.name as bank,
                     p_budget_items.item_name,
                     measurement.code,
                     p_field.name as field
                     from payment_voucher
                     left join bank on bank.bank_id=payment_voucher.bank
                     join user on user.StaffID=payment_voucher.User
                     join main_request on payment_voucher.ref_number=main_request.Main_Request_id
                        join p_request on p_request.main_req= main_request.Main_Request_id
                        join p_budget_items on p_budget_items.p_budget_items_id=p_request.item
                    join measurement on measurement_id=p_request.measurement
                        join p_field on p_field.p_field_id=p_request.field
                     where payment_voucher.payment_voucher_id=:id";
            $stmt = $db->prepare($sql);
            $stmt2 = $db->prepare($sql2);
        } else if ($reference == 'purchase order') {
            $sql2 = "select payment_voucher.payment_voucher_id, payment_voucher.bank, payment_voucher.details,payment_voucher.item,  payment_voucher.entry_date,  payment_voucher.User,  p_request.quantity,  p_request.unit_cost,  p_request.amount,  payment_voucher.budget_prep,  payment_voucher.payee,
                     user.Lastname,  user.Firstname ,
                     bank.name as bank,
                     p_budget_items.item_name,
                     measurement.code,
                     p_field.name as field
                     from payment_voucher
                     left join bank on bank.bank_id=payment_voucher.bank
                     join user on user.StaffID=payment_voucher.User
                      join main_request on payment_voucher.ref_number=main_request.Main_Request_id
                      join p_request on p_request.main_req= main_request.Main_Request_id
                       join p_budget_items on p_budget_items.p_budget_items_id=p_request.item
                     join measurement on measurement_id=p_request.measurement
                      join p_field on p_field.p_field_id=p_request.field
                     where payment_voucher.payment_voucher_id=:id";
            $stmt = $db->prepare($sql);
            $stmt2 = $db->prepare($sql2);
        } else {
            $stmt = $db->prepare($sql);
        }

        $stmt = $db->prepare($sql);
        $stmt2 = $db->prepare($sql2);
        $stmt->execute(array(":id" => filter_input(INPUT_POST, 'pay_v_id')));
        $stmt2->execute(array(":id" =>  $payt_id));
//        //<editor-fold defaultstate="collapsed" desc="----text Above (header = company addresses) ------">
        $this->Image('../web_images/report_header.png');
        $this->Cell(170, 7, '   ', 0, 0, 'C');
        $this->Ln();

        $this->Ln();
        $this->SetFont("Arial", 'B', 14);
        $this->Cell(180, 7, 'PAYMENT VOUCHER No.: ' . $payt_id, 0, 0, 'C');
//
        $this->Ln();
        $this->Ln(); $this->SetFont("Arial", 'B', 10);
        $this->Cell(200, 7, strtoupper('SUMMARY'), 0, 0, 'L');
        $this->SetFont("Arial", '', 10);$this->Ln();
// </editor-fold>
        $this->Cell(45, 7, strtoupper('Amount'), 0, 0, 'L');
        $this->Cell(45, 7, strtoupper('User'), 0, 0, 'L');
        $this->Cell(30, 7, strtoupper('Bank'), 0, 0, 'L');
        $this->Cell(40, 7, strtoupper('Date of issue'), 0, 0, 'L');
        $this->Cell(70, 7, strtoupper('Description'), 0, 0, 'L');

        $this->Ln();
        $this->SetFont("Arial", '', $this->get_font());
        while ($row = $stmt->fetch()) {
            $this->cell(45, 7, number_format($row['amount']), 0, 0, 'L');
            $this->cell(45, 7, $row['Firstname'] . ' ' . $row['Lastname'], 0, 0, 'L');
            $this->cell(30, 7, $row['bank'], 0, 0, 'L');
            $this->cell(40, 7, $row['entry_date'], 0, 0, 'L');
            $this->cell(70, 7, $row['details'], 0, 0, 'L');
            $this->Ln();
        }
        if (filter_input(INPUT_POST, 'summary') == 'no') {

            if ($reference == 'invoice' || $reference == 'purchase order') {
                $this->Ln();
                $this->Ln();
                $this->Ln(); $this->SetFont("Arial", 'B', 10);

                $this->Cell(200, 7, strtoupper('REQUEST DETAILS'), 0, 0, 'L');
                $this->Ln();     
                $this->SetFont("Arial", '', 10);
                $this->Cell(41, 7, strtoupper('Item'), 0, 0, 'L');
                $this->Cell(30, 7, strtoupper('Unit Cost'), 0, 0, 'L');
                $this->Cell(25, 7, strtoupper('Quantity'), 0, 0, 'L');
                $this->Cell(30, 7, strtoupper('Amount'), 0, 0, 'L');
                $this->Cell(30, 7, strtoupper('Field'), 0, 0, 'L');
                $this->Cell(45, 7, strtoupper('Requester'), 0, 0, 'L');
               
                while ($row = $stmt2->fetch()) {
                    $this->cell(41, 7, $row['item_name'] . ' ' . $row['code'], 0, 0, 'L');
                    $this->cell(30, 7, $row['unit_cost'] . ' ', 0, 0, 'L');
                    $this->cell(25, 7, $row['quantity'] . ' '  , 0, 0, 'L');
                    $this->cell(30, 7, number_format($row['amount']) . ' '   , 0, 0, 'L');
                    $this->cell(30, 7, $row['field'], 0, 0, 'L');
                    $this->cell(45, 7, $row['Firstname'].' '.$row['Lastname'], 0, 0, 'L');
                    $this->Ln();
                }
            }
        }
    }

    function footer() {
        // Position at 1.5 cm from bottom
        $this->SetY(-15);
        // Arial italic 8
        $this->SetFont('Arial', 'I', 8);
        // Page number
        $this->Cell(0, 10, 'Page ' . $this->PageNo() . '/' . $this->AliasNbPages(), 0, 0, 'C');
    }

    function prepared_by() {
        $this->SetFont('Arial', 'I', 8);
        // Print centered page number
        $this->Cell(0, 10, ' ', 0, 0, 'R');
        $this->Ln();
        $this->Cell(0, 10, ' ', 0, 0, 'R');
        $this->Ln();
        $this->Image('../web_images/prepared_by_protrait.png');
    }

    function get_font() {
        $obj = new preppared_footer();
        return $font = $obj->fonts();
    }

}

$pdf = new PDF();
$pdf->SetFont('Arial', '', 10);
$pdf->AddPage();
$pdf->LoadData();
$pdf->prepared_by();

$pdf->Output();

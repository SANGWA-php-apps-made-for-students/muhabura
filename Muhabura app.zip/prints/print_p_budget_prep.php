<?php

    require_once 'Fpdf/fpdf.php';
    require_once '../web_db/connection.php';
    require_once './preppared_footer.php';

    class PDF extends FPDF {

// Load data
        function LoadData() {
            // Read file lines

            $database = new dbconnection();
            $db = $database->openconnection();
            $sql = "select p_budget_prep.p_budget_prep_id,  min(p_budget_prep.project_type) as project_type, min( p_budget_prep.user) as user,  min(p_budget_prep.entry_date) as entry_date,  min(p_budget_prep.budget_type) as budget_type,  min(p_budget_prep.activity_desc) as activity_desc,  min(p_budget_prep.name) as name ,min(p_type_project.name) as type,sum(p_activity.amount) as amount from p_budget_prep  "
                    . " join p_type_project on p_budget_prep.project_type=p_type_project.p_type_project_id "
                    . " join p_activity on p_activity.project=p_budget_prep.p_budget_prep_id "
                    . " group by p_budget_prep.p_budget_prep_id ";
            // <editor-fold defaultstate="collapsed" desc="----text Above (header = company addresses) ------">
            $this->Image('../web_images/report_header.png');

            $this->Ln();
            $this->Ln();
            $this->Ln();

            $this->Ln();
            $this->Ln();
            $this->Ln();
            $this->Ln();
            $this->SetFont("Arial", 'B', 14);
            $this->Cell(190, 7, 'BUDGET PREPARATION REPORT ', 0, 0, 'C');

            $this->Ln();
            $this->Ln();
            $this->SetFont("Arial", '', 10);
// </editor-fold>

            $this->Cell(15, 7, 'S/N', 1, 0, 'L');
            $this->Cell(100, 7, strtoupper('Budget Line'), 1, 0, 'L');
            $this->Cell(95, 7, strtoupper(wordwrap('Project')), 1, 0, 'L');
            $this->Cell(44, 7, strtoupper('Amount'), 1, 0, 'L');
            $this->Ln();
            $this->SetFont("Arial", '', $this->get_font());
            foreach ($db->query($sql) as $row) {
                $this->cell(15, 7, $row['p_budget_prep_id'], 1, 0, 'L');
                $this->cell(100, 7, $row['type'], 1, 0, 'L');

                $this->cell(95, 7, $row['name'], 1, 0, 'L');
                $this->cell(44, 7, number_format($row['amount']), 1, 0, 'L');


                $this->Ln();
            }
        }

        function prepared_by() {
            $this->SetFont('Arial', 'I', 8);
            // Print centered page number
            $this->Cell(0, 10, ' ', 0, 0, 'R');
            $this->Ln();
            $this->Cell(0, 10, ' ', 0, 0, 'R');
            $this->Ln();

            $this->Image('../web_images/prepared_by_protrait.png');
        }

        function get_font() {
            $obj = new preppared_footer();
            return $font = $obj->fonts();
        }

    }

    $pdf = new PDF();
    $pdf->SetFont('Arial', '', 11);
    $pdf->AddPage('L');
    $pdf->LoadData();
    $pdf->prepared_by();
    $pdf->Output();
    
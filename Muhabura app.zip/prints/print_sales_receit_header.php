<?php

    require_once 'Fpdf/fpdf.php';
    require_once '../web_db/connection.php';
    require_once './preppared_footer.php';

    class PDF extends FPDF {

// Load data
        function LoadData() {
            // Read file lines

            $database = new dbconnection();
            $db = $database->openconnection();
            $sql = "select * from sales_receit_header "
                    . " join user on user.StaffID= sales_receit_header.User";
            // <editor-fold defaultstate="collapsed" desc="----text Above (header = company addresses) ------">
            $this->Cell(120, 7, 'MUHABURA MULTI CHOICE COMPANY', 0, 0, 'L');
            $this->Cell(60, 7, 'DISTRICT: GASABO', 0, 0, 'L');
            $this->Ln();
            $this->Cell(120, 7, 'RWANDA ', 0, 0, 'E');
            $this->Cell(60, 7, 'TELEPHONE: . ', 0, 0, 'L');

            $this->Ln();
            $this->Ln();
            $this->Ln();
            $this->Ln();
            $this->SetFont("Arial", 'B', 11);
            $this->Cell(170, 7, 'SALES RECEIPTS REPORT ', 0, 0, 'C');

            $this->Ln();
            $this->Ln();
            $this->SetFont("Arial", '', 11);
// </editor-fold>

            $this->Cell(20, 7, 'S/N', 1, 0, 'L');
//            $this->Cell(30, 7, 'SALES INVOICE', 1, 0, 'L');
            $this->Cell(40, 7, 'ENTRY DATE', 1, 0, 'L');

            $this->Cell(30, 7, 'AMOUNT', 1, 0, 'L');
//            $this->Cell(30, 7, 'APPROVED', 1, 0, 'L');
            $this->Cell(30, 7, 'QUANTITY', 1, 0, 'L');
            $this->Cell(30, 7, 'UNIT COST', 1, 0, 'L');
//            $this->Cell(30, 7, 'CLIENT', 1, 0, 'L');
//            $this->Cell(30, 7, 'BUDGET PREP', 1, 0, 'L');
            $this->Cell(35, 7, 'USER', 1, 0, 'L');
//            $this->Cell(30, 7, 'ACCOUNT', 1, 0, 'L');
            $this->Ln();
            $this->SetFont("Arial", '', $this->get_font());
            foreach ($db->query($sql) as $row) {
                $this->cell(20, 7, $row['sales_receit_header_id'], 1, 0, 'L');
//                $this->cell(30, 7, $row['sales_invoice'], 1, 0, 'L');
                $this->cell(40, 7, $row['entry_date'], 1, 0, 'L');

                $this->cell(30, 7, $row['amount'], 1, 0, 'L');
//                $this->cell(30, 7, $row['approved'], 1, 0, 'L');
                $this->cell(30, 7, $row['quantity'], 1, 0, 'L');
                $this->cell(30, 7, $row['unit_cost'], 1, 0, 'L');
//                $this->cell(30, 7, $row['client'], 1, 0, 'L');
//                $this->cell(30, 7, $row['budget_prep'], 1, 0, 'L');
                $this->cell(35, 7, $row['Firstname'] . ' ' . $row['Lastname'], 1, 0, 'L');
//                $this->cell(30, 7, $row['account'], 1, 0, 'L');


                $this->Ln();
            }
        }

        function prepared_by() {
            $this->SetFont('Arial', 'I', 8);
            // Print centered page number
            $this->Cell(0, 10, ' ', 0, 0, 'R');
            $this->Ln();
            $this->Cell(0, 10, ' ', 0, 0, 'R');
            $this->Ln();

            $this->Image('../web_images/prepared_by_protrait.png');
        }

        function get_font() {
            $obj = new preppared_footer();
            return $font = $obj->fonts();
        }

    }

    $pdf = new PDF();
    $pdf->SetFont('Arial', '', 11);
    $pdf->AddPage();
    $pdf->LoadData();
    $pdf->prepared_by();
    $pdf->Output();
    
<?php

    require_once 'Fpdf/fpdf.php';
    require_once '../web_db/connection.php';
    require_once './preppared_footer.php';

    class PDF extends FPDF {

// Load data
        function LoadData() {
            // Read file lines

            $database = new dbconnection();
            $db = $database->openconnection();
            $sql = "select * from sales_order_line  ";
            // <editor-fold defaultstate="collapsed" desc="----text Above (header = company addresses) ------">
            $this->Cell(120, 7, 'MUHABURA MULTI CHOICE COMPANY', 0, 0, 'L');
            $this->Cell(60, 7, 'DISTRICT: GASABO', 0, 0, 'L');
            $this->Ln();
            $this->Cell(120, 7, 'RWANDA ', 0, 0, 'E');
            $this->Cell(60, 7, 'TELEPHONE: . ', 0, 0, 'L');

            $this->Ln();
            $this->Ln();
            $this->Ln();
            $this->Ln();
            $this->SetFont("Arial", 'B', 14);
            $this->Cell(170, 7, 'SALE ORDERS REPORT ', 0, 0, 'C');

            $this->Ln();
            $this->Ln();
            $this->SetFont("Arial", '', 11);
// </editor-fold>

            $this->Cell(30, 7, strtoupper('S/N'), 1, 0, 'L');
//            $this->Cell(30, 7, strtoupper('quotationid'), 1, 0, 'L');
            $this->Cell(25, 7, strtoupper('quantity'), 1, 0, 'L');
            $this->Cell(30, 7, strtoupper('unit cost'), 1, 0, 'L');
            $this->Cell(30, 7, strtoupper('amount'), 1, 0, 'L');
            $this->Cell(45, 7, strtoupper('entry date'), 1, 0, 'L');
//            $this->Cell(30, 7, strtoupper('User'), 1, 0, 'L');
            $this->Ln();
            $this->SetFont("Arial", '', $this->get_font());
            foreach ($db->query($sql) as $row) {
                $this->cell(30, 7, $row['sales_order_line_id'], 1, 0, 'L');
//                $this->cell(30, 7, $row['quotationid'], 1, 0, 'L');
                $this->cell(25, 7, $row['quantity'], 1, 0, 'L');
                $this->cell(30, 7, $row['unit_cost'], 1, 0, 'L');
                $this->cell(30, 7, $row['amount'], 1, 0, 'L');
                $this->cell(45, 7, $row['entry_date'], 1, 0, 'L');
//                $this->cell(30, 7, $row['User'], 1, 0, 'L');
                $this->Ln();
            }
        }

        function prepared_by() {
            $this->SetFont('Arial', 'I', 8);
            // Print centered page number
            $this->Cell(0, 10, ' ', 0, 0, 'R');
            $this->Ln();
            $this->Cell(0, 10, ' ', 0, 0, 'R');
            $this->Ln();

            $this->Image('../web_images/prepared_by_protrait.png');
        }

        function get_font() {
            $obj = new preppared_footer();
            return $font = $obj->fonts();
        }

    }

    $pdf = new PDF();
    $pdf->SetFont('Arial', '', 11);
    $pdf->AddPage();
    $pdf->LoadData();
    $pdf->prepared_by();
    $pdf->Output();
    
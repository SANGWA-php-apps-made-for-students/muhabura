<?php

    require_once 'Fpdf/fpdf.php';
    require_once '../web_db/connection.php';
    require_once './preppared_footer.php';

    class PDF extends FPDF {

// Load data
        function get_font() {
            $obj = new preppared_footer();
            return $font = $obj->fonts();
        }

        function LoadData() {
            // Read file lines
            $database = new dbconnection();

            $db = $database->openconnection();
            $req = filter_input(INPUT_POST, 'main_request');
            $sql = " SELECT  * from p_request
                 join p_budget_items  on  p_budget_items.p_budget_items_id= p_request.item 
                 join user on user.StaffID = p_request.User 
                 join measurement on measurement.measurement_id=p_request.measurement
                 where p_request.main_req='" . $req . "'  ";

            $sql2 = "select min(party.tin) as tin,min(party.name)as name, min(party.phone) as phone from purchase_order_line
                  join party on purchase_order_line.supplier=party.party_id
                  join p_request on p_request.p_request_id=purchase_order_line.request
                    where party.party_type='supplier' and p_request.main_req='" . $req . "'  "
                    . "  group by party.party_id";
            // <editor-fold defaultstate="collapsed" desc="----text Above (header = company addresses) ------">

            $this->Image('../web_images/report_header.png');

            $this->Ln();
            $this->Ln();
            $this->Ln();
            $this->Ln();
            $this->Ln();
            $this->Ln();
            $this->Ln();

            $this->Ln();
            $this->SetFont("Arial", 'B', 14);
            $purchase_yes_no = (filter_has_var(INPUT_POST, 'purchase_y_no')) ? 'PURCHASE ORDER' : 'REQUESTS';

            $this->Cell(30, 7, '  ', 0, 0, 'C');
            $this->Ln();
            $this->Cell(170, 7, $purchase_yes_no . ' ', 0, 0, 'C');

            $this->Ln();
            $this->Ln();
            $this->SetFont("Arial", '', 11);
// </editor-fold>
//            $this->Cell(30, 7, 'S/N', 1, 0, 'L');
            foreach ($db->query($sql2) as $row2) {
                $this->Cell(70, 7, '', 0, 0, 'L');
                $this->cell(40, 7, 'Supplier  Name: ' . $row2['name'], 0, 0, 'L');
                $this->Ln();

                $this->Cell(70, 7, '', 0, 0, 'L');
                $this->cell(40, 7, 'Supplier TIN: ' . $row2['tin'], 0, 0, 'L');
                $this->Ln();
                $this->Cell(70, 7, '', 0, 0, 'L');
                $this->cell(40, 7, 'Supplier  Phone: ' . $row2['phone'], 0, 0, 'L');
            }
            $this->Ln();
            $this->Ln();
            $this->SetFont('Arial', '', $this->get_font());

//          $this->Cell(30, 7, 'measurement', 1, 0, 'L');
            $this->Cell(60, 7, strtoupper('item'), 1, 0, 'L');
            $this->Cell(30, 7, strtoupper('quantity'), 1, 0, 'L');
            $this->Cell(30, 7, strtoupper('unit cost'), 1, 0, 'L');
            $this->Cell(30, 7, strtoupper('amount'), 1, 0, 'L');
//            $this->Cell(40, 7, strtoupper('entry date'), 1, 0, 'L');
            $this->Cell(40, 7, strtoupper('User'), 1, 0, 'L');

            $this->Ln();
            $this->SetFont("Arial", '', $this->get_font());
            $tot_amount = 0;
            foreach ($db->query($sql) as $row) {
                $tot_amount += $row['amount'];
//                $this->cell(30, 7, $row['p_request_id'], 1, 0, 'L');
//                $this->cell(30, 7, $row['measurement'], 1, 0, 'L');
                $this->cell(60, 7, $row['item_name'], 1, 0, 'L');
                $this->cell(30, 7, $row['quantity'] . ' ' . $row['code'], 1, 0, 'L');
                $this->cell(30, 7, number_format($row['unit_cost']), 1, 0, 'L');
                $this->cell(30, 7, number_format($row['amount']), 1, 0, 'L');

//                $names = 'ttttttt tttttttt askdfj asl faskjlf ';
//                $n = $pdff->WordWrap($names, 120);
                $this->cell(40, 7, $row['Firstname'] . ' ' . $row['Lastname'], 1, 0, 'L');

//                $this->cell(30, 7, $row['request_no'], 1, 0, 'L');
                $this->Ln();
            }
            $this->cell(110, 7, '', 0, 0, 'L');
            $this->SetFont("Arial", 'B', 12);
            $this->cell(120, 7, 'Total: ' . number_format($tot_amount), 0, 0, 'L');
        }

        function prepared_by() {
            $this->SetFont('Arial', 'I', 8);
            // Print centered page number
            $this->Cell(0, 10, ' ', 0, 0, 'R');
            $this->Ln();
            $this->Cell(0, 10, ' ', 0, 0, 'R');
            $this->Ln();
            $this->Image('../web_images/PO Portrait footer.png');
        }

        function Approved_by() {
            // Go to 1.5 cm from bottom
//            $this->SetY(-32);
            // Select Arial italic 8
            $this->SetFont('Arial', 'I', 8);
            // Print centered page number
            $this->Cell(0, 30, 'Approved by........................................................ ', 0, 0, 'R');
//            $this->Ln();
//            $this->Cell(0, 10, 'Approved by............................. ', 1, 0, 'R');
        }

    }

    $pdf = new PDF();
    $pdf->SetFont('Arial', '', $pdf->get_font());
    $pdf->AddPage();
    $pdf->LoadData();
    $pdf->Ln();
    $pdf->prepared_by();

    $pdf->Output();

//    $pdf->Footer();
   
    
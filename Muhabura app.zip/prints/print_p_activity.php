<?php

    require_once 'Fpdf/fpdf.php';
    require_once '../web_db/connection.php';
    require_once './preppared_footer.php';

    class PDF extends FPDF {

// Load data
        function LoadData() {
            // Read file lines

            $database = new dbconnection();
            $db = $database->openconnection();
            $sql = "select p_activity.p_activity_id,"
                    . "p_type_project.name as type, "
                    . " p_activity.project,  p_activity.name,project_expectations.name as budget_type, p_budget_prep.name as project,  user.Firstname,user.Lastname"
                    . " from p_activity "
                    . " join project_expectations on project_expectations.project_expectations_id= p_activity.budget_type "
                    . " join p_budget_prep on p_budget_prep.p_budget_prep_id=p_activity.project"
                    . " join user on user.StaffID= p_budget_prep.user "
                    . " join p_type_project on p_type_project.p_type_project_id= p_budget_prep.project_type "
                    . "  ";
            //<editor-fold defaultstate="collapsed" desc="----text Above (header = company addresses) ------">
            $this->Image('../web_images/report_header.png');
            $this->Cell(170, 7, '   ', 0, 0, 'C');
            $this->Ln();

            $this->Ln();
            $this->SetFont("Arial", 'B', 14);
            $this->Cell(260, 7, 'ACTIVITIES REPORT ', 0, 0, 'C');

            $this->Ln();
            $this->Ln();
            $this->SetFont("Arial", '', 10);
// </editor-fold>

            $this->Cell(20, 7, strtoupper('S/N'), 1, 0, 'L');
            $this->Cell(80, 7, strtoupper('Budget'), 1, 0, 'L');

            $this->Cell(80, 7, strtoupper('project'), 1, 0, 'L');
            $this->Cell(85, 7, strtoupper('Activity'), 1, 0, 'L');
//            $this->Cell(45, 7, strtoupper('fisc year'), 1, 0, 'L');
//            $this->Cell(40, 7, strtoupper('user'), 1, 0, 'L');
            $this->Ln();
            $this->SetFont("Arial", '', $this->get_font());
            foreach ($db->query($sql) as $row) {
                $this->cell(20, 7, $row['p_activity_id'], 1, 0, 'L');
                $this->cell(80, 7, $row['type'], 1, 0, 'L');


                $this->cell(80, 7, $row['project'], 1, 0, 'L');
                $this->cell(85, 7, $row['name'], 1, 0, 'L'); //activity
//                $this->cell(45, 7, $row['start_date'] . ' - ' . $row['end_date'], 1, 0, 'L');
//                $this->cell(40, 7, $row['Firstname'] . ' ' . $row['Lastname'], 1, 0, 'L');
                $this->Ln();
            }
        }

        function footer() {
            // Position at 1.5 cm from bottom
            $this->SetY(-15);
            // Arial italic 8
            $this->SetFont('Arial', 'I', 8);
            // Page number
            $this->Cell(0, 10, 'Page ' . $this->PageNo() . '/' . $this->AliasNbPages(), 0, 0, 'C');
        }

        function prepared_by() {
            $this->SetFont('Arial', 'I', 8);
            // Print centered page number
            $this->Cell(0, 10, ' ', 0, 0, 'R');
            $this->Ln();
            $this->Cell(0, 10, ' ', 0, 0, 'R');
            $this->Ln();

            $this->Image('../web_images/prepared_by_protrait.png');
        }

        function get_font() {
            $obj = new preppared_footer();
            return $font = $obj->fonts();
        }

    }

    $pdf = new PDF();
    $pdf->SetFont('Arial', '', 10);
    $pdf->AddPage("L", "A4");
    $pdf->LoadData();
    $pdf->prepared_by();

    $pdf->Output();
    
<?php

    class preppared_footer extends FPDF {

        function fonts() {
            return 10;
        }

    }
    
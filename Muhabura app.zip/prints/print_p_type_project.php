<?php

    require_once 'Fpdf/fpdf.php';
    require_once '../web_db/connection.php';
    require_once './preppared_footer.php';
    require_once '../web_db/fin_books_sum_views.php';
    require_once '../web_db/other_fx.php';

    class PDF extends FPDF {

// Load data
        function get_font() {
            $obj = new preppared_footer();
            return $font = $obj->fonts();
        }

        function LoadData() {
            // Read file lines


            $database = new dbconnection();
            $db = $database->openconnection();

            $fin = new fin_books_sum_views();
            $ot = new other_fx();
            $min = $ot->get_this_year_start_date();
            $max = $ot->get_this_year_end_date();
            $sql = $fin->get_budgets();
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min_date" => $min, ":max_date" => $max));
            // <editor-fold defaultstate="collapsed" desc="----text Above (header = company addresses) ------">
            $this->Image('../web_images/report_header.png');

            $this->Ln();
            $this->Ln();
            $this->Ln();
            $this->Ln();
            $this->Ln();
            $this->Ln();
            $this->Ln();
            $this->SetFont("Arial", 'B', 14);
            $this->Cell(170, 7, 'BUDGET LINES REPORT OF ' . $min . ' - ' . $max, 0, 0, 'C');

            $this->Ln();
            $this->Ln();
            $this->SetFont("Arial", '', $this->get_font());
// </editor-fold>

            $this->Cell(15, 7, 'S/N', 1, 0, 'L');
            $this->Cell(110, 7, 'PROJECT', 1, 0, 'L');
            $this->Cell(35, 7, 'REVENUES', 1, 0, 'L');
            $this->Cell(35, 7, 'EXPENSES', 1, 0, 'L');
            $this->Cell(35, 7, 'GROSS PROFIT', 1, 0, 'L');
            $this->Cell(15, 7, '%', 1, 0, 'L');
            $this->Ln();
            $this->SetFont("Arial", '', 10);
            while ($row = $stmt->fetch()) {
                $sql2 = $fin->get_tot_rev_exp('revenue');
                $sql3 = $fin->get_tot_rev_exp('expense');

                $sql4 = $fin->get_implementation_rev_exp('income');
                $sql5 = $fin->get_implementation_rev_exp('expense');
                $stmt2 = $db->prepare($sql2);
                $stmt3 = $db->prepare($sql3);
                $stmt4 = $db->prepare($sql4);
                $stmt5 = $db->prepare($sql5);
                $stmt2->execute(array(":project" => $row['p_type_project_id']));
                $stmt3->execute(array(":project" => $row['p_type_project_id']));
                $stmt4->execute(array(":project" => $row['p_type_project_id']));
                $stmt5->execute(array(":project" => $row['p_type_project_id']));
                $row2 = $stmt2->fetch(PDO::FETCH_ASSOC);
                $row3 = $stmt3->fetch(PDO::FETCH_ASSOC);
                $row4 = $stmt4->fetch(PDO::FETCH_ASSOC);
                $row5 = $stmt5->fetch(PDO::FETCH_ASSOC);
                $tot1 = ($row2['tot'] < 1) ? 1 : $row2['tot'];
                $exp1 = ($row3['tot'] < 1) ? 1 : $row3['tot'];

                $this->cell(15, 7, $row['p_type_project_id'], 1, 0, 'L');
                $this->cell(110, 7, strtoupper($row['prj_type']), 1, 0, 'L');
                $this->cell(35, 7, number_format($row2['tot']), 1, 0, 'L');
                $this->cell(35, 7, number_format($row5['tot']), 1, 0, 'L');
                $perc = $row5['tot'];
                $this->cell(35, 7, $perc = number_format($row2['tot'] - $row5['tot']), 1, 0, 'L');
                $this->cell(15, 7, number_format(($row2['tot'] - $row5['tot']) / $tot1 * 100) . '%', 1, 0, 'L');
                $this->Ln();
            }
        }

        function prepared_by() {
            $this->SetFont('Arial', 'I', 8);
            // Print centered page number
            $this->Cell(0, 10, ' ', 0, 0, 'R');
            $this->Ln();
            $this->Cell(0, 10, ' ', 0, 0, 'R');
            $this->Ln();

            $this->Image('../web_images/prepared_by_protrait.png');
        }

    }

//    parent::__construct('L', 'mm', 'A2', true, 'UTF-8', $use_cache, false);
    $pdf = new PDF();

    $pdf->SetFont('Arial', '', 10);
    $pdf->AddPage('L');
    $pdf->LoadData();
    $pdf->prepared_by();
    $pdf->Output();
    
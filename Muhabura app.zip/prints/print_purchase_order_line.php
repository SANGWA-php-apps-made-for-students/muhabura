<?php

    session_start();

    require_once 'Fpdf/fpdf.php';
    require_once '../web_db/connection.php';
    require_once './preppared_footer.php';
    require_once '../web_db/Reports.php';

    class PDF extends FPDF {

// Load data
        function LoadData() {
            try {   // Read file lines
                $rpt = new Reports ();
                $database = new dbconnection();
                $db = $database->openconnection();
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $cond = ($_SESSION['cat'] == 'admin') ? '' : " where purchase_order_line.User='" . $_SESSION['userid'] . "'";

                $sql = "SELECT  purchase_order_line.purchase_order_line_id, p_budget_items.item_name,  purchase_order_line.entry_date,user.Firstname,user.Lastname,p_request.p_request_id,purchase_order_line.quantity,purchase_order_line.unit_cost,purchase_order_line.amount, party.name  from purchase_order_line  "
                        . " join  user on user.StaffID=purchase_order_line.User "
                        . "  JOIN p_request on p_request.p_request_id = purchase_order_line.request"
                        . " join p_budget_items on p_budget_items.p_budget_items_id= p_request.item "
                        . " join party on party.party_id= purchase_order_line.supplier "
                        . " "
                        . $cond;
                $stmt = $db->prepare($sql);
                $stmt->execute();
                // <editor-fold defaultstate="collapsed" desc="----text Above (header = company addresses) ------">
                $this->Cell(70, 7, '', 0, 0, 'C');
                $this->Image('../web_images/report_header.png');

                $this->Cell(170, 7, '   ', 0, 0, 'C');
                $this->Ln();

                $this->Ln();
                $this->SetFont("Arial", 'B', 14);
                $this->Cell(250, 7, 'PURCHASE ORDERS', 0, 0, 'C');

                $this->Ln();
                $this->Ln();
                $this->SetFont("Arial", '', 10);
// </editor-fold>
                // <editor-fold defaultstate="collapsed" desc="----other ----">

                $this->Cell(12, 7, 'S/N', 1, 0, 'L');
                $this->Cell(35, 7, strtoupper('Item'), 1, 0, 'L');
                $this->Cell(35, 7, strtoupper('Date'), 1, 0, 'L');
                $this->Cell(45, 7, strtoupper('Done by'), 1, 0, 'L');
                $this->Cell(40, 7, strtoupper('Requested by '), 1, 0, 'L');
                $this->Cell(17, 7, strtoupper('quantity'), 1, 0, 'L');
                $this->Cell(17, 7, strtoupper('cost'), 1, 0, 'L');
//            $this->Cell(30, 7, 'discount', 1, 0, 'L');
                $this->Cell(17, 7, strtoupper('amount'), 1, 0, 'L');
                $this->Cell(55, 7, strtoupper('Supplier'), 1, 0, 'L');
                $this->Ln();
                $this->SetFont("Arial", '', $this->get_font()); // </editor-fold>




                while ($row = $stmt->fetch()) {
                    $this->cell(12, 7, $row['purchase_order_line_id'], 1, 0, 'L');
                    $this->cell(35, 7, $row['item_name'], 1, 0, 'L');
                    $this->cell(35, 7, $row['entry_date'], 1, 0, 'L');
                    $this->cell(45, 7, $row['Firstname'] . '  ' . $row['Lastname'], 1, 0, 'L');
                    $this->cell(40, 7, $rpt->get_requester($row['p_request_id']), 1, 0, 'L');
                    $this->cell(17, 7, $row['quantity'], 1, 0, 'L');
                    $this->cell(17, 7, number_format($row['unit_cost']), 1, 0, 'L');
//              $this->cell(30, 7, $row['discount'], 1, 0, 'L');
                    $this->cell(17, 7, number_format($row['amount']), 1, 0, 'L');
                    $this->cell(55, 7, $row['name'], 1, 0, 'L');

                    $this->Ln();
                }
            } catch (PDOException $e) {
                echo $e->getMessage();
            }
        }

        function prepared_by() {
            $this->SetFont('Arial', 'I', 8);
            // Print centered page number
            $this->Cell(0, 10, ' ', 0, 0, 'R');
            $this->Ln();
            $this->Cell(0, 10, ' ', 0, 0, 'R');
            $this->Ln();

            $this->Image('../web_images/prepared_by_protrait.png');
        }

        function get_font() {
            $obj = new preppared_footer();
            return $font = $obj->fonts();
        }

    }

    $pdf = new PDF();
    $pdf->SetFont('Arial', '', 10);
    $pdf->AddPage('L');
    $pdf->LoadData();
    $pdf->prepared_by();
    $pdf->Output();
    
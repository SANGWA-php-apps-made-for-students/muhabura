<?php

    session_start();

    require_once 'Fpdf/fpdf.php';
    require_once '../web_db/connection.php';

    class PDF extends FPDF {

// Load data
        function LoadData() {
            // Read file lines

            $database = new dbconnection();
            $db = $database->openconnection();
            $sql = " select p_type_project.name as type, p_budget_prep.name as proj, p_activity.name,  p_activity.amount ,p_budget_prep.entry_date
                     from p_activity                
                       join p_budget_prep on p_activity.project=p_budget_prep.p_budget_prep_id 
                       join p_type_project on p_budget_prep.project_type=p_type_project.p_type_project_id 
                         join project_expectations on project_expectations.project_expectations_id=p_activity.budget_type "
                    . " where     p_budget_prep.entry_date>=:min and p_budget_prep.entry_date<=:max and p_activity.project=:project"
                    . "  and project_expectations.name='revenue' "
                    . "  ";
            // <editor-fold defaultstate="collapsed" desc="----text Above (header = company addresses) ------">
            $this->Image('../web_images/report_header.png');
            $this->Ln();
            $this->Cell(60, 7, ': . ', 0, 0, 'L');

            $this->Ln();
            $this->SetFont("Arial", 'B', 13);
            $this->Cell(170, 7, 'ACTIVITIES REPORT FOR ' . strtoupper($_POST['project_name']) . '  PROJECT', 0, 0, 'C');

            $this->Ln();
            $this->Ln();

// </editor-fold>
            $this->SetFont("Arial", 'B', 12);

            $this->cell(5, 7, "REVENUES FOR " . strtoupper($_POST['project_name'] . ' (' . $_POST['type'] . '}'), 0, 0, 'L');
            $this->Ln();
            $this->SetFont("Arial", '', 9);
            $this->cell(5, 7, "", 0, 0, 'L');
            $this->Cell(65, 7, strtoupper('Activity'), 1, 0, 'L');
            $this->Cell(24, 7, strtoupper('Amount'), 1, 0, 'L');
            $this->Cell(35, 7, strtoupper('Entry date'), 1, 0, 'L');
            $this->Ln();
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $_SESSION['min_date'], ":max" => $_SESSION['max_date'], ":project" => $_POST['project']));
            $all_amount = 0;
            while ($row = $stmt->fetch()) {
                $this->cell(5, 7, "", 0, 0, 'L');
                $this->cell(65, 7, $row['name'], 1, 0, 'L');
                $this->cell(24, 7, number_format($row['amount']), 1, 0, 'L');
                $this->cell(35, 7, $row['entry_date'], 1, 0, 'L');
                $all_amount += $row['amount'];
                $this->Ln();
            }
            $this->cell(5, 7, "", 0, 0, 'L');
            $this->SetFont("Arial", 'B', 11);
            $this->Cell(90, 7, 'TOTAL ' . number_format($all_amount), 0, 0, 'R');
            $this->Ln();
            $this->Ln();
            $sql = "select p_type_project.name as type, p_budget_prep.name as proj, p_activity.name,  p_activity.amount ,p_budget_prep.entry_date
                       from p_activity
                        join p_budget_prep on p_activity.project=p_budget_prep.p_budget_prep_id 
                       join p_type_project on p_budget_prep.project_type=p_type_project.p_type_project_id 
                        join project_expectations on project_expectations.project_expectations_id=p_activity.budget_type "
                    . " where     p_budget_prep.entry_date>=:min and p_budget_prep.entry_date<=:max "
                    . "   and p_activity.project=:project "
                    . "  and project_expectations.name='expense' "
                    . "  ";
            $stmt1 = $db->prepare($sql);
            $stmt1->execute(array(":min" => $_SESSION['min_date'], ":max" => $_SESSION['max_date'], ":project" => $_POST['project']));
            $this->SetFont("Arial", 'B', 12);
            $this->AddPage();
            $this->cell(5, 7, "EXPENSES FOR " . strtoupper($_POST['project_name'] . ' (' . $_POST['type'] . ')'), 0, 0, 'L');
            $this->Ln();
            while ($row1 = $stmt1->fetch()) {
                $this->cell(5, 7, "", 0, 0, 'L');
                $this->cell(65, 7, $row['name'], 1, 0, 'L');

                $this->cell(24, 7, number_format($row['amount']), 1, 0, 'L');
                $this->cell(35, 7, $row['entry_date'], 1, 0, 'L');
                $all_amount += $row['amount'];
                $this->Ln();
            }
            // Go to 1.5 cm from bottom
            $this->SetY(-15);
            // Select Arial italic 8
            $this->SetFont('Arial', 'I', 8);
            // Print centered page number
            $this->Cell(0, 10, 'Page ' . $this->PageNo(), 0, 0, 'C');
        }

    }

    $pdf = new PDF();
    $pdf->SetFont('Arial', '', 10);
    $pdf->AddPage();
    $pdf->LoadData();
    $pdf->Output();
    
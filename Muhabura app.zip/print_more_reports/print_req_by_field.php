<?php

    /**
     * Description of print_req_by_field
     *
     * Done by SANGWA on  Oct 4, 2018
     */
    session_start();

    require_once 'Fpdf/fpdf.php';
    require_once '../web_db/connection.php';
    require_once '../web_db/other_fx.php';

    class PDF extends FPDF {

// Load data
        function LoadData() {
            // Read file lines

            $database = new dbconnection();
            $db = $database->openconnection();
            $fieldid = filter_input(INPUT_POST, 'field_id');
            $field_name = filter_input(INPUT_POST, 'field_name');
            require_once '../web_db/fin_books_sum_views.php';
            $fin = new fin_books_sum_views();


            // <editor-fold defaultstate="collapsed" desc="----text Above (header = company addresses) ------">
            $this->Image('../web_images/report_header.png');
            $this->Ln();
            $this->Cell(60, 7, ': . ', 0, 0, 'L');

            $this->Ln();
            $this->SetFont("Arial", 'B', 13);
            $this->Cell(170, 7, "REQUEST FOR ITEMS TO " . strtoupper($field_name), 0, 0, 'C');

            $this->Ln();
            $this->Ln();

// </editor-fold>
            $this->SetFont("Arial", 'B', 12);

//            $this->cell(5, 7, "REQUEST FOR ITEMS TO " . strtoupper($field_name), 0, 0, 'L');
            $this->Ln();
            $this->SetFont("Arial", '', 9);
//            $this->cell(5, 7, "", 0, 0, 'L');
            $this->Cell(28, 7, strtoupper('item'), 1, 0, 'L');
            $this->Cell(28, 7, strtoupper('Unit cost'), 1, 0, 'L');
            $this->Cell(28, 7, strtoupper('quantity'), 1, 0, 'L');
            $this->Cell(30, 7, strtoupper('amount'), 1, 0, 'L');
            $this->Cell(40, 7, strtoupper('Entry date'), 1, 0, 'L');
            $this->Cell(40, 7, strtoupper('user'), 1, 0, 'L');
            $this->Ln();

            $this->put_query_loop($db, $fin, $fieldid);
        }

        function put_query_loop($db, $obj, $field) {
            $sql = $obj->get_request_by_field();
            $stmt = $db->prepare($sql);
            $sdate = $this->s_date();
            $edate = $this->e_date();
//            $stmt->execute(array(":min_date" => $sdate, ":max_date" => $edate));
            $stmt->execute(array(":field" => $field));
            $this->loop_me($stmt);
        }

        function loop_me($stmt) {
            $sum = 0;
            $qty = 0;
            while ($row = $stmt->fetch()) {
//                $this->cell(40, 7, $row['budget'], 0, 0, 'L');
                $this->cell(28, 7, $row['item'], 1, 0, 'L');
                $this->cell(28, 7, $row['unit_cost'], 1, 0, 'L');
                $this->cell(28, 7, $row['quantity'] . ' ' . $row['measurement'], 1, 0, 'L');
                $this->cell(30, 7, number_format($row['amount']), 1, 0, 'L');
                $this->cell(40, 7, $row['entry_date'], 1, 0, 'L');
                $this->cell(40, 7, $row['Firstname'] . ' ' . $row['Lastname'], 1, 0, 'L');

                $this->Ln();
                $sum += $row['amount'];
                $qty += $row['quantity'];
            } $this->SetFont("Arial", 'B', 11);
            $this->cell(56, 7, 'TOTAL: ', 1, 0, 'L');
            $this->cell(28, 7, $qty, 1, 0, 'L');

            $this->cell(30, 7, number_format($sum), 1, 0, 'L');
            $this->cell(80, 7, '', 1, 0, 'L');

            $this->cell(158, 7, 'Total: ' . number_format($sum), 0, 0, 'R');
        }

        function title_it($title, $note) {
            $this->Ln();
            $this->cell(5, 7, "", 0, 0, 'L');
            $this->SetFont("Arial", 'B', 10);
            $this->cell(50, 7, $title, 0, 0, 'L');
            $this->cell(10, 7, $note, 0, 0, 'L');
            $this->Ln();
            $this->SetFont("Arial", '', 9);
        }

        function e_date() {
            $date_obj = new other_fx();
            return $date_obj->get_this_year_end_date();
        }

        function prepared_by() {
            $this->SetFont('Arial', 'I', 8);
            // Print centered page number
            $this->Cell(0, 10, ' ', 0, 0, 'R');
            $this->Ln();
            $this->Cell(0, 10, ' ', 0, 0, 'R');
            $this->Ln();

            $this->Image('../web_images/prepared_by_protrait.png');
        }

        function s_date() {
            $date_obj = new other_fx();
            return $date_obj->get_this_year_start_date();
        }

    }

    $pdf = new PDF();
    $pdf->SetFont('Arial', '', 10);
    $pdf->AddPage();
    $pdf->LoadData();
    $pdf->prepared_by();
    $pdf->Output();
    
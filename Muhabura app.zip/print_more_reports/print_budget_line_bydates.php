<?php

    session_start();

    require_once 'Fpdf/fpdf.php';
    require_once '../web_db/connection.php';

    class PDF extends FPDF {

// Load data
        function LoadData() {
            // Read file lines
            // <editor-fold defaultstate="collapsed" desc="----text Above (header = company addresses) ------">
            $this->Image('../web_images/report_header.png');
            $this->Ln();
            $this->Cell(60, 7, ': . ', 0, 0, 'L');

            $this->Ln();
            $this->SetFont("Arial", 'B', 14);
            $this->Cell(170, 7, 'BUDGET LINE (' . strtoupper(filter_input(INPUT_POST, 'proj_name')) . ') REPORT ', 0, 0, 'C');

            $this->Ln();
            $this->Ln();
            $prj_type = filter_input(INPUT_POST, 'type');
            $this->SetFont("Arial", '', 1);

// </editor-fold>
            $database = new dbconnection();
            $db = $database->openconnection();
            $sql = "    select   p_type_project.p_type_project_id,  p_budget_prep.entry_date,p_budget_prep.p_budget_prep_id,  p_budget_prep.budget_type as type,     p_type_project.name, p_budget_prep.name as project   from p_budget_prep "
                    . " join p_type_project on p_type_project.p_type_project_id=p_budget_prep.project_type "
                    . " where  p_budget_prep.entry_date>=:min and p_budget_prep.entry_date<=:max "
                    . " and    p_type_project.p_type_project_id=:type "
                    . "  ";
            $stmt1 = $db->prepare($sql);
            $stmt1->execute(array(":min" => $_SESSION['min_date'], ":max" => $_SESSION['max_date'], ":type" => $prj_type));
            while ($row1 = $stmt1->fetch()) {
                $this->SetFont("Arial", 'B', 11);
                $this->cell(5, 7, "", 0, 0, 'L');
                $this->cell(70, 7, 'PROJECT: ' . $row1['project'], 0, 0, 'L');
                $this->Ln();
                $sql = "select p_activity.name,p_budget_prep.entry_date,  p_activity.amount ,p_budget_prep.name as proj_name
                            from p_activity
                             join p_budget_prep on p_activity.project=p_budget_prep.p_budget_prep_id"
                        . " where     p_budget_prep.entry_date>=:min and p_budget_prep.entry_date<=:max and p_activity.project=:proj ";
                $stmt2 = $db->prepare($sql);
                $stmt2->execute(array(":min" => $_SESSION['min_date'], ":max" => $_SESSION['max_date'], ":proj" => $row1['p_budget_prep_id']));

                $this->cell(10, 7, "", 0, 0, 'L');
                $this->cell(78, 7, "Activity Name", 1, 0, 'L');
                $this->cell(35, 7, "Amount", 1, 0, 'L');
                $this->cell(35, 7, "Entry Date", 1, 0, 'L');
                $this->Ln();
                $proj_sum = 0;
                while ($row2 = $stmt2->fetch()) {
                    $this->SetFont("Arial", '', 10);
                    $this->cell(5, 7, "", 0, 0, 'L');
                    $this->cell(5, 7, "", 0, 0, 'L');
                    $this->cell(78, 7, $row2['name'], 1, 0, 'L');
                    $this->cell(35, 7, number_format($row2['amount']), 1, 0, 'L');
                    $this->cell(35, 7, $row2['entry_date'], 1, 0, 'L');
                    $this->Ln();
                    $proj_sum += $row2['amount'];
                }

                $this->cell(78, 7, "", 0, 0, 'L');
                $this->SetFont("Arial", 'B', 11);
                $this->SetFont("Arial", 'U', 11);

                $this->cell(30, 7, "Total: " . number_format($proj_sum), 0, 0, 'L');
                $this->Ln();
            }
            $this->Ln();
        }

    }

    $pdf = new PDF();
    $pdf->SetFont('Arial', '', 11);
    $pdf->AddPage();
    $pdf->LoadData();
    $pdf->Output();
    
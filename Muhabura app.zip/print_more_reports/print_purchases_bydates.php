<?php

    session_start();

    require_once 'Fpdf/fpdf.php';
    require_once '../web_db/connection.php';

    class PDF extends FPDF {

// Load data
        function LoadData() {
            // Read file lines

            $database = new dbconnection();
            $db = $database->openconnection();
            $sql = "select * from purchase_receit_line "
                    . " join user on user.StaffID=purchase_receit_line.User
                     and purchase_receit_line.entry_date>=:min and purchase_receit_line.entry_date<=:max";
            // <editor-fold defaultstate="collapsed" desc="----text Above (header = company addresses) ------">
            $this->Image('../web_images/report_header.png');
            $this->Ln();
            $this->Cell(60, 7, ': . ', 0, 0, 'L');

            $this->Ln();
            $this->SetFont("Arial", 'B', 14);
            $this->Cell(170, 7, 'PURCHASES REPORT OF ' . $_SESSION['min_date'] . ' - ' . $_SESSION['max_date'], 0, 0, 'C');

            $this->Ln();
            $this->Ln();
            $this->SetFont("Arial", '', 11);
// </editor-fold>

            $this->Cell(15, 7, 'S/N', 1, 0, 'L');

            $this->Cell(35, 7, 'UNIT COST', 1, 0, 'L');
            $this->Cell(40, 7, 'QUANTITY', 1, 0, 'L');
            $this->Cell(60, 7, 'AMOUNT', 1, 0, 'L');
            $this->Cell(63, 7, 'DATE', 1, 0, 'L');
            $this->Ln();
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $_SESSION['min_date'], ":max" => $_SESSION['max_date']));
            while ($row = $stmt->fetch()) {
                $this->cell(15, 7, $row['purchase_receit_line_id'], 1, 0, 'L');
                $this->cell(35, 7, $row['unit_cost'], 1, 0, 'L');
                $this->cell(40, 7, $row['quantity'], 1, 0, 'L');
                $this->cell(60, 7, $row['amount'], 1, 0, 'L');
                $this->cell(63, 7, $row['entry_date'], 1, 0, 'L');

                $this->Ln();
            }
        }

    }

    $pdf = new PDF();
    $pdf->SetFont('Arial', '', 11);
    $pdf->AddPage();
    $pdf->LoadData();
    $pdf->Output();
    
<?php

    session_start();

    require_once 'Fpdf/fpdf.php';
    require_once '../web_db/connection.php';

    class PDF extends FPDF {

// Load data
        function LoadData() {
            // Read file lines

            $database = new dbconnection();
            $db = $database->openconnection();
            $sql = "select * from account
                    right join journal_entry_line on journal_entry_line.accountid=account.account_id
                    left join journal_entry_header on journal_entry_header.journal_entry_header_id=journal_entry_line.journal_entry_header
                    join account_type on account.acc_type=account_type.account_type_id         
                    where account_type.name='other current asset'
                    or account_type.name='Fixed Assets'
                    or account_type.name='Other asset' 
                     and journal_entry_line.entry_date>=:min and journal_entry_line.entry_date<=:max";
            // <editor-fold defaultstate="collapsed" desc="----text Above (header = company addresses) ------">
            $this->Image('../web_images/report_header.png');
            $this->Ln();
            $this->Cell(60, 7, ': . ', 0, 0, 'L');

            $this->Ln();
            $this->SetFont("Arial", 'B', 14);
            $this->Cell(170, 7, 'BALANCE SHEET REPORT OF ' . $_SESSION['min_date'] . ' - ' . $_SESSION['max_date'], 0, 0, 'C');

            $this->Ln();
            $this->Ln();
            $this->SetFont("Arial", '', 11);
// </editor-fold>

            $this->Cell(15, 7, 'S/N', 1, 0, 'L');

            $this->Cell(35, 7, 'NAME', 1, 0, 'L');
            $this->Cell(40, 7, 'MEMO', 1, 0, 'L');
            $this->Cell(63, 7, 'PARTY', 1, 0, 'L');
            $this->Ln();
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $_SESSION['min_date'], ":max" => $_SESSION['max_date']));
            while ($row = $stmt->fetch()) {
                $this->cell(15, 7, $row['account_id'], 1, 0, 'L');
                $this->cell(35, 7, $row['name'], 1, 0, 'L');
                $this->cell(40, 7, $row['memo'], 1, 0, 'L');
                $this->cell(63, 7, $row['party'], 1, 0, 'L');

                $this->Ln();
            }
        }

    }

    $pdf = new PDF();
    $pdf->SetFont('Arial', '', 11);
    $pdf->AddPage();
    $pdf->LoadData();
    $pdf->Output();
    
<?php

    session_start();

    require_once 'Fpdf/fpdf.php';
    require_once '../web_db/connection.php';

    class PDF extends FPDF {

// Load data
        function LoadData() {
            // Read file lines

            $database = new dbconnection();
            $db = $database->openconnection();
            $sql = "select sales_receit_header.sales_receit_header_id,  sales_receit_header.sales_invoice,  sales_receit_header.quantity,  sales_receit_header.unit_cost,  sales_receit_header.amount,  sales_receit_header.entry_date,  sales_receit_header.User,  sales_receit_header.client,    sales_receit_header.budget_prep,  sales_receit_header.account,p_budget_items.item_name as item "
                    . ",user.Firstname,user.Lastname   from sales_receit_header "
                    . " join user on user.StaffID= sales_receit_header.User "
                    . " join sales_invoice_line on sales_receit_header.sales_invoice=sales_invoice_line.sales_invoice_line_id
                            join sales_order_line on sales_invoice_line.sales_order= sales_order_line.sales_order_line_id
                            join sales_quote_line on sales_order_line.quotationid=sales_quote_line.sales_quote_line_id 
                            join p_budget_items on sales_quote_line.item=p_budget_items.p_budget_items_id  ";
            // <editor-fold defaultstate="collapsed" desc="----text Above (header = company addresses) ------">
            $this->Image('../web_images/report_header.png');
            $this->Ln();
            $this->Cell(60, 7, ': . ', 0, 0, 'L');

            $this->Ln();
            $this->SetFont("Arial", 'B', 11);
            $this->Cell(170, 7, 'STOCK ITEMS REPORT OF ' . $_SESSION['min_date'] . ' - ' . $_SESSION['max_date'], 0, 0, 'C');

            $this->Ln();
            $this->Ln();
            $this->SetFont("Arial", '', 9);
// </editor-fold>

            $this->Cell(15, 7, 'S/N', 1, 0, 'L');
            $this->Cell(25, 7, 'ITEM', 1, 0, 'L');
            $this->Cell(20, 7, 'UNIT COST', 1, 0, 'L');
            $this->Cell(20, 7, 'QUANTITY', 1, 0, 'L');
            $this->Cell(30, 7, 'AMOUNT', 1, 0, 'L');
            $this->Cell(40, 7, 'DATE', 1, 0, 'L');
            $this->Cell(40, 7, 'User', 1, 0, 'L');
            $this->Ln();
            $stmt = $db->prepare($sql);
            $stmt->execute(array(":min" => $_SESSION['min_date'], ":max" => $_SESSION['max_date']));
            while ($row = $stmt->fetch()) {
                $this->cell(15, 7, $row['sales_receit_header_id'], 1, 0, 'L');
                $this->cell(25, 7, $row['item'], 1, 0, 'L');
                $this->cell(20, 7, $row['unit_cost'], 1, 0, 'L');
                $this->cell(20, 7, $row['quantity'], 1, 0, 'L');
                $this->cell(30, 7, number_format($row['amount']), 1, 0, 'L');
                $this->cell(40, 7, $row['entry_date'], 1, 0, 'L');
                $this->cell(40, 7, $row['Firstname'] . ' ' . $row['Lastname'], 1, 0, 'L');

                $this->Ln();
            }
        }

    }

    $pdf = new PDF();
    $pdf->SetFont('Arial', '', 10);
    $pdf->AddPage();
    $pdf->LoadData();
    $pdf->Output();
    
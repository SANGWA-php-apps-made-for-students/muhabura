<?php

    session_start();

    require_once 'Fpdf/fpdf.php';
    require_once '../web_db/connection.php';
    require_once '../web_db/fin_books_sum_views.php';
    require_once '../web_db/other_fx.php';

    class PDF extends FPDF {

// Load data
        function LoadData() {
            // Read file lines

            $database = new dbconnection();
            $db = $database->openconnection();
            $fin = new fin_books_sum_views();
            $ot = new other_fx();
            $sql = "select p_type_project.name from p_type_project "
                    . " group by  p_type_project.p_type_project_id ";
            // <editor-fold defaultstate="collapsed" desc="----text Above (header = company addresses) ------">
            $this->Image('../web_images/report_header.png');
            $this->Ln();
            $this->Cell(60, 7, ': . ', 0, 0, 'L');

            $this->Ln();
            $this->SetFont("Arial", 'B', 14);
            $class = trim(filter_input(INPUT_POST, 'acc_classid'));
            $acc_classname = trim($ot->get_acc_name_byid($class));
            if ($acc_classname == 'Cash_hand_bank') {
                $this->Cell(250, 7, 'Cash at hand / cash REPORT ', 0, 0, 'C');
            } else {
                $this->Cell(250, 7, strtoupper($acc_classname) . ' REPORT BETWEEEN ' . $this->s_date() . '  ' . $this->e_date(), 0, 0, 'C');
            }
            $this->SetFont("Arial", '', 10);
            $this->title_it('', '');
            $this->add_header();
            $this->put_query_loop($db, $fin, $acc_classname);


// </editor-fold>
        }

        function add_header() {
            $this->Ln();
            $this->Cell(40, 10, 'BUDGET ', 0, 0, 'L');
            $this->Cell(35, 10, 'PROJECT ', 0, 0, 'L');
            $this->Cell(30, 10, 'ACTIVITY ', 0, 0, 'L');
            $this->Cell(33, 10, 'FIN. ACCOUNT ', 0, 0, 'L');
            $this->Cell(30, 10, 'AMOUNT ', 0, 0, 'L');
            $this->Cell(40, 10, 'MEMO ', 0, 0, 'L');
            $this->Cell(40, 10, 'ENTRY DATE ', 0, 0, 'L');
            $this->Cell(40, 10, 'USER ', 0, 0, 'L');
            $this->Ln();
        }

        function prepared_by() {
            $this->SetFont('Arial', 'I', 8);
            // Print centered page number
            $this->Cell(0, 10, ' ', 0, 0, 'R');
            $this->Ln();
            $this->Cell(0, 10, ' ', 0, 0, 'R');
            $this->Ln();

            $this->Image('../web_images/prepared_by_protrait.png');
        }

        function put_query_loop($db, $obj, $query) {
            $sql = $obj->journal_based_query_acc_class($query);
            $stmt = $db->prepare($sql);
            $sdate = $this->s_date();
            $edate = $this->e_date();
            $stmt->execute(array(":min_date" => $sdate, ":max_date" => $edate));
            $this->loop_me($stmt);
        }

        function loop_me($stmt) {
            $sum = 0;
            while ($row = $stmt->fetch()) {
                $this->cell(40, 7, $row['budget'], 0, 0, 'L');
                $this->cell(35, 7, $row['project'], 0, 0, 'L');
                $this->cell(30, 7, $row['activity'], 0, 0, 'L');
                $this->cell(33, 7, $row['accountname'], 0, 0, 'L');
                $this->cell(30, 7, number_format($row['amount']), 0, 0, 'L');
                $this->cell(40, 7, $row['memo'], 0, 0, 'L');
                $this->cell(40, 7, $row['entry_date'], 0, 0, 'L');
                $this->cell(40, 7, $row['Firstname'] . ' ' . $row['Lastname'], 0, 0, 'L');

                $this->Ln();
                $sum += $row['amount'];
            }
            $this->SetFont("Arial", 'B', 11);
            $this->cell(158, 7, 'Total: ' . number_format($sum), 0, 0, 'R');
        }

        function title_it($title, $note) {
            $this->Ln();
            $this->cell(5, 7, "", 0, 0, 'L');
            $this->SetFont("Arial", 'B', 10);
            $this->cell(50, 7, $title, 0, 0, 'L');
            $this->cell(10, 7, $note, 0, 0, 'L');
            $this->Ln();
            $this->SetFont("Arial", '', 9);
        }

        function e_date() {
            $date_obj = new other_fx();
            return $date_obj->get_this_year_end_date();
        }

        function s_date() {
            $date_obj = new other_fx();
            return $date_obj->get_this_year_start_date();
        }

        function get_font() {
            $obj = new preppared_footer();
            return $font = $obj->fonts();
        }

    }

    $pdf = new PDF();
    $pdf->SetFont('Arial', '', 11);
    $pdf->AddPage('L');
    $pdf->LoadData();
    $pdf->prepared_by();
    $pdf->Output();
    